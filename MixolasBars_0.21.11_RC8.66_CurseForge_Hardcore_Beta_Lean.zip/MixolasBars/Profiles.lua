-- Mixolas Bars v0.18: independent layout profiles and per-character restore points.
-- Named profiles contain visual layout, Mixolas button overrides, and (v4)
-- native WoW keybinding snapshots including interface panels and movement.
-- Spell placements, macro content and action assignments are never copied.
-- Older v1-v3 profiles contain no native snapshot and preserve live WoW keys.
local api = _G.MixolasBarsAPI
if not api then return end
local MAX_PROFILES = 16
local BUILTIN_NAME = "MIXOLAS"
local function builtin()
    local profile=_G.MixolasBarsBuiltInProfile
    return type(profile)=="table" and type(profile.layout)=="table" and profile or nil
end

local applyingProfile = false
local profileAutosaveReady = false
local skipCurrentSaveOnce = false
local equal, layoutDiffers
local forkBuiltInIfChanged
-- Normalized live values are the edit baseline. Rendering defaults may be
-- filled during a load; that is not a user edit and must not create a copy.
local builtInLiveLayoutBaseline, builtInLiveBindingsBaseline
local MAX_SNAPSHOTS = 8
local FIELDS = {
    -- Blizzard visibility is a global preference, not a visual profile field.
    -- Old profiles must not resurrect native Blizzard action bars when loaded.
    "locked", "snapEnabled", "visible",
    "buttonSize", "gap", "diamondGapEW", "diamondGapNS", "glow", "borderAlpha", "borderWidth",
    "illuminationStyle", "diamondGlows", "diamondIlluminationStyles", "glowSpread", "glowSaturation",
    "hotkeyFontSize", "itemCountFontSize", "showHotkeys", "showMacroNames", "rangeDim", "combatDim", "buttonLock",
    "gcdSweep", "gcdDarkness", "counts", "diamondEnabled", "diamondShowEmpty", "alphas", "combatAlphas",
    "brightness", "scales", "borderStyles", "glowMotions", "colors",
    "positions", "regularBars", "utilityBars", "decorFrames", "frameStudio",
    "minimapAngle", "minimapSize",
}
local function clone(value,level)
    if type(value)~="table" then return value end
    if (level or 0)>18 then return nil end
    local t={}
    for k,v in pairs(value) do
        if (type(k)=="string" or type(k)=="number")
            and (type(v)=="table" or type(v)=="number" or type(v)=="string" or type(v)=="boolean") then
            t[k]=clone(v,(level or 0)+1)
        end
    end
    return t
end
local function settingsCopy()
    local db=api.GetDB()
    if not db then return nil end
    local out={}
    for _,key in ipairs(FIELDS) do
        if db[key]~=nil then out[key]=clone(db[key]) end
    end
    return out
end
-- Use the live character-owned binding map, not a stale account-wide alias.
-- Mixolas-owned shortcut overrides are stored separately from a snapshot of
-- native WoW commands; never copy spell placements or macro contents.
-- A newly created profile does not inherit modified bars, their positions,
-- decorative frames or attached frame styles. No live SavedVariables are
-- touched while building this template.
local function factoryLayout()
    local fresh=api.GetDefaultVisualLayout and api.GetDefaultVisualLayout()
    if type(fresh)~="table" then return nil,"Factory defaults are unavailable." end
    if not api.GetDefaultRegularBarLayout or not api.GetDefaultUtilityBarLayout then
        return nil,"Bar default providers are unavailable."
    end
    fresh.regularBars=clone(api.GetDefaultRegularBarLayout())
    fresh.utilityBars=clone(api.GetDefaultUtilityBarLayout())
    fresh.decorFrames={}
    fresh.frameStudio={}
    -- On the first refresh the addon will show six diamonds and two 3x4 bars.
    -- Locking is an editing safety state, not a binding or spell reset.
    fresh.locked=true
    return fresh
end
local function bindingsCopy()
    local char=api.GetCharacterDB()
    local db=api.GetDB()
    local source=(char and char.bindings) or (db and db.bindings) or {}
    return clone(source)
end
local function nativeCopy()
    if type(api.CaptureNativeBindings)~="function" then
        return nil,"Native keybinding capture is not available."
    end
    return api.CaptureNativeBindings()
end
local function nativeCount(snapshot)
    return (api.CountNativeBindings and api.CountNativeBindings(snapshot)) or 0
end
local function saveLiveNative(profile)
    -- Active profiles always follow native changes, including pre-v4 profiles.
    -- When an old profile is first selected, seed it from the LIVE WoW set;
    -- historical keys that were never recorded cannot be reconstructed.
    if not profile then return false,"No active named profile." end
    local native,why=nativeCopy()
    if not native then return false,why end
    -- A profile may contain commands supplied by an addon/class unavailable
    -- on this character. Keep those dormant entries when their keys are free,
    -- rather than silently deleting them on load or logout.
    local known=api.GetNativeBindingCommands and api.GetNativeBindingCommands()
    if type(known)=="table" then
        for key,command in pairs((profile.nativeBindings and profile.nativeBindings.keys) or {}) do
            if not known[command] and native.keys[key]==nil then
                native.keys[key]=command
            end
        end
    end
    profile.nativeBindings=native
    profile.version=4
    return true
end
local function bindingCount(map)
    local total=0
    for _,keys in pairs(map or {}) do
        if type(keys)=="table" then total=total+#keys end
    end
    return total
end
local function frameCount(layout)
    local count=0
    for _,frame in ipairs((layout and layout.decorFrames) or {}) do
        if frame and not frame.deleted then count=count+1 end
    end
    return count
end
local function validName(name)
    if type(name)~="string" then return nil end
    name=name:match("^%s*(.-)%s*$")
    if #name<1 or #name>32 or name:find("[%c|;]") then return nil end
    return name
end
local function activeDB()
    local db=api.GetDB()
    if not db then return nil end
    db.mixolasProfiles=db.mixolasProfiles or {}
    -- Older builds allowed a user-created profile named MIXOLAS. Never throw
    -- that data away: move it to a personal name once, freeing the reserved name.
    if db.mixolasProfiles[BUILTIN_NAME] then
        local old=db.mixolasProfiles[BUILTIN_NAME]
        local renamed="MIXOLAS (previous)"
        local i=2
        while db.mixolasProfiles[renamed] do
            renamed="MIXOLAS (previous "..i..")";i=i+1
        end
        db.mixolasProfiles[renamed]=old
        db.mixolasProfiles[BUILTIN_NAME]=nil
        local char=api.GetCharacterDB()
        if char and char.activeLayoutProfile==BUILTIN_NAME then char.activeLayoutProfile=renamed end
    end
    db.mixolasSnapshots=db.mixolasSnapshots or {}
    db.mixolasProfileRenames=db.mixolasProfileRenames or {}
    return db
end
local function listNames()
    local db=activeDB()
    if not db then return {} end
    local names={}
    for name,data in pairs(db.mixolasProfiles) do
        if type(name)=="string" and type(data)=="table" and type(data.layout)=="table" then
            names[#names+1]=name
        end
    end
    table.sort(names)
    -- The protected default is always first, regardless of personal names.
    if builtin() then table.insert(names,1,BUILTIN_NAME) end
    return names
end
-- Ordinary personal profiles are the only ones created dynamically. The
-- shipped MIXOLAS profile is not stored in SavedVariables and never renamed.
local function newPersonalName(db)
    local base="New Profile"
    if not db.mixolasProfiles[base] then return base end
    for i=2,MAX_PROFILES+2 do
        local name=base.." "..i
        if not db.mixolasProfiles[name] then return name end
    end
    return nil
end
-- Fork a read-only MIXOLAS working view on the FIRST genuine user change.
-- The source snapshot always stays in BuiltInPreset.lua. Native keybindings
-- reflect the current character unless the user explicitly applied the preset.
forkBuiltInIfChanged=function(force)
    if not profileAutosaveReady or applyingProfile then return true end
    local char=api.GetCharacterDB()
    if not char or char.activeLayoutProfile~=BUILTIN_NAME then return true end
    local preset=builtin()
    local db=activeDB()
    if not preset or not db then return false,"MIXOLAS preset is unavailable." end
    if not force then
        local live=settingsCopy() or {}
        local baseline=builtInLiveLayoutBaseline or preset.layout
        local differs=false
        for _,field in ipairs(FIELDS) do
            if field~="locked" and not equal(live[field],baseline[field]) then
                differs=true;break
            end
        end
        if not differs and equal(bindingsCopy(),builtInLiveBindingsBaseline or preset.bindings) then return true end
    end
    if api.IsInCombat and api.IsInCombat() then
        -- Secure state is never edited during combat. Keep the preset intact.
        return false,"Cannot create a profile during combat."
    end
    local name=newPersonalName(db)
    if not name or (#listNames()-(builtin() and 1 or 0))>=MAX_PROFILES then
        return false,"Profile library is full. Delete an unused profile before editing MIXOLAS."
    end
    local native,why=nativeCopy()
    if not native then return false,why end
    local live=settingsCopy()
    db.mixolasProfiles[name]={version=4,layout=clone(live),
        bindings=bindingsCopy(),nativeBindings=native,
        builtInSource=BUILTIN_NAME,saved="Created after editing MIXOLAS"}
    char.activeLayoutProfile=name
    char.activeVisualLayout=clone(live)
    if api.Say then api.Say("MIXOLAS is protected. Your changes are now saved in '"..name.."'. You can rename or delete it in Profiles.") end
    return true,name
end
-- Keep a separate active layout for each character, while the named profile
-- library remains account-wide.  MixolasBarsDB remains the live rendering DB
-- for legacy modules, so apply the character's layout during PLAYER_LOGIN.
local function rememberCharacterLayout()
    local char=api.GetCharacterDB()
    -- The working layout is plain SavedVariables data, never secure UI state.
    -- Capture it even during logout while flagged as in combat: the previous
    -- combat guard discarded frames edited earlier in the session.
    if char and api.IsReady() then
        local current=settingsCopy()
        char.activeVisualLayout=current
        -- AceDB-style behavior: edits belong to the selected shared profile,
        -- not to a separate unsaved snapshot. Never write while importing.
        if profileAutosaveReady and not applyingProfile then
            local forked,reason=forkBuiltInIfChanged(false)
            if not forked and api.Say then api.Say(reason) end
            local db=activeDB()
            local name=char.activeLayoutProfile
            local profile=name and db and db.mixolasProfiles[name]
            if profile and name~=BUILTIN_NAME then
                profile.layout=clone(current)
                profile.bindings=bindingsCopy()
                -- The binding editor is transactional: do not snapshot a
                -- temporarily previewed keyboard configuration.
                if not (api.IsBindingMode and api.IsBindingMode()) then
                    saveLiveNative(profile)
                end
                profile.version=profile.nativeBindings and 4 or 3
            end
        end
        return true
    end
    return false
end

local function refreshVisuals()
    -- These are the same render paths used by manual UI edits.  In particular
    -- neither icon nor minimap refresh is covered by api.Refresh alone.
    local paths={
        {"Refresh"}, {"RefreshRegularBars"}, {"RefreshUtilityBars"},
        {"ReloadDecorFromConfig"}, {"RefreshFrameStudio"}, {"RefreshRegularActionIcons"},
        {"RefreshIcons"}, {"RefreshHotkeys", "RefreshHotkeyLabels"},
        {"UpdateGCD"}, {"UpdateMinimapIcon"},
    }
    for _,alternates in ipairs(paths) do
        for _,name in ipairs(alternates) do
            local fn=api[name]
            if type(fn)=="function" then
                local ok,value=pcall(fn)
                if not ok then return false,name..": "..tostring(value) end
                if value==false then return false,name.." rejected the refresh" end
                break
            end
        end
    end
    local blizzard=_G.MixolasBarsBlizzardVisibility
    local db=api.GetDB()
    if blizzard then
        -- Blizzard visibility is intentionally NOT part of profile contents.
        if blizzard.SetHiddenButtons then blizzard.SetHiddenButtons(db.hideBlizzard) end
        if blizzard.SetHiddenArt then blizzard.SetHiddenArt(db.hideBlizzardArt) end
    end
    return true
end
local function restoreLayout(config, replaceAll)
    if api.IsInCombat() then return false,"Cannot load a layout during combat." end
    if not api.IsReady() then return false,"Mixolas Bars is not initialized yet." end
    if type(config)~="table" then return false,"Invalid layout data." end
    local db=api.GetDB()
    if not db then return false,"Mixolas settings are unavailable." end
    local previous=settingsCopy()
    for _,key in ipairs(FIELDS) do
        -- New profiles must not inherit any prior profile's optional settings.
        -- Existing/legacy profiles keep their original merge semantics.
        if replaceAll or config[key]~=nil then db[key]=clone(config[key]) end
    end
    -- Profiles saved before Frame Studio existed should use "Existing" frames,
    -- rather than inherit the unrelated class housing from another profile.
    if config.frameStudio==nil then db.frameStudio={} end
    -- Legacy profiles have no per-diamond combat opacity: inherit THEIR own
    -- saved regular alphas, never the previously loaded profile overrides.
    if config.combatAlphas==nil then db.combatAlphas={} end
    -- Secure action positions only change outside combat.  Lock the layout
    -- before drawing; saved visual configurations never move spell actions.
    db.locked=true
    db.combatUsability=true
    local ok,why=refreshVisuals()
    if not ok then
        for _,key in ipairs(FIELDS) do db[key]=clone(previous[key]) end
        db.locked=true
        pcall(refreshVisuals)
        return false,"Could not apply layout ("..tostring(why).."); original settings restored."
    end
    rememberCharacterLayout()
    return true
end
api.CaptureCurrentVisualLayout=rememberCharacterLayout
api.IsProfileApplying=function() return applyingProfile end
-- Called immediately after a user changes a frame, not just at logout. This
-- protects the working copy even when a logout/combat event is interrupted.
api.MarkVisualLayoutDirty=rememberCharacterLayout
-- Persist other visual control changes as they happen (not just on logout).
-- DecorFrames handles its own add/edit/remove calls, while DragController
-- handles positions, so these wrappers cover all the remaining UI editors.
for _,name in ipairs({"SetRegularBar", "DockRegularBar", "SetUtilityBar",
        "SetDiamondEnabled", "SetDiamondShowEmpty", "SetDiamondOutOpacity", "SetDiamondCombatOpacity",
        "ChangeColor", "SetCount", "ResetPositions", "Reset"}) do
    local fn=api[name]
    if type(fn)=="function" then
        api[name]=function(...)
            local result=fn(...)
            if result then rememberCharacterLayout() end
            return result
        end
    end
end

equal=function(a,b,depth)
    if type(a)~=type(b) then return false end
    if type(a)~="table" then return a==b end
    if (depth or 0)>18 then return true end
    for key,val in pairs(a) do
        if not equal(val,b[key],(depth or 0)+1) then return false end
    end
    for key in pairs(b) do if a[key]==nil then return false end end
    return true
end
layoutDiffers=function(saved)
    local live=settingsCopy() or {}
    for _,key in ipairs(FIELDS) do
        -- Loading a profile locks the edit handles by design. That temporary
        -- UI safety state should never count as an unsaved profile change.
        if key~="locked" and not equal(live[key],saved[key]) then return true end
    end
    return false
end
-- Legacy compatibility: profiles are live now and update automatically.
-- Keep status API for old UI consumers; no manual save is ever required.
api.GetProfileSaveStatus=function(name)
    local db=activeDB()
    local char=api.GetCharacterDB()
    name=name or (char and char.activeLayoutProfile)
    local profile=name and db and db.mixolasProfiles[name]
    if not profile or type(profile.layout)~="table" then
        return nil,"No active saved profile; create one to share your layout."
    end
    local native=profile.nativeBindings and nativeCopy()
    if layoutDiffers(profile.layout) or
        (type(profile.bindings)=="table" and not equal(bindingsCopy(),profile.bindings))
        or (native and not equal(native.keys,profile.nativeBindings.keys)) then
        return true,"Edits are being synchronized to '"..name.."'."
    end
    return false,"'"..name.."' saves automatically."
end
api.SaveActiveProfile=function()
    local char=api.GetCharacterDB()
    local name=char and char.activeLayoutProfile
    if not name or not api.HasNamedProfile(name) then
        return false,"No active profile. Create a named profile first."
    end
    return api.SaveNamedProfile(name)
end

api.ListProfiles=listNames
-- A native snapshot is an explicit property of each profile.  Profiles
-- created before v4 have no native key data; they CANNOT safely restore an
-- "unbound" key by guessing or copying the last selected profile.
api.GetNamedProfileNativeStatus=function(name)
    local db=activeDB()
    local profile=name==BUILTIN_NAME and builtin() or (db and db.mixolasProfiles[name])
    if not profile then return nil,0,"Profile not found." end
    if type(profile.nativeBindings)=="table" and profile.nativeBindings.version==1
        and type(profile.nativeBindings.keys)=="table" then
        return true,nativeCount(profile.nativeBindings),"Saved WoW bindings"
    end
    return false,0,"NOT SAVED (older profile)"
end
-- Optional compatibility method: automatic updates no longer require a button.
-- This must never overwrite visual layout or Mixolas button bindings.
api.SaveActiveNativeBindings=function()
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local db=activeDB()
    local char=api.GetCharacterDB()
    local name=char and char.activeLayoutProfile
    if name==BUILTIN_NAME then return false,"The built-in MIXOLAS preset is read-only." end
    local profile=name and db and db.mixolasProfiles[name]
    if not profile or type(profile.layout)~="table" then
        return false,"Select a named profile before saving WoW keybindings."
    end
    if applyingProfile then return false,"A profile is currently loading." end
    local native,err=nativeCopy()
    if not native then return false,"Cannot capture WoW shortcuts: "..tostring(err) end
    if profile.nativeBindings then
        -- Preserve unknown, dormant addon commands as before.
        saveLiveNative(profile)
    else
        profile.nativeBindings=native
    end
    profile.version=4
    return true,"WoW keybindings saved to '"..name.."' ("..nativeCount(profile.nativeBindings)..
        " keys). Other profiles were not changed."
end
-- Diagnostic for a reported key leaking between profile snapshots.
-- Shows saved ownership vs live WoW ownership, without changing bindings.
SLASH_MIXOLASBARSPROFILEKEY1="/mxbprofilekey"
SlashCmdList=SlashCmdList or {}
SlashCmdList.MIXOLASBARSPROFILEKEY=function(raw)
    local key=(type(raw)=="string" and raw:match("^%s*(.-)%s*$") or ""):upper()
    if key=="" or #key>64 or key:find("%c") then
        if api.Say then api.Say("Usage: /mxbprofilekey J (or SHIFT-M)") end
        return
    end
    local char=api.GetCharacterDB()
    local active=char and char.activeLayoutProfile or "none"
    local live="(unbound)"
    if type(GetBindingAction)=="function" then
        local ok,command=pcall(GetBindingAction,key)
        if ok and type(command)=="string" and command~="" then live=command end
    end
    if api.Say then api.Say("Native "..key.." LIVE: "..live.."; active: "..active) end
    local db=activeDB()
    for _,name in ipairs(listNames()) do
        local profile=db.mixolasProfiles[name]
        local saved=profile and profile.nativeBindings
        local state="NOT SAVED (legacy; WoW keys unchanged on switch)"
        if type(saved)=="table" and saved.version==1 and type(saved.keys)=="table" then
            state=saved.keys[key] or "(unbound)"
        end
        if api.Say then api.Say("  "..name..": "..key.." -> "..state) end
    end
end
api.GetActiveProfileName=function()
    local char=api.GetCharacterDB()
    return char and char.activeLayoutProfile or nil
end
-- Notify after successfully changing the Mixolas override map.
-- Native bindings are captured independently using WoW's binding APIs.
api.ProfileBindingsChanged=function()
    if not profileAutosaveReady or applyingProfile then return end
    forkBuiltInIfChanged(false)
    local db=activeDB()
    local char=api.GetCharacterDB()
    local profile=char and db.mixolasProfiles[char.activeLayoutProfile]
    if profile and char.activeLayoutProfile~=BUILTIN_NAME then
        profile.bindings=bindingsCopy()
        profile.version=profile.nativeBindings and 4 or 3
    end
end
local originalSetCharacterBindings=api.SetCharacterBindings
if type(originalSetCharacterBindings)=="function" then
    api.SetCharacterBindings=function(map)
        local ok=originalSetCharacterBindings(map)
        if ok then api.ProfileBindingsChanged() end
        return ok
    end
end
api.SaveNamedProfile=function(raw)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local name=validName(raw)
    if not name then return false,"Name must be 1-32 characters; no line breaks." end
    if name:upper()==BUILTIN_NAME then return false,"MIXOLAS is a reserved built-in preset." end
    local db=activeDB()
    if not db.mixolasProfiles[name] and (#listNames()-(builtin() and 1 or 0))>=MAX_PROFILES then
        return false,"Maximum of "..MAX_PROFILES.." saved profiles."
    end
    rememberCharacterLayout() -- commit previous active profile before switching
    local layout=settingsCopy()
    local bindings=bindingsCopy()
    local native,why=nativeCopy()
    if not native then return false,"Cannot save profile: "..tostring(why) end
    -- Freeze a snapshot of the live custom frames and keys; never retain a
    -- reference to the mutable settings or character binding tables.
    -- Profiles without user-created frames are valid, too.
    layout.decorFrames=layout.decorFrames or {}
    db.mixolasProfiles[name]={version=4, layout=layout, bindings=bindings,
        nativeBindings=native,
        saved=(date and date("%Y-%m-%d %H:%M") or "Saved")}
    local char=api.GetCharacterDB()
    if char then
        char.activeLayoutProfile=name
        char.activeVisualLayout=clone(layout)
    end
    return true,"Saved profile '"..name.."': "..frameCount(layout).." custom frames, "..
        bindingCount(bindings).." Mixolas keys and "..nativeCount(native)..
        " native WoW keys. Available on your other characters."
end
-- CREATE means start fresh. SAVE (above) intentionally still captures the
-- current layout for legacy callers; COPY FROM explicitly duplicates another.
api.CreateNamedProfile=function(raw)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local name=validName(raw)
    if not name then return false,"Name must be 1-32 characters; no line breaks." end
    if name:upper()==BUILTIN_NAME then return false,"MIXOLAS is a reserved built-in preset." end
    local db=activeDB()
    if db.mixolasProfiles[name] then return false,"That profile already exists." end
    if (#listNames()-(builtin() and 1 or 0))>=MAX_PROFILES then return false,"Maximum of "..MAX_PROFILES.." saved profiles." end
    local layout,err=factoryLayout()
    if not layout then return false,err end
    local char=api.GetCharacterDB()
    if not char then return false,"Character settings are unavailable." end
    -- Record the previous profile before changing any live settings. The old
    -- profile remains untouched and can be selected again at any time.
    rememberCharacterLayout()
    local oldLayout=settingsCopy()
    local oldBindings=bindingsCopy()
    local native,why=nativeCopy()
    if not native then return false,"Cannot create profile: "..tostring(why) end
    local oldProfile=char.activeLayoutProfile
    if api.TakeLayoutSnapshot then
        local ok,result=pcall(api.TakeLayoutSnapshot,"Before creating blank profile: "..name)
        if not ok or result==false then return false,"Could not save a restore point; profile not created." end
    end
    db.mixolasProfiles[name]={version=4,layout=clone(layout),bindings={},
        nativeBindings=native,
        saved=(date and date("%Y-%m-%d %H:%M") or "Created blank")}
    applyingProfile=true
    local ok,why=restoreLayout(layout,true)
    if not ok then
        db.mixolasProfiles[name]=nil
        applyingProfile=false
        return false,why or "Could not create profile; previous layout restored."
    end
    -- Native WoW bindings, spells, and action-slot assignments are NEVER
    -- cleared. Only Mixolas-owned custom key overrides are reset.
    local stored,accepted=pcall(function()
        return api.SetCharacterBindings and api.SetCharacterBindings({})
    end)
    if not stored or accepted~=true then
        pcall(function() api.SetCharacterBindings(clone(oldBindings)) end)
        pcall(function() restoreLayout(oldLayout,true) end)
        char.activeLayoutProfile=oldProfile
        db.mixolasProfiles[name]=nil
        applyingProfile=false
        return false,"Could not reset Mixolas keys; original profile restored."
    end
    char.activeLayoutProfile=name
    -- The factory helpers and module refresh populate their actual defaults.
    -- Save those exact live values as the new profile, not another profile's
    -- settings. Keep the old profile's auto-save protected during the switch.
    applyingProfile=false
    rememberCharacterLayout()
    local routeOK=pcall(function()
        if api.ApplyBindings then api.ApplyBindings() end
        if api.RefreshHotkeys then api.RefreshHotkeys() end
    end)
    return true,"Created blank profile '"..name.."': default bars and frames, "..
        "no custom Mixolas keys. "..nativeCount(native)..
        " native WoW shortcuts captured (unchanged). Spells are unchanged."..
        (not routeOK and " Check live key routing after reload." or "")
end
-- Personal and account-shared profiles can always be renamed. Only the
-- immutable, code-shipped MIXOLAS preset reserves its name. Keep aliases for
-- other characters that still point at the old shared name in SavedVariables;
-- those aliases are resolved when those characters next log in.
api.RenameNamedProfile=function(oldName,rawNewName)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    if oldName==BUILTIN_NAME then return false,"The built-in MIXOLAS preset cannot be renamed." end
    local newName=validName(rawNewName)
    if not newName then return false,"New name must be 1-32 characters; no line breaks." end
    if newName:upper()==BUILTIN_NAME then return false,"MIXOLAS is reserved for the built-in preset." end
    local db=activeDB()
    if not db or not db.mixolasProfiles[oldName] then return false,"Select an existing personal profile." end
    if newName==oldName then return false,"That is already this profile's name." end
    if db.mixolasProfiles[newName] then return false,"A profile with that name already exists." end
    local char=api.GetCharacterDB()
    local active=char and char.activeLayoutProfile==oldName
    if active then rememberCharacterLayout() end
    db.mixolasProfiles[newName]=db.mixolasProfiles[oldName]
    db.mixolasProfiles[oldName]=nil
    if active then char.activeLayoutProfile=newName end
    if db.mixolasWorkingProfile==oldName then db.mixolasWorkingProfile=newName end
    local aliases=db.mixolasProfileRenames
    -- The destination may have been used as a profile name long ago; don't
    -- let a stale alias steal it from its new owner.
    aliases[newName]=nil
    for alias,target in pairs(aliases) do
        if target==oldName then aliases[alias]=newName end
    end
    aliases[oldName]=newName
    return true,"Renamed '"..oldName.."' to '"..newName.."'. All settings and bindings preserved."
end

api.GetProfileFrameCounts=function(name)
    local live=settingsCopy()
    local db=activeDB()
    local profile=name and db and db.mixolasProfiles[name]
    return frameCount(live),profile and frameCount(profile.layout) or nil
end
api.HasNamedProfile=function(name)
    local db=activeDB()
    return (name==BUILTIN_NAME and builtin()~=nil) or (db and db.mixolasProfiles[name]~=nil)
end
api.IsBuiltInProfile=function(name) return name==BUILTIN_NAME and builtin()~=nil end
api.TakeLayoutSnapshot=function(reason)
    if api.IsInCombat() or not api.IsReady() then return false end
    local db=activeDB()
    if not db then return false end
    local char=api.GetCharacterDB()
    if not char then return false end
    -- Snapshots are deliberately per-character, even though the visual
    -- settings live in the account-level SavedVariables file.
    char.layoutSnapshots=char.layoutSnapshots or {}
    local entry={
        label=tostring(reason or "Manual snapshot"):sub(1,54),
        saved=(date and date("%Y-%m-%d %H:%M") or "Saved"),
        layout=settingsCopy(),
        bindings=bindingsCopy(),
        nativeBindings=nativeCopy(),
        customActions=clone(char.customActions or db.customActions or {}),
    }
    table.insert(char.layoutSnapshots,1,entry)
    while #char.layoutSnapshots>MAX_SNAPSHOTS do table.remove(char.layoutSnapshots) end
    return true
end
api.GetLayoutSnapshots=function()
    local char=api.GetCharacterDB()
    return char and char.layoutSnapshots or {}
end
-- Apply the shared layout first, then the optional profile keybinding map.
-- If the bindings cannot be stored, roll back both stages together.
-- Legacy v1 visual-only profiles keep this character's existing bindings.
api.LoadNamedProfile=function(name,noBackup)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local db=activeDB()
    if name==BUILTIN_NAME then
        return false,"MIXOLAS is a read-only preset. Select it in Profiles to apply an editable copy."
    end
    local profile=db and db.mixolasProfiles[name]
    if not profile or type(profile.layout)~="table" then return false,"Profile not found." end
    local char=api.GetCharacterDB()
    local oldLayout=settingsCopy()
    local oldBindings=bindingsCopy()
    local oldProfile=char and char.activeLayoutProfile
    local legacyNative=type(profile.nativeBindings)~="table"
    if not noBackup then api.TakeLayoutSnapshot("Before loading: "..tostring(name)) end
    -- Save edits to the old selected profile before importing the new one.
    -- On first login autosave is intentionally not enabled yet.
    if profileAutosaveReady and not skipCurrentSaveOnce then rememberCharacterLayout() end
    skipCurrentSaveOnce=false
    applyingProfile=true
    local ok,why=restoreLayout(profile.layout)
    if not ok then
        applyingProfile=false
        return false,why or "Cannot restore layout."
    end
    local hasKeys=profile.version and profile.version>=2 and type(profile.bindings)=="table"
    if hasKeys then
        local stored,accepted=pcall(function()
            return api.SetCharacterBindings and api.SetCharacterBindings(clone(profile.bindings))
        end)
        if not stored or accepted~=true then
            -- Binding application is a separate, character-specific operation.
            -- Do not leave a half-loaded layout behind if that stage fails.
            pcall(function() api.SetCharacterBindings(clone(oldBindings)) end)
            pcall(function() restoreLayout(oldLayout) end)
            if char then char.activeLayoutProfile=oldProfile end
            applyingProfile=false
            return false,"Could not apply profile keybindings; previous layout and keys restored."
        end
        if type(profile.nativeBindings)=="table" then
            local nativeOK,nativeResult=api.RestoreNativeBindings(profile.nativeBindings)
            if not nativeOK then
                pcall(function() api.SetCharacterBindings(clone(oldBindings)) end)
                pcall(function() restoreLayout(oldLayout) end)
                if char then char.activeLayoutProfile=oldProfile end
                applyingProfile=false
                return false,"Native WoW keys could not be restored: "..tostring(nativeResult)..
                    ". Previous layout and Mixolas keys restored."
            end
        end
        -- A routing mismatch can be reported by the client even though the
        -- assignments are correctly persisted. Do not discard saved keys just
        -- because verification is unavailable in the beta client.
        local routed,routeResult=pcall(function()
            return api.ApplyBindings and api.ApplyBindings()
        end)
        if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
        if api.KeyBindProfilesSaveCurrent then pcall(api.KeyBindProfilesSaveCurrent) end
        if char then char.activeLayoutProfile=name end
        applyingProfile=false
        rememberCharacterLayout()
        local warning=(not routed or routeResult==false) and
            " Some live key routes need verification (/mxbkey KEY)." or ""
        return true,"Loaded profile '"..name.."': "..frameCount(profile.layout).." frames, "..
            bindingCount(profile.bindings).." Mixolas keys, "..
            nativeCount(profile.nativeBindings).." native WoW keys. Auto-save ON."..
            (legacyNative and " First use of older profile: live WoW keys were adopted as its initial baseline; remove any inherited shortcuts once and changes will then save automatically." or "")..warning
    end
    if char then char.activeLayoutProfile=name end
    applyingProfile=false
    rememberCharacterLayout()
    return true,"Loaded legacy visual-only profile '"..name.."': "..
        frameCount(profile.layout).." frames. Native keys now auto-save to this profile. Older shortcut settings cannot be reconstructed; remove any inherited keys once to establish the desired layout."
end
local function applyBuiltInAppearance(preset)
    local db=api.GetDB()
    if not db or not preset then return end
    local cosmetics=preset.appearance or {}
    local look=cosmetics.obsidianPrototype or {}
    db.obsidianPrototype=db.obsidianPrototype or {}
    for _,key in ipairs({"intensity","frameOpacity","armorGlow","armorOpacity"}) do
        if look[key]~=nil then db.obsidianPrototype[key]=clone(look[key]) end
    end
    local flash=cosmetics.activationFlash or {}
    db.activationFlash=db.activationFlash or {}
    for _,key in ipairs({"enabled","strength","duration","bar1ModifierColors","bar2ModifierColors"}) do
        if flash[key]~=nil then db.activationFlash[key]=clone(flash[key]) end
    end
    local renderer=_G.MixolasBarsObsidian
    if renderer and type(renderer.Apply)=="function" then pcall(renderer.Apply) end
end
-- Select the genuine built-in default without making or saving a personal
-- profile. This never changes native WoW keys without explicit consent.
api.SelectBuiltInDefault=function(skipBackup)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local preset=builtin()
    local char=api.GetCharacterDB()
    if not preset or not char then return false,"Built-in MIXOLAS unavailable." end
    if not skipBackup and api.TakeLayoutSnapshot and not api.TakeLayoutSnapshot("Before returning to MIXOLAS default") then
        return false,"Could not save backup; profile unchanged."
    end
    if profileAutosaveReady and not applyingProfile then rememberCharacterLayout() end
    local previousLayout=settingsCopy()
    local previousBindings=bindingsCopy()
    local previousName=char.activeLayoutProfile
    applyingProfile=true
    local ok,reason=restoreLayout(preset.layout,true)
    if not ok then applyingProfile=false;return false,reason end
    local stored,accepted=pcall(function()
        return api.SetCharacterBindings and api.SetCharacterBindings(clone(preset.bindings))
    end)
    if not stored or accepted~=true then
        pcall(function() restoreLayout(previousLayout,true) end)
        pcall(function() api.SetCharacterBindings(previousBindings) end)
        char.activeLayoutProfile=previousName
        applyingProfile=false
        return false,"Could not load MIXOLAS keys; profile unchanged."
    end
    char.activeLayoutProfile=BUILTIN_NAME
    char.activeVisualLayout=settingsCopy()
    applyBuiltInAppearance(preset)
    builtInLiveLayoutBaseline=settingsCopy()
    builtInLiveBindingsBaseline=bindingsCopy()
    applyingProfile=false
    if api.ApplyBindings then pcall(api.ApplyBindings) end
    if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
    return true,"MIXOLAS is the protected default. Edit a setting to create a personal profile. Native WoW keys remain unchanged until you explicitly apply MIXOLAS."
end
-- Delete from the shared account-wide library. Deleting the currently used
-- profile must also select a valid replacement *now*, not wait until login.
-- The existing profile remains untouched if switching to a replacement fails.
api.DeleteNamedProfile=function(name)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    if type(name)~="string" then return false,"Select a profile to delete." end
    if name==BUILTIN_NAME then return false,"The built-in MIXOLAS preset cannot be deleted." end
    local db=activeDB()
    if not db or not db.mixolasProfiles[name] then return false,"Profile not found." end
    local char=api.GetCharacterDB()
    local active=char and char.activeLayoutProfile==name
    if active then
        if api.TakeLayoutSnapshot and not api.TakeLayoutSnapshot("Before deleting: "..name) then
            return false,"Could not save a backup; nothing deleted."
        end
        -- A deleted active profile returns to MIXOLAS, never fabricates
        -- a replacement named Default or a protected working copy.
        local ok,reason=api.SelectBuiltInDefault(true)
        if not ok then return false,"Could not return to MIXOLAS; nothing deleted. "..tostring(reason) end
    end
    db.mixolasProfiles[name]=nil
    if db.mixolasWorkingProfile==name then db.mixolasWorkingProfile=nil end
    -- An alias must never redirect another character to a deleted profile.
    local aliases=db.mixolasProfileRenames or {}
    for alias,target in pairs(aliases) do
        if alias==name or target==name then aliases[alias]=nil end
    end
    if active then
        return true,"Deleted '"..name.."'. Now using the protected MIXOLAS default."
    end
    return true,"Deleted profile '"..name.."'."
end
api.RestoreLayoutSnapshot=function(which)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local char=api.GetCharacterDB()
    local snap=char and char.layoutSnapshots and char.layoutSnapshots[which]
    if not snap or type(snap.layout)~="table" then return false,"Restore point not found." end
    local config=clone(snap)
    local previousLayout=settingsCopy()
    local previousBindings=bindingsCopy()
    local previousActions=clone(char.customActions or {})
    applyingProfile=true
    local ok,why=restoreLayout(config.layout)
    if not ok then applyingProfile=false;return false,why or "Cannot restore layout." end
    local stored=api.SetCharacterBindings and api.SetCharacterBindings(clone(config.bindings or {}))
    if not stored then
        pcall(function() restoreLayout(previousLayout) end)
        applyingProfile=false
        return false,"Could not restore saved Mixolas bindings. Layout rolled back."
    end
    if config.nativeBindings then
        local restored,reason=api.RestoreNativeBindings(config.nativeBindings)
        if not restored then
            pcall(function() api.SetCharacterBindings(previousBindings) end)
            pcall(function() restoreLayout(previousLayout) end)
            applyingProfile=false
            return false,"Native shortcuts could not be restored: "..tostring(reason)..
                ". Previous layout and Mixolas keys restored."
        end
    end
    char.customActions=clone(config.customActions or {})
    api.GetDB().customActions=char.customActions
    if api.RefreshCustomActions then api.RefreshCustomActions() end
    if api.ApplyBindings then api.ApplyBindings() end
    if api.RefreshIcons then api.RefreshIcons() end
    if api.RefreshRegularActionIcons then api.RefreshRegularActionIcons() end
    applyingProfile=false
    rememberCharacterLayout()
    return true,"Restored Mixolas layout, extra actions and saved keys. Native WoW shortcuts were restored when present; spell slots untouched."
end
-- Non-intrusive snapshot when beginning a layout edit. Important: capture
-- BEFORE the user starts dragging, so Restore truly returns to prior positions.
local originalChange=api.Change
api.Change=function(key,value)
    if key=="locked" and value==false and api.GetDB() and api.GetDB().locked then
        api.TakeLayoutSnapshot("Before unlocking layout")
    end
    local ok=originalChange(key,value)
    if ok then rememberCharacterLayout() end
    return ok
end
-- Every EXPLICIT selection of MIXOLAS creates a fresh editable personal
-- copy, per the user-facing confirmation. The first fresh install instead
-- starts in the read-only MIXOLAS default; only edits fork automatically.
api.GetBuiltInPresetTarget=function()
    local db=activeDB()
    return db and newPersonalName(db) or nil,true
end
api.ApplyBuiltInPreset=function()
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local preset=builtin()
    if not preset then return false,"Built-in MIXOLAS preset unavailable." end
    local db=activeDB()
    local char=api.GetCharacterDB()
    if not char or not db then return false,"Character settings unavailable." end
    local name=newPersonalName(db)
    if not name or (#listNames()-(builtin() and 1 or 0))>=MAX_PROFILES then
        return false,"Profile library full; delete an unused personal profile first."
    end
    local oldNative=nativeCopy()
    if not oldNative then return false,"Could not capture existing native WoW keybindings." end
    rememberCharacterLayout()
    if api.TakeLayoutSnapshot and not api.TakeLayoutSnapshot("Before applying MIXOLAS preset") then
        return false,"Could not save a backup; nothing changed."
    end
    db.mixolasProfiles[name]={version=4,layout=clone(preset.layout),
        bindings=clone(preset.bindings),nativeBindings=clone(preset.nativeBindings),
        builtInSource=BUILTIN_NAME,saved="New editable MIXOLAS copy"}
    skipCurrentSaveOnce=true
    local ok,why=api.LoadNamedProfile(name,true)
    if not ok then
        db.mixolasProfiles[name]=nil
        if api.RestoreNativeBindings then pcall(api.RestoreNativeBindings,oldNative) end
        skipCurrentSaveOnce=false
        return false,"Could not apply MIXOLAS: "..tostring(why)
    end
    -- Appearance effects from the authored preset accompany its layout.
    applyBuiltInAppearance(preset)
    return true,"Created editable '"..name.."' from MIXOLAS. Rename or delete it freely. The built-in original remains unchanged."
end
api.SwitchNamedProfile=function(name)
    if name==BUILTIN_NAME then return false,"Selecting MIXOLAS opens confirmation to create a new editable personal profile." end
    if name==api.GetActiveProfileName() then return true,"Already using '"..name.."'. Edits save automatically." end
    return api.LoadNamedProfile(name)
end
api.CopyNamedProfile=function(source)
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local db=activeDB()
    local sourceData=source==BUILTIN_NAME and builtin() or db.mixolasProfiles[source]
    local dest=api.GetActiveProfileName()
    if not dest or not db.mixolasProfiles[dest] then return false,"Select a profile first." end
    if dest==BUILTIN_NAME then return false,"The built-in MIXOLAS preset cannot be overwritten." end
    if not sourceData or type(sourceData.layout)~="table" then return false,"Source profile not found." end
    if source==dest then return false,"Choose a different source profile." end
    rememberCharacterLayout()
    api.TakeLayoutSnapshot("Before copying from: "..source)
    local prior=clone(db.mixolasProfiles[dest])
    db.mixolasProfiles[dest]={version=sourceData.nativeBindings and 4 or 3,
        layout=clone(sourceData.layout),bindings=clone(sourceData.bindings or {}),
        nativeBindings=clone(sourceData.nativeBindings),saved="Copied from "..source}
    -- The destination was just overwritten intentionally. Do not let the
    -- old live layout auto-save over the copied data during the switch.
    skipCurrentSaveOnce=true
    local ok,reason=api.LoadNamedProfile(dest,true)
    if not ok then db.mixolasProfiles[dest]=prior;return false,reason end
    return true,"Copied '"..source.."' into '"..dest.."'. Changes save automatically."
end
api.ResetActiveProfile=function()
    if api.IsInCombat() or not api.IsReady() then return false,"Available outside combat." end
    local db=activeDB()
    local name=api.GetActiveProfileName()
    if name==BUILTIN_NAME then return false,"The built-in MIXOLAS preset cannot be reset." end
    if not name or not db.mixolasProfiles[name] then return false,"No active profile." end
    -- Preserve an undo restore point before the reset.
    api.TakeLayoutSnapshot("Before resetting: "..name)
    -- The addon Reset method restores its built-in defaults. We then save
    -- those defaults as the selected profile, not into another profile.
    local reset=api.Reset
    if type(reset)~="function" then return false,"Reset unavailable." end
    local ok,result=pcall(reset)
    if not ok or result==false then return false,"Reset was rejected." end
    rememberCharacterLayout()
    return true,"Reset profile '"..name.."' to default layout."
end
local function uniqueCharacterProfileName(db)
    local full=(UnitName and UnitName("player") or "Character")
    local realm=(GetRealmName and GetRealmName() or "")
    local base=(full..(realm~="" and " - "..realm or "")):sub(1,28)
    if base=="" then base="Character" end
    local name=base
    for i=2,99 do
        if not db.mixolasProfiles[name] then return name end
        name=(base:sub(1,27).." "..i):sub(1,32)
    end
    return nil
end
local login=CreateFrame("Frame")
login:RegisterEvent("PLAYER_LOGIN")
login:RegisterEvent("PLAYER_LOGOUT")
login:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGOUT" then
        rememberCharacterLayout()
        return
    end
    -- Account settings may still show another character until restore ends.
    profileAutosaveReady=false
    local char=api.GetCharacterDB()
    local db=activeDB()
    if not char or not db then return end
    -- Preserve pre-v3 character working layouts. Legacy profiles were manual
    -- snapshots; never silently overwrite them while upgrading.
    if not char.profileSystemV3 then
        local hadLegacyProfile=char.activeLayoutProfile~=nil or char.activeVisualLayout~=nil
        local former=char.activeLayoutProfile and db.mixolasProfiles[char.activeLayoutProfile]
        local working=char.activeVisualLayout
        local oldDifferent=false
        -- Compare WORKING to former profile, not the current account DB that
        -- might still be showing the previous character's layout.
        if former and type(working)=="table" then
            oldDifferent=false
            for _,key in ipairs(FIELDS) do
                if key~="locked" and not equal(working[key],former.layout[key]) then oldDifferent=true;break end
            end
            if type(former.bindings)=="table" and not equal(bindingsCopy(),former.bindings) then oldDifferent=true end
        end
        if oldDifferent or (not former and hadLegacyProfile) then
            local backup=uniqueCharacterProfileName(db)
            if backup then
                local layout=type(working)=="table" and clone(working) or settingsCopy()
                local native=nativeCopy()
                db.mixolasProfiles[backup]={version=native and 4 or 3,layout=layout,
                    bindings=bindingsCopy(),nativeBindings=native,
                    saved="Recovered character working layout"}
                char.activeLayoutProfile=backup
            end
        end
        char.profileSystemV3=true
    end
    local selected=char.activeLayoutProfile
    -- Shared profiles may have been renamed on another character. Follow
    -- stored aliases only when the old name no longer exists.
    if selected and not db.mixolasProfiles[selected] then
        local seen={}
        local nextName=selected
        local aliases=db.mixolasProfileRenames or {}
        while nextName and not seen[nextName] and not db.mixolasProfiles[nextName] do
            seen[nextName]=true
            nextName=aliases[nextName]
        end
        if nextName and db.mixolasProfiles[nextName] then
            selected=nextName
            char.activeLayoutProfile=nextName
        end
    end
    if not selected or (selected~=BUILTIN_NAME and not db.mixolasProfiles[selected]) then
        selected=BUILTIN_NAME
        char.activeLayoutProfile=BUILTIN_NAME
    end
    if selected==BUILTIN_NAME then
        -- Fresh installs boot into MIXOLAS visuals and Mixolas bindings.
        -- Never silently replace Blizzard's native keybindings at login.
        local ok,why=api.SelectBuiltInDefault(true)
        if not ok and api.Say then api.Say("Default MIXOLAS restore failed: "..tostring(why)) end
    elseif db.mixolasProfiles[selected] then
        local ok,why=api.LoadNamedProfile(selected,true)
        if not ok and api.Say then api.Say("Profile restore failed: "..tostring(why)) end
    end
    profileAutosaveReady=true
end)

-- WoW emits UPDATE_BINDINGS for *individual* SetBinding operations, as well
-- as SaveBindings. Coalesce the event until the following frame so a multi-key
-- reassignment (including Mixolas Save & Exit) cannot snapshot half a change.
-- A profile load emits those same events: never interpret its own restores
-- as edits to the newly selected profile.
local nativeEvents=CreateFrame("Frame")
local nativeChangePending=nil
local function flushNativeChange()
    local name=nativeChangePending
    if not name then return end
    if not profileAutosaveReady or applyingProfile or not api.IsReady()
        or (api.IsBindingMode and api.IsBindingMode()) then return end
    nativeChangePending=nil
    local db=activeDB()
    local char=api.GetCharacterDB()
    if not char or char.activeLayoutProfile~=name then return end
    local profile=db and db.mixolasProfiles[name]
    if name==BUILTIN_NAME then
        local ok,why=forkBuiltInIfChanged(true)
        if not ok then
            if api.Say then api.Say(why) end
            return
        end
        name=char.activeLayoutProfile
        profile=db and db.mixolasProfiles[name]
    end
    if profile and name~=BUILTIN_NAME then
        local ok,why=saveLiveNative(profile)
        if not ok and api.Say then api.Say("Could not auto-save WoW keys: "..tostring(why)) end
    end
end
nativeEvents:RegisterEvent("UPDATE_BINDINGS")
nativeEvents:SetScript("OnEvent",function()
    if not profileAutosaveReady or applyingProfile or not api.IsReady() then return end
    local char=api.GetCharacterDB()
    if char and char.activeLayoutProfile then
        nativeChangePending=char.activeLayoutProfile
    end
end)
nativeEvents:SetScript("OnUpdate",function()
    if nativeChangePending then flushNativeChange() end
end)
api.FlushPendingNativeProfileSave=flushNativeChange
