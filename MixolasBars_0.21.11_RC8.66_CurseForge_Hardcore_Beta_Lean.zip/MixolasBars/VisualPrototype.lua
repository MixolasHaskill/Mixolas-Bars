-- Mixolas Bars: Warlord-only appearance module, Classic Hardcore.
-- Isolated cosmetic module. Any visual API failure disables this experiment,
-- never the action bar addon. No secure attributes, click handlers, bindings,
-- cooldowns, or action slots are changed here.

local PREFIX = '|cff65baffMixolas Bars|r: '
local ROOT = 'Interface\\AddOns\\MixolasBars\\Media\\'
local glyphs = {} -- button -> array of textures we own
local plates = {} -- cluster -> larger Warlord armor silhouette; cosmetic only
local barHousings = {} -- regular action-bar parent -> Warlord housing textures
local active = {} -- indexed active clusters 1 through 8
local ready = false
local lastError = nil
local lastPhase = nil
local elapsed = 0
local smooth = {} -- independent color interpolation for each diamond
local previewPhase,previewUntil
local armorBursts = setmetatable({}, {__mode='k'})
local stage = CreateFrame('Frame')
local setPlate

local function announce(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. tostring(message))
    end
end

local function config()
    if type(MixolasBarsDB) ~= 'table' then return nil end
    local c = MixolasBarsDB.obsidianPrototype
    if type(c) ~= 'table' then
        c = { enabled = true, diamond = 1, scope = 'all', intensity = 0.20, frameOpacity = 1.0 }
        MixolasBarsDB.obsidianPrototype = c
    end
    -- One permanent Warlord identity. Old Obsidian profiles are migrated on
    -- access; the saved material is never allowed to override the current look.
    c.enabled = true
    c.theme = 'warlord'
    c.scope = 'all'
    -- hc8 default reduction: upgrade untouched hc7 defaults (0.50) to 0.20 once.
    -- Preserve values users intentionally customized to something else.
    -- The marker prevents the migration from repeatedly overriding a later 50% choice.
    if not c.hc8GlowDefaultMigrated then
        if c.intensity == nil or math.abs((tonumber(c.intensity) or 0.50) - 0.50) < 0.00001 then
            c.intensity = 0.20
        end
        c.hc8GlowDefaultMigrated = true
    end
    -- hc9 recalibration: the old 50% luminosity is the new 20%.
    -- Existing custom values retain approximately their prior appearance; the
    -- hc8 default of 20% becomes the new brighter 20% baseline intentionally.
    if not c.hc9GlowScaleMigrated then
        local previous = tonumber(c.intensity)
        if previous and math.abs(previous - 0.20) > 0.00001 then
            c.intensity = previous / 2.5
        end
        c.hc9GlowScaleMigrated = true
    end
    -- Both controls are appearance-only and saved with MixolasBarsDB.
    c.intensity = math.min(1, math.max(0, tonumber(c.intensity) or 0.20))
    c.frameOpacity = math.min(1, math.max(0, tonumber(c.frameOpacity) or 1.0))
    c.armorOpacity = math.min(1, math.max(0, tonumber(c.armorOpacity) or 0.92))
    c.armorGlow = math.min(1, math.max(0, tonumber(c.armorGlow) or 0.55))
    local index = tonumber(c.diamond) or 1
    if index < 1 or index > 8 then index = 1 end
    c.diamond = math.floor(index)
    -- Older hc5 users have only 'diamond': upgrade silently to all diamonds.
    if c.scope ~= 'single' then c.scope = 'all' end
    return c
end

local function hideAll()
    for _,regions in pairs(glyphs) do
        for _,region in ipairs(regions) do
            if region and region.Hide then region:Hide() end
        end
    end
    for _,plate in pairs(plates) do
        if type(plate) == "table" then
            for _,region in pairs(plate) do if region and region.Hide then region:Hide() end end
        elseif plate and plate.Hide then
            plate:Hide()
        end
    end
    for _,housing in pairs(barHousings) do
        if type(housing) == "table" then
            for _,region in pairs(housing) do if region and region.Hide then region:Hide() end end
        elseif housing and housing.Hide then
            housing:Hide()
        end
    end
    active = {}
    smooth = {}
end

-- Keep this operation deliberately simple. WoW's UI textures are client APIs:
-- validation in external Lua cannot guarantee they behave identically in Era.
local function addTexture(button, regions, name, layer, sublevel, blend, expand)
    local region = button:CreateTexture(nil, layer, nil, sublevel)
    regions[#regions + 1] = region -- record immediately for error-safe cleanup
    if expand then
        region:SetPoint('TOPLEFT', button, 'TOPLEFT', -4, 4)
        region:SetPoint('BOTTOMRIGHT', button, 'BOTTOMRIGHT', 4, -4)
    else
        region:SetAllPoints(button)
    end
    region:SetTexture(ROOT .. name)
    if blend then region:SetBlendMode(blend) end
    return region
end

local function ensure(button)
    if glyphs[button] then return end
    local t = {}
    glyphs[button] = t -- survive a partial texture creation failure
    -- No attempts to change existing FontString layers, secure button strata,
    -- or protected frame properties (hc3 did move text draw layers).
    t.face = addTexture(button, t, 'ObsidianFrame.tga', 'OVERLAY', 1)
    t.shine = addTexture(button, t, 'ObsidianShine.tga', 'OVERLAY', 2)
    t.channels = addTexture(button, t, 'ObsidianChannels.tga', 'OVERLAY', 3, 'ADD')
    t.halo = addTexture(button, t, 'ObsidianHalo.tga', 'OVERLAY', 0, 'ADD', true)
    t.prismRed = addTexture(button, t, 'ObsidianPrismRed.tga', 'OVERLAY', 3, 'ADD')
    t.prismGold = addTexture(button, t, 'ObsidianPrismGold.tga', 'OVERLAY', 3, 'ADD')
    t.prismBlue = addTexture(button, t, 'ObsidianPrismBlue.tga', 'OVERLAY', 3, 'ADD')
    -- The former 50% is now 20%. Beyond 40% we need extra additive
    -- texture passes: WoW clamps texture alpha to 1, and simply multiplying
    -- alpha would make the top of the slider look almost unchanged.
    for _, spec in ipairs({
        {'channels', 'ObsidianChannels.tga', 3, false},
        {'halo', 'ObsidianHalo.tga', 0, true},
        {'prismRed', 'ObsidianPrismRed.tga', 3, false},
        {'prismGold', 'ObsidianPrismGold.tga', 3, false},
        {'prismBlue', 'ObsidianPrismBlue.tga', 3, false},
    }) do
        local key, name, sublevel, expanded = unpack(spec)
        for pass = 2, 3 do
            local texture = addTexture(button, t, name, 'OVERLAY', sublevel, 'ADD', expanded)
            t[key .. pass] = texture
            texture:Hide()
        end
    end
    t.spark = addTexture(button, t, 'WarlordSparks.tga', 'OVERLAY', 4, 'ADD')
    t.spark:Hide()
    t._mixolasTheme = nil
    t.prismRed:Hide()
    t.prismGold:Hide()
    t.prismBlue:Hide()
end

-- All material changes affect textures owned by this visual module only.
-- Theme swap never touches secure button attributes, bindings, parent anchors,
-- icon regions or GCD frames. Classic Hardcore client and macOS share code.
local MATERIALS = {
    obsidian = {frame='ObsidianFrame.tga', shine='ObsidianShine.tga',
        channels='ObsidianChannels.tga', halo='ObsidianHalo.tga'},
    warlord = {frame='WarlordFrame.tga', shine='WarlordShine.tga',
        channels='WarlordChannels.tga', halo='WarlordHalo.tga'},
}
local function applyMaterial(t, theme)
    if t._mixolasTheme == theme then return end
    local m = MATERIALS[theme] or MATERIALS.obsidian
    t.face:SetTexture(ROOT..m.frame)
    t.shine:SetTexture(ROOT..m.shine)
    t.channels:SetTexture(ROOT..m.channels)
    t.halo:SetTexture(ROOT..m.halo)
    for pass=2,3 do
        t['channels'..pass]:SetTexture(ROOT..m.channels)
        t['halo'..pass]:SetTexture(ROOT..m.halo)
    end
    t._mixolasTheme=theme
end

-- Map displayed slider intensity onto light output. 20% equals the former
-- 50%; 40% equals former 100%; 100% requests former 250% light output.
-- Distribute additive alpha across up to three copies so overdrive still
-- increases brightness after an individual texture reaches alpha=1.
local GLOW_SCALE = 2.5
local function light(texture, second, third, r, g, b, alpha)
    local raw = math.max(0, alpha)
    texture:SetVertexColor(r, g, b, math.min(1, raw))
    if raw > 1 then
        second:SetVertexColor(r, g, b, math.min(1, raw - 1))
        second:Show()
    else
        second:Hide()
    end
    if raw > 2 then
        third:SetVertexColor(r, g, b, math.min(1, raw - 2))
        third:Show()
    else
        third:Hide()
    end
end

-- Diamond order follows the original Mixolas Bars modifier/color layout.
-- Illuminate ONLY when the exact modifier combination for the selected
-- diamond is held. E.g. Diamond 1 (Shift+Alt) must not react to Alt alone.
local DIAMOND_PHASES = {
    [1] = 'shiftalt',  -- green: Shift + Alt
    [2] = 'alt',       -- yellow: Alt
    [3] = 'ctrlalt',   -- orange: Ctrl + Alt
    [4] = 'shift',     -- blue: Shift
    [5] = 'idle',      -- white: no modifiers
    [6] = 'ctrl',      -- red: Ctrl
    [7] = 'shiftctrl', -- purple: Shift + Ctrl
    [8] = 'triple',    -- prismatic: Shift + Ctrl + Alt
}

local TONES = {
    shiftalt  = {0.27,1.00,0.49,0.77},
    alt       = {1.00,0.86,0.24,0.77},
    ctrlalt   = {1.00,0.55,0.17,0.77},
    shift     = {0.26,0.62,1.00,0.77},
    idle      = {0.94,0.95,1.00,0.77},
    ctrl      = {1.00,0.26,0.32,0.77},
    shiftctrl = {0.72,0.39,1.00,0.77},
    triple    = {0.94,0.95,1.00,0.90},
}

local function heldPhase()
    local shift = not not (IsShiftKeyDown and IsShiftKeyDown())
    local ctrl = not not (IsControlKeyDown and IsControlKeyDown())
    local alt = not not (IsAltKeyDown and IsAltKeyDown())
    if shift and ctrl and alt then return 'triple' end
    if shift and ctrl then return 'shiftctrl' end
    if shift and alt then return 'shiftalt' end
    if ctrl and alt then return 'ctrlalt' end
    if shift then return 'shift' end
    if ctrl then return 'ctrl' end
    if alt then return 'alt' end
    return 'idle'
end

-- Every diamond owns its own interpolation state and keeps its own idle tint.
-- Only the diamond matching the *exact* current chord receives the active glow.
local function modifierTone(index, current)
    local expected = DIAMOND_PHASES[index]
    if current == expected then
        local t = TONES[expected]
        return true, t[1], t[2], t[3], t[4]
    end
    local colors = MixolasBarsDB and MixolasBarsDB.colors
    local rgb = type(colors) == 'table' and colors[index]
    local r = type(rgb) == 'table' and tonumber(rgb[1]) or 0.80
    local g = type(rgb) == 'table' and tonumber(rgb[2]) or 0.84
    local b = type(rgb) == 'table' and tonumber(rgb[3]) or 0.90
    return false, r,g,b,0.24
end

-- Retire the old bulky "Existing" plate/housing artwork entirely. The
-- Frames tab owns the new attached housings. Per-button material and glow
-- layers are preserved; neither geometry nor secure behavior changes.
local function legacyHousing(key)
    return false
end

local function repaint(dt)
    local c = config()
    if not c or not c.enabled then return end
    local phase = heldPhase()
    local now = GetTime and GetTime() or 0
    if previewPhase then
        if now < (previewUntil or 0) then phase = previewPhase
        else previewPhase = nil end
    end
    local intensity = c.intensity * GLOW_SCALE
    local frameOpacity = c.frameOpacity
    local warlord = c.theme == "warlord"
    local weight = math.min(1, math.max(0, dt or 0.05) * 13)
    local pulse = 0.95 + 0.05 * math.sin(GetTime() * 4.5)
    for index = 1, 8 do
        local cluster = active[index]
        if cluster and cluster.buttons and (not cluster.IsShown or cluster:IsShown()) then
            if warlord and legacyHousing('d'..index) then setPlate(cluster,true,frameOpacity) else setPlate(cluster,false,frameOpacity) end
            local lit, r,g,b,a = modifierTone(index, phase)
            local v = smooth[index]
            if not v then
                v = {r=r,g=g,b=b,a=a}
                smooth[index] = v
            end
            v.r = v.r + (r - v.r) * weight
            v.g = v.g + (g - v.g) * weight
            v.b = v.b + (b - v.b) * weight
            v.a = v.a + (a - v.a) * weight
            local plate = plates[cluster]
            if plate then
                plate.base:SetVertexColor(1,1,1,c.armorOpacity)
                if warlord and legacyHousing('d'..index) then
                    local burst = armorBursts[cluster]
                    local impact = burst and math.max(0,1-(now - burst.at) / 0.38) or 0
                    if impact <= 0 then armorBursts[cluster]=nil end
                    local shellGlow = math.min(1,(0.20 + v.a * 0.78) * (lit and 1 or 0.55) * intensity * c.armorGlow * 2 + impact * 0.78)
                    local shellRim = math.min(1,(0.10 + v.a * 0.42) * (lit and pulse or 0.6) * intensity * c.armorGlow * 2 + impact * 0.80)
                    plate.glow:SetVertexColor(v.r,v.g,v.b,shellGlow)
                    plate.rim:SetVertexColor(v.r,v.g,v.b,shellRim)
                    plate.base:Show(); plate.glow:Show(); plate.rim:Show()
                else
                    plate.base:Hide(); plate.glow:Hide(); plate.rim:Hide()
                end
            end
            local triple = lit and phase == "triple"
            for _, button in ipairs(cluster.buttons) do
                local t = glyphs[button]
                if t then
                    if triple then
                        t.prismRed:Show(); t.prismGold:Show(); t.prismBlue:Show()
                        light(t.prismRed,t.prismRed2,t.prismRed3,1,0.23,0.27,0.92 * intensity)
                        light(t.prismGold,t.prismGold2,t.prismGold3,1,0.80,0.24,0.92 * intensity)
                        light(t.prismBlue,t.prismBlue2,t.prismBlue3,0.27,0.61,1,0.92 * intensity)
                    else
                        t.prismRed:Hide(); t.prismGold:Hide(); t.prismBlue:Hide()
                        t.prismRed2:Hide(); t.prismGold2:Hide(); t.prismBlue2:Hide()
                        t.prismRed3:Hide(); t.prismGold3:Hide(); t.prismBlue3:Hide()
                    end
                    local heat = (index == 3 or index == 6) and 1.13 or 1
                    local channelPower = (triple and 0.30 or (0.42 + 0.68 * v.a)) * intensity
                    if warlord then channelPower = channelPower * (lit and heat or 0.76) end
                    light(t.channels,t.channels2,t.channels3,v.r,v.g,v.b,channelPower)
                    local haloPower = v.a * (warlord and 0.55 or 0.68) * (lit and pulse or 1) * intensity
                    light(t.halo,t.halo2,t.halo3,v.r,v.g,v.b,haloPower)
                    if warlord and lit and intensity > 0 then
                        local flicker = 0.78 + 0.22*math.sin(GetTime()*8 + index*2)
                        t.spark:SetVertexColor(v.r,v.g,v.b,math.min(1,v.a*intensity*0.75*flicker))
                        t.spark:Show()
                    else
                        t.spark:Hide()
                    end
                    t.face:SetVertexColor(1,1,1,frameOpacity)
                    t.shine:SetVertexColor(1,1,1,(warlord and 0.90 or 0.64) * frameOpacity)
                end
            end
        end
    end
    local grouped = {}
    local regular = _G.MixolasBarsAPI and _G.MixolasBarsAPI.GetRegularButtons and _G.MixolasBarsAPI.GetRegularButtons() or nil
    if type(regular) == "table" then
        for _,button in ipairs(regular) do
            local barNo = button and button.barNumber
            if button and (barNo == 1 or barNo == 2) and (not button.IsVisible or button:IsVisible()) then
                local parent = button.GetParent and button:GetParent() or nil
                if parent then grouped[parent] = barNo end
                local t = glyphs[button]
                if t then
                    local br,bg,bb = 0.95,0.92,0.88
                    local ba = 0.22
                    if barNo == 1 then br,bg,bb,ba = 1.00,0.32,0.22,0.34 else br,bg,bb,ba = 1.00,0.64,0.22,0.24 end
                    local localPulse = 0.92 + 0.08*math.sin(GetTime()*3.7 + barNo)
                    light(t.channels,t.channels2,t.channels3,br,bg,bb,(0.18 + ba * 0.95) * intensity)
                    light(t.halo,t.halo2,t.halo3,br,bg,bb,(0.08 + ba * 0.45) * localPulse * intensity)
                    if warlord then
                        t.spark:SetVertexColor(br,bg,bb,math.min(1,0.20*intensity*localPulse))
                        t.spark:Show()
                    else
                        t.spark:Hide()
                    end
                    t.face:SetVertexColor(1,1,1,frameOpacity)
                    t.shine:SetVertexColor(1,1,1,(warlord and 0.86 or 0.62) * frameOpacity)
                end
            end
        end
    end
    for frame,barNo in pairs(grouped) do
        local housing = barHousings[frame]
        if housing then
            local r,g,b,a = 1.00,0.38,0.20,0.28
            if barNo == 2 then r,g,b,a = 1.00,0.65,0.22,0.22 end
            housing.base:SetVertexColor(1,1,1,c.armorOpacity)
            if warlord and legacyHousing('bar'..barNo) then
                housing.base:Show(); housing.glow:Show()
                local burst = armorBursts[frame]
                local impact = burst and math.max(0,1-(now - burst.at)/0.38) or 0
                if impact <= 0 then armorBursts[frame]=nil end
                local col = burst and burst.color or nil
                housing.glow:SetVertexColor(col and col[1] or r,col and col[2] or g,col and col[3] or b,
                    math.min(1,(0.16 + a * 0.95) * intensity * c.armorGlow * 2 + impact*0.86))
            else
                housing.base:Hide(); housing.glow:Hide()
            end
        end
    end
end

-- A diamond is a four-button unit, not four unrelated squares. Forged
-- Warlord plating fills the silhouette around the buttons, behind spell icons.
-- Texture regions cannot intercept input and do not alter secure frame state.
setPlate = function(cluster, on, opacity)
    local plate=plates[cluster]
    if not plate and on then
        plate={}
        plate.base=cluster:CreateTexture(nil,"BACKGROUND",nil,0)
        plate.base:SetPoint("TOPLEFT",cluster,"TOPLEFT",-8,8)
        plate.base:SetPoint("BOTTOMRIGHT",cluster,"BOTTOMRIGHT",8,-8)
        plate.base:SetTexture(ROOT.."WarlordDiamondPlate.tga")
        plate.glow=cluster:CreateTexture(nil,"BACKGROUND",nil,1)
        plate.glow:SetPoint("TOPLEFT",cluster,"TOPLEFT",-10,10)
        plate.glow:SetPoint("BOTTOMRIGHT",cluster,"BOTTOMRIGHT",10,-10)
        plate.glow:SetTexture(ROOT.."WarlordArmorChannels.tga")
        plate.glow:SetBlendMode("ADD")
        plate.rim=cluster:CreateTexture(nil,"OVERLAY",nil,-1)
        plate.rim:SetPoint("TOPLEFT",cluster,"TOPLEFT",-12,12)
        plate.rim:SetPoint("BOTTOMRIGHT",cluster,"BOTTOMRIGHT",12,-12)
        plate.rim:SetTexture(ROOT.."WarlordDiamondPlate.tga")
        plate.rim:SetBlendMode("ADD")
        plates[cluster]=plate
    end
    if plate then
        if on then
            plate.base:SetVertexColor(1,1,1,math.min(1,math.max(0,opacity or 1)))
            plate.base:Show(); plate.glow:Show(); plate.rim:Show()
        else
            plate.base:Hide(); plate.glow:Hide(); plate.rim:Hide()
        end
    end
end

local function setBarHousing(frame, on, opacity)
    local housing=barHousings[frame]
    if not housing and on then
        housing={}
        housing.base=frame:CreateTexture(nil,"BACKGROUND",nil,-2)
        housing.base:SetPoint("TOPLEFT",frame,"TOPLEFT",-10,10)
        housing.base:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",10,-10)
        housing.base:SetTexture(ROOT.."WarlordBarHousing.tga")
        housing.glow=frame:CreateTexture(nil,"BACKGROUND",nil,-1)
        housing.glow:SetPoint("TOPLEFT",frame,"TOPLEFT",-12,12)
        housing.glow:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",12,-12)
        housing.glow:SetTexture(ROOT.."WarlordBarHousingGlow.tga")
        housing.glow:SetBlendMode("ADD")
        barHousings[frame]=housing
    end
    if housing then
        if on then
            housing.base:SetVertexColor(1,1,1,math.min(1,math.max(0,opacity or 1)))
            housing.base:Show(); housing.glow:Show()
        else
            housing.base:Hide(); housing.glow:Hide()
        end
    end
end

local function render()
    if InCombatLockdown and InCombatLockdown() then return false end
    local c = config()
    if not c then return false end
    local api = _G.MixolasBarsAPI
    if not api or not api.GetClusters then return false end
    if api.IsReady and not api.IsReady() then return false end
    local clusters = api.GetClusters()
    if type(clusters) ~= 'table' then return false end
    -- No partial install: wait until the action bar has created all diamonds.
    for index = 1, 8 do
        if not clusters[index] or type(clusters[index].buttons) ~= 'table' then
            return false
        end
    end
    hideAll()
    if c.enabled then
        for index = 1, 8 do
            if c.scope == 'all' or index == c.diamond then
                local cluster = clusters[index]
                active[index] = cluster
                setPlate(cluster,c.theme == 'warlord' and legacyHousing('d'..index),c.frameOpacity)
                for _,button in ipairs(cluster.buttons) do
                    ensure(button)
                    applyMaterial(glyphs[button], c.theme)
                    for _,region in ipairs(glyphs[button]) do region:Show() end
                    local group = glyphs[button]
                    group.prismRed:Hide(); group.prismGold:Hide(); group.prismBlue:Hide()
                    group.prismRed2:Hide(); group.prismGold2:Hide(); group.prismBlue2:Hide()
                    group.prismRed3:Hide(); group.prismGold3:Hide(); group.prismBlue3:Hide()
                end
            end
        end
        local regular = api.GetRegularButtons and api.GetRegularButtons() or nil
        if type(regular) == 'table' then
            for _,button in ipairs(regular) do
                if button and (button.barNumber == 1 or button.barNumber == 2) then
                    ensure(button)
                    applyMaterial(glyphs[button], c.theme)
                    for _,region in ipairs(glyphs[button]) do region:Show() end
                    local group = glyphs[button]
                    group.prismRed:Hide(); group.prismGold:Hide(); group.prismBlue:Hide()
                    group.prismRed2:Hide(); group.prismGold2:Hide(); group.prismBlue2:Hide()
                    group.prismRed3:Hide(); group.prismGold3:Hide(); group.prismBlue3:Hide()
                    local parent = button.GetParent and button:GetParent() or nil
                    if parent then setBarHousing(parent,c.theme == 'warlord' and legacyHousing('bar'..button.barNumber),c.frameOpacity) end
                end
            end
        end
    end
    ready = true
    -- Initialize each diamond to its OWN color (no carryover from another).
    repaint(0.05)
    return true
end

local function onFailure(phase, err)
    lastError = tostring(phase) .. ': ' .. tostring(err)
    -- Disable the optional visual skin; leave all secure gameplay intact.
    local c = config()
    if c then c.enabled = false end
    pcall(hideAll)
    ready = true -- prevent an OnUpdate retry/error loop
    announce('|cffff6666Obsidian preview disabled after a visual error.|r')
    announce('Use /mxblookerror to see the error. Original action bars remain active.')
end

local function tryVisual(phase, func)
    local ok, value = pcall(func)
    if not ok then onFailure(phase, value); return false end
    if value == true then lastError = nil end
    return value
end

-- Legacy status command remains read-only; the appearance is now Warlord-only.
SLASH_MIXOLASLOOK1 = '/mxblook'
SlashCmdList.MIXOLASLOOK = function()
    local c=config()
    if not c then announce('Appearance not loaded yet.'); return end
    announce('Default appearance is active. Diamond Border Glow is in Diamonds > Border & Glow; Metal Finish Opacity is there too.')
end

SLASH_MIXOLASLOOKERROR1 = '/mxblookerror'
SlashCmdList.MIXOLASLOOKERROR = function()
    announce(lastError or 'No visual-prototype error recorded in this session.')
end

stage:RegisterEvent('PLAYER_LOGIN')
stage:RegisterEvent('PLAYER_ENTERING_WORLD')
stage:RegisterEvent('PLAYER_REGEN_ENABLED')
stage:SetScript('OnEvent', function()
    if not ready or not lastError then
        tryVisual('initialization / world load', render)
    end
end)
stage:SetScript('OnUpdate', function(_,dt)
    elapsed = elapsed + dt
    if elapsed < 0.05 then return end
    local period = elapsed
    elapsed = 0
    if lastError then return end -- never retry a failed skin automatically
    if not ready then
        tryVisual('delayed initialization', render)
        return
    end
    local c = MixolasBarsDB and MixolasBarsDB.obsidianPrototype
    if c and c.enabled then tryVisual('modifier repaint', function() repaint(period) end) end
end)

_G.MixolasBarsObsidian = {
    Apply = function() return tryVisual('external apply', render) end,
    GetSettings = function() return config() end,
    FlashArmor = function(button,index,strength)
        local c=config()
        if not c or not c.enabled or c.theme ~= 'warlord' then return false end
        local now=GetTime and GetTime() or 0
        local tones=TONES[DIAMOND_PHASES[index] or 'idle'] or TONES.idle
        local entry={at=now,color={tones[1],tones[2],tones[3]}}
        if button and button.barNumber and (button.barNumber==1 or button.barNumber==2) then
            local parent=button.GetParent and button:GetParent()
            if parent then armorBursts[parent]=entry; return true end
        end
        for _,cluster in pairs(active) do
            if cluster and cluster.buttons then
                for _,b in ipairs(cluster.buttons) do
                    if button==b then armorBursts[cluster]=entry; return true end
                end
            end
        end
        return false
    end,
    PreviewModifier = function(index,seconds)
        local phase = DIAMOND_PHASES[tonumber(index) or 0]
        if not phase then return false end
        previewPhase=phase
        previewUntil=(GetTime and GetTime() or 0)+math.min(12,math.max(1,tonumber(seconds) or 6))
        return tryVisual('modifier preview',function() repaint(0.08); return true end)
    end,
    SetArmorGlow = function(value)
        local c=config();local n=tonumber(value)
        if not c or not n then return false end
        c.armorGlow=math.max(0,math.min(1,n))
        return true
    end,
    SetArmorOpacity = function(value)
        local c=config();local n=tonumber(value)
        if not c or not n then return false end
        c.armorOpacity=math.max(0,math.min(1,n))
        return true
    end,
    SetIntensity = function(value)
        if InCombatLockdown and InCombatLockdown() then return false end
        local n = tonumber(value)
        if not n then return false end
        local c = config(); if not c then return false end
        c.intensity = math.min(1, math.max(0, n))
        -- No rebuild or secure frame mutation, just repaint owned textures.
        return tryVisual('glow intensity', function() repaint(0.05); return true end)
    end,
    SetFrameOpacity = function(value)
        if InCombatLockdown and InCombatLockdown() then return false end
        local n = tonumber(value)
        if not n then return false end
        local c = config(); if not c then return false end
        c.frameOpacity = math.min(1, math.max(0, n))
        return tryVisual('frame opacity', function() repaint(0.05); return true end)
    end,
    ResetAppearance = function()
        if InCombatLockdown and InCombatLockdown() then return false end
        local c = config(); if not c then return false end
        c.intensity = 0.20; c.frameOpacity = 1; c.armorOpacity=0.92; c.armorGlow=0.55; c.enabled = true; c.scope = 'all'
        return tryVisual('reset appearance', render)
    end,
    SetEnabled = function(enabled)
        if InCombatLockdown and InCombatLockdown() then return false end
        local c = config(); if not c then return false end
        c.enabled = not not enabled
        if c.enabled then c.scope = 'all' end
        return tryVisual('external enable', render)
    end,
    SetDiamond = function(index)
        index = tonumber(index)
        if not index or index < 1 or index > 8 then return false end
        if InCombatLockdown and InCombatLockdown() then return false end
        local c = config(); if not c then return false end
        c.diamond = math.floor(index); c.enabled = true; c.scope = 'single'
        return tryVisual('external diamond', render)
    end,
}
