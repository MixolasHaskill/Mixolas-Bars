-- Mixolas Bars RC8.25: clear ONLY Mixolas-owned action-button shortcuts.
-- A destructive action is exposed through two consecutive UI confirmations.
-- Never resets WoW spells, native WoW bindings, layouts or other profiles.
local api=_G.MixolasBarsAPI
if not api then return end
local function clone(src)
    local out={}
    for id,keys in pairs(src or {}) do
        if type(keys)=="table" then
            local list={}
            for i,k in ipairs(keys) do list[i]=k end
            out[id]=list
        end
    end
    return out
end
local function tally(map)
    local buttons,keys=0,0
    for _,list in pairs(map or {}) do
        if type(list)=="table" and #list>0 then
            buttons=buttons+1
            keys=keys+#list
        end
    end
    return buttons,keys
end
api.GetBarBindingClearStatus=function()
    local db=api.GetDB and api.GetDB()
    local char=api.GetCharacterDB and api.GetCharacterDB()
    local profile=api.GetActiveProfileName and api.GetActiveProfileName()
    local buttons,keys=tally((char and char.bindings) or (db and db.bindings) or {})
    return profile,buttons,keys
end
api.ClearAllBarKeybinds=function(expectedProfile)
    if not api.IsReady or not api.IsReady()
        or (api.IsInCombat and api.IsInCombat()) or (InCombatLockdown and InCombatLockdown()) then
        return false,"Clear All Bar Keybinds is unavailable during combat or before loading."
    end
    if api.IsBindingMode and api.IsBindingMode() then
        return false,"Exit mouseover binding mode before clearing shortcuts."
    end
    local profile,buttons,keys=api.GetBarBindingClearStatus()
    if not profile or profile=="" then return false,"Choose a named Mixolas profile first." end
    if expectedProfile~=profile then
        return false,"Active profile changed after confirmation; no keybindings were cleared."
    end
    if keys==0 then return false,"This profile has no Mixolas bar shortcuts to clear." end
    if not api.CanRecordUndo or not api.CanRecordUndo() or not api.RunBatchEdit then
        return false,"Undo history is not ready. No keybindings were cleared."
    end
    local char=api.GetCharacterDB()
    local db=api.GetDB()
    local old=clone((char and char.bindings) or (db and db.bindings) or {})
    local changed=false
    local message="Clear operation could not be completed."
    local success,err=pcall(function()
        api.RunBatchEdit("Clear All Bar Keybinds",function()
            if api.GetActiveProfileName()~=profile then
                message="Active profile changed; no changes applied."
                return false
            end
            if not api.SetCharacterBindings or not api.SetCharacterBindings({}) then
                message="Could not save the empty Mixolas keybinding map."
                return false
            end
            local routed,ok=pcall(api.ApplyBindings)
            if not routed or ok==false then
                local reverted=api.SetCharacterBindings(old)
                if api.ApplyBindings then pcall(api.ApplyBindings) end
                if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
                message=reverted and "Could not refresh bar key routing; original shortcuts restored."
                    or "Key routing failed and rollback was incomplete; restore your saved export."
                return false
            end
            if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
            changed=true
            return true
        end)
    end)
    if not success then
        -- Unexpected Lua errors are also rolled back to avoid partial clears.
        local reverted=api.SetCharacterBindings and api.SetCharacterBindings(old)
        if api.ApplyBindings then pcall(api.ApplyBindings) end
        if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
        return false,reverted and ("Clear failed; original shortcuts restored: "..tostring(err))
            or ("Clear failed and rollback may be incomplete: "..tostring(err))
    end
    if not changed then return false,message end
    return true,"Cleared "..keys.." Mixolas bar shortcuts from "..buttons.." buttons in profile '"..
        profile.."'. One Undo restores them. Native WoW keybindings were not changed."
end
