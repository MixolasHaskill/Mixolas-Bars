-- Classic Hardcore compatibility diagnostics (read-only).
SLASH_MIXOLASBARSHC1 = "/mxbhc"
SlashCmdList.MIXOLASBARSHC = function()
    local v,build,date,toc = GetBuildInfo()
    local isEra = WOW_PROJECT_ID and WOW_PROJECT_CLASSIC and WOW_PROJECT_ID == WOW_PROJECT_CLASSIC
    local api = _G.MixolasBarsAPI
    local clusters = api and api.GetClusters and api.GetClusters() or {}
    local regular = api and api.GetRegularButtons and api.GetRegularButtons() or {}
    local compat = _G.MixolasBarsCompat
    local function msg(s)
        if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff77c8ffMixolas Bars HC:|r "..s) end
    end
    msg("WoW "..tostring(v).." / build "..tostring(build).." / interface "..tostring(toc)
        .." / Classic Era "..tostring(not not isEra))
    msg("Modules: compat="..tostring(not not compat)..", ready="
        ..tostring(api and api.IsReady and api.IsReady())..", diamonds="..tostring(#clusters)
        ..", regular buttons="..tostring(#regular))
    local c=clusters[1] and clusters[1].buttons and clusters[1].buttons[1]
    if c then
        local slot=c.GetAttribute and c:GetAttribute("action") or c.actionSlot
        local has=compat and compat.ActionHas and compat.ActionHas(slot)
        msg("Diamond 1 first native slot="..tostring(slot).." hasAction="..tostring(has)
            .." (empty is normal until a spell is placed)")
    end
    msg("Use /mxb for settings; test changes out of combat on a safe character.")
end
