-- RC8.21: MXBA1 complete keybinding import (one click, one Undo step).
-- Parse both length-delimited MXB1/MXBN1 segments before changing anything.
-- Keeps native & Mixolas binding changes isolated to the active profile.
local api=_G.MixolasBarsAPI
if not api then return end
local MAX_ALL=60000
local function clone(v)
    if type(v)~='table' then return v end
    local r={}
    for k,x in pairs(v) do r[k]=clone(x) end
    return r
end
local function parse(raw)
    if type(raw)~='string' or #raw>MAX_ALL then return nil,'Invalid or overly long All Keybinds import.' end
    raw=raw:match('^%s*(.-)%s*$')
    local offset,barLen=raw:match('^()MXBA1;B=(%d+):')
    if not offset then return nil,'Expected an MXBA1 All Keybinds export.' end
    local header='MXBA1;B='..barLen..':'
    if #barLen>5 or tonumber(barLen)>16384 or tonumber(barLen)<4 then
        return nil,'Invalid MXB1 segment length.'
    end
    local barStart=#header+1
    local barEnd=barStart+tonumber(barLen)-1
    if barEnd>#raw then return nil,'Truncated MXB1 section.' end
    local bar=raw:sub(barStart,barEnd)
    if bar:sub(1,4)~='MXB1' then return nil,'Combined export has an invalid bar section.' end
    local tail=raw:sub(barEnd+1)
    local nativeLen=tail:match('^;N=(%d+):')
    if not nativeLen or #nativeLen>5 or tonumber(nativeLen)>MAX_ALL or tonumber(nativeLen)<5 then
        return nil,'Combined export has an invalid native section.'
    end
    local nativeHeader=';N='..nativeLen..':'
    local native=tail:sub(#nativeHeader+1)
    if #native~=tonumber(nativeLen) or native:sub(1,5)~='MXBN1' then
        return nil,'Combined export is truncated or contains trailing text.'
    end
    return {bar=bar,native=native}
end
local function eligible()
    if not api.IsReady or not api.IsReady() or (api.IsInCombat and api.IsInCombat())
        or (InCombatLockdown and InCombatLockdown()) then
        return nil,'Import is available only outside combat after loading.'
    end
    if api.IsBindingMode and api.IsBindingMode() then
        return nil,'Exit mouseover keybinding mode before importing.'
    end
    local name=api.GetActiveProfileName and api.GetActiveProfileName()
    if not name then return nil,'Select a named Mixolas profile first.' end
    return name
end
local function nativeOwnershipCheck(map,plan)
    -- Imported bar and native keys may share a key only if the native
    -- command owns that SAME action button (the documented inherited route).
    local known=api.GetNativeBindingCommands and api.GetNativeBindingCommands()
    if not known then return nil,'Native WoW binding API is unavailable.' end
    local target={}
    for key,command in pairs(plan.source.keys) do
        if known[command] then target[key]=command
        elseif plan.live.keys[key] then target[key]=plan.live.keys[key] end
    end
    for id,keys in pairs(map) do
        for _,key in ipairs(keys) do
            local command=target[key]
            if command then
                local owner=api.GetBindingTargetForImport and api.GetBindingTargetForImport(id)
                local allowed=owner and api.GetNativeBindingCommand and api.GetNativeBindingCommand(owner)
                if not allowed or command~=allowed then
                    return nil,'Conflict: '..key..' is assigned to native WoW command '..command..'. Adjust the source export before importing.'
                end
            end
        end
    end
    return target
end
api.ApplyAllBindingImport=function(raw)
    local profile,why=eligible()
    if not profile then return false,why end
    local parts,err=parse(raw)
    if not parts then return false,err end
    if not api.ParsePortableBarBindings or not api.PreviewNativeBindingImport
        or not api.SetCharacterBindings or not api.ApplyNativeBindingImport then
        return false,'Bar or native import services are unavailable.'
    end
    local barMap,barError=api.ParsePortableBarBindings(parts.bar)
    if not barMap then return false,'Bar import: '..tostring(barError) end
    local plan,nativeError=api.PreviewNativeBindingImport(parts.native)
    if not plan then return false,'Native import: '..tostring(nativeError) end
    if plan.profile~=profile then return false,'Profile changed during validation.' end
    local compatible,conflict=nativeOwnershipCheck(barMap,plan)
    if not compatible then return false,conflict end
    local db=api.GetDB and api.GetDB()
    local char=api.GetCharacterDB and api.GetCharacterDB()
    if not db or not char or not db.mixolasProfiles or not db.mixolasProfiles[profile] then
        return false,'The active profile is unavailable.'
    end
    local oldBar=clone(char.bindings or db.bindings or {})
    local oldNative=clone(plan.live)
    local oldProfile=clone(db.mixolasProfiles[profile])
    local nativeChanged=false
    local function rollback(message)
        local errors={}
        -- First free any imported overrides; then restore native keys and
        -- finally the old Mixolas map. Avoid leaving the current profile half-updated.
        if not api.SetCharacterBindings({}) then errors[#errors+1]='Could not clear temporary bar bindings' end
        if nativeChanged then
            local ok,reason=api.RestoreNativeBindings(oldNative)
            if not ok then errors[#errors+1]='Native rollback: '..tostring(reason) end
        end
        if not api.SetCharacterBindings(oldBar) then errors[#errors+1]='Bar rollback failed' end
        if api.ApplyBindings then pcall(api.ApplyBindings) end
        if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
        db.mixolasProfiles[profile]=clone(oldProfile)
        if #errors>0 then return false,'IMPORT FAILED; rollback incomplete: '..message..' / '..table.concat(errors,'; ') end
        return false,'Import cancelled; original bindings restored. '..message
    end
    -- Clear old custom overrides before replacing native shortcuts so the
    -- destination's previous bar keys cannot cause false import conflicts.
    if not api.SetCharacterBindings({}) then return rollback('Could not prepare bar bindings.') end
    -- Mark native restoration as needed even if the native writer reports
    -- a partial failure: rollback must attempt to restore the original set.
    nativeChanged=true
    local ok,nativeMessage=api.ApplyNativeBindingImport(parts.native)
    if not ok then
        return rollback('Native binding import failed: '..tostring(nativeMessage))
    end
    if not api.SetCharacterBindings(barMap) then
        return rollback('WoW rejected Mixolas bar assignments.')
    end
    local routed,reason=true,nil
    if api.ApplyBindings then
        routed,reason=pcall(api.ApplyBindings)
        if not routed or reason==false then return rollback('Mixolas routes could not be applied.') end
    end
    if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
    if api.GetActiveProfileName and api.GetActiveProfileName()~=profile then
        return rollback('Active profile changed during import.')
    end
    return true,'Imported All Keybinds to '..profile..' (Mixolas bars + native WoW shortcuts).'
end
