-- Mixolas Bars Classic Hardcore hc11: layout-only Steam Controller preset.
-- No secure action attributes, spell assignments, class pages or bindings change.
-- This module works identically on macOS and Windows WoW Classic clients.
local api = _G.MixolasBarsAPI
if not api then return end
local POSITION = {
    {-155,-10}, {0,-10}, {155,-10},
    {-155,-155}, {0,-155}, {155,-155},
}
local function apply()
    if not api.IsReady or not api.IsReady() or (api.IsInCombat and api.IsInCombat()) then
        if api.Say then api.Say('Apply the six-diamond layout outside combat.') end
        return false
    end
    local db = api.GetDB and api.GetDB()
    if not db then return false end
    -- Snapshot first so a pre-existing custom layout can be restored.
    if api.TakeLayoutSnapshot then
        local ok,saved = pcall(api.TakeLayoutSnapshot,'Before Steam Controller six-diamond layout')
        if not ok or saved == false then
            if api.Say then api.Say('Cannot create a restore point; layout was not changed.') end
            return false
        end
    end
    db.positions = db.positions or {}
    db.diamondEnabled = db.diamondEnabled or {}
    for i=1,6 do
        db.positions[i] = {POSITION[i][1],POSITION[i][2]}
        db.diamondEnabled[i] = true
    end
    -- Do not remove these abilities, mappings or action slots from the addon.
    db.diamondEnabled[7] = false
    db.diamondEnabled[8] = false
    db.regularBars = db.regularBars or {}
    for _,entry in ipairs({{number=2,x=-365},{number=1,x=365}}) do
        local c=db.regularBars[entry.number] or {}
        db.regularBars[entry.number] = c
        c.enabled=true
        c.count=12
        c.rows=4
        c.x=entry.x
        c.y=-83
        c.positionInitialized=true
        -- Preserve user scale, spacing, opacity and existing action assignments.
    end
    if api.Refresh then api.Refresh() end
    if api.RefreshRegularBars then api.RefreshRegularBars() end
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    if api.Say then
        api.Say('Six-diamond layout applied: Bar 2 LEFT / green-yellow-orange over blue-white-red / Bar 1 RIGHT. Diamonds 7-8 retained but hidden.')
    end
    return true
end
_G.MixolasBarsSixDiamondLayout={Apply=apply}
SLASH_MIXOLASLAYOUT6_1='/mxblayout6'
SlashCmdList['MIXOLASLAYOUT6']=function() apply() end
