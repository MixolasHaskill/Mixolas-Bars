-- Mixolas Bars 0.21.5: read-only diagnostic for unbound diamond cooldowns.
-- No secure-action attributes, bindings or cooldown values are changed.
local api = _G.MixolasBarsAPI
if not api then return end
local function announce(t)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage('|cff65baffMixolas Bars|r: '..tostring(t))
    end
end
local function numeric(v)
    if type(v) ~= 'number' then return nil end
    if issecretvalue then
        local ok,secret=pcall(issecretvalue,v)
        if not ok or secret then return nil end
    end
    return v
end
SLASH_MIXOLASDIAMONDCD1='/mxbdiamondcd'
SlashCmdList.MIXOLASDIAMONDCD=function(raw)
    if not api.IsReady or not api.IsReady() then announce('Bars not ready.'); return end
    local diamond,buttonIndex = tostring(raw or ''):match('^%s*(%d+)%s+(%d+)%s*$')
    diamond,buttonIndex=tonumber(diamond),tonumber(buttonIndex)
    if not diamond or diamond<1 or diamond>8 or not buttonIndex or buttonIndex<1 or buttonIndex>4 then
        announce('Usage: /mxbdiamondcd 1 1 (diamond number 1-8, spell position 1-4).')
        return
    end
    local clusters=api.GetClusters and api.GetClusters()
    local b=clusters and clusters[diamond] and clusters[diamond].buttons
       and clusters[diamond].buttons[buttonIndex]
    if not b then announce('No button exists for that position.');return end
    local action=b:GetAttribute('action') or b.actionSlot
    local kind,id='none','none'
    if action and GetActionInfo then
        local ok,a,c=pcall(GetActionInfo,action)
        if ok and type(a)=='string' then kind=a;id=tostring(c or 'unknown') end
    end
    local start,duration
    local compat=_G.MixolasBarsCompat
    if action and compat and compat.ActionCooldown then
        local ok,a,c=pcall(compat.ActionCooldown,action)
        if ok then start,duration=numeric(a),numeric(c) end
    end
    local seconds=(start and duration) and string.format('%.1fs / %.1fs',start,duration)
        or 'unreadable or unavailable'
    local widget=b.cooldown
    announce('Diamond '..diamond..', spell '..buttonIndex..' | native action '..tostring(action or '?')..' | '..kind..' '..id)
    announce('Start/duration: '..seconds..' | duration-object route: '..(b._mxbNativeCooldown and 'yes' or 'no')..' | swipe visible: '..(widget and widget:IsShown() and 'yes' or 'no'))
    announce('Hotkey not required. If this is missing after using an ability, share these two lines.')
end
