-- Mixolas Bars 0.20 RC: visual-only tuning, preview and read-only routing audit.
-- The editor never assigns spells or writes WoW's own keyboard bindings.
local api=_G.MixolasBarsAPI
if not api then return end
local bridge=_G.MixolasBarsObsidian
local flash=_G.MixolasBarsActivationFlash
local function tell(msg)
    if api.Say then api.Say(msg)
    elseif DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage('Mixolas Bars: '..tostring(msg)) end
end
local function forbidden()
    if not api.IsReady or not api.IsReady() or (api.IsInCombat and api.IsInCombat()) then
        tell('Edit geometry only out of combat, after login.')
        return true
    end
    return false
end
local function clamp(x,minimum,maximum)
    return math.max(minimum,math.min(maximum,tonumber(x) or minimum))
end
local function spacing(axis,value)
    if forbidden() then return false end
    local db=api.GetDB(); if not db then return false end
    if axis ~= 'ew' and axis ~= 'ns' then return false end
    local key = axis=='ew' and 'diamondGapEW' or 'diamondGapNS'
    local previous=db[key]
    db[key]=math.floor(clamp(value,0,24)+0.5)
    local ok,why=pcall(api.Refresh)
    if not ok or why==false then
        db[key]=previous
        pcall(api.Refresh)
        tell('Spacing change reverted after an error.')
        return false
    end
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return true
end
local function spreadColumns(spacingX,spacingY)
    if forbidden() then return false end
    local db=api.GetDB();if not db then return false end
    if api.TakeLayoutSnapshot and not api.TakeLayoutSnapshot('Before six-diamond spacing edit') then
        tell('Could not create a restore point; positions unchanged.')
        return false
    end
    db.positions=db.positions or {}
    local xs=155+clamp(spacingX,0,80)
    local ys=145+clamp(spacingY,0,80)
    for i=1,6 do
        local column=(i-1)%3-1
        local row=math.floor((i-1)/3)
        db.positions[i]={column*xs,-10-row*ys}
    end
    local ok,why=pcall(api.Refresh)
    if not ok or why==false then
        tell('Spacing layout refresh failed; restore the preceding layout snapshot.')
        return false
    end
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    tell('Applied six-diamond spacing to visible diamonds only; 7-8 untouched.')
    return true
end
local NAMES={'Green Shift+Alt','Yellow Alt','Orange Ctrl+Alt','Blue Shift','White None','Red Ctrl','Purple Shift+Ctrl','Prismatic Triple'}
local function preview(i)
    if not bridge or not bridge.PreviewModifier then return false end
    if not bridge.PreviewModifier(i,7) then return false end
    if flash and flash.PreviewBar1 then flash.PreviewBar1(1,i) end
    if flash and flash.PreviewBar then flash.PreviewBar(2,1,i) end
    tell('Preview '..NAMES[i]..' (7 seconds, no spells cast).')
    return true
end
local function keyReport()
    local lines={
        'MIXOLAS BARS | KEYBIND ROUTING AUDIT (read-only)',
        'WoW native bindings are never overwritten by this page.',
        'Bar 3/4/5 mirror buttons are omitted; each diamond owns those native action slots.',
        'Client routes marked CLIENT UNVERIFIED require an in-game key test.',
        '========================================================'
    }
    local db=api.GetDB and api.GetDB() or {}
    local char=api.GetCharacterDB and api.GetCharacterDB() or {}
    local saved=char.bindings or db.bindings or {}
    local routed=api.GetBindingRouteReport and api.GetBindingRouteReport() or {}
    local routes=routed.routes or {}
    local claimed={}
    local function collect(button,label)
        if not button then return end
        local slot=button.actionSlot
        local id=tostring(button.bindId or button.slot or '?')
        local native=api.GetNativeBindingCommand and api.GetNativeBindingCommand(button) or nil
        local clientKeys=api.GetNativeBindingKeys and api.GetNativeBindingKeys(button) or {}
        local localKeys=saved[id] or {}
        local nativeList,localList={},{}
        for _,key in ipairs(clientKeys) do
            if key and key~='' then nativeList[#nativeList+1]=key end
        end
        for _,key in ipairs(localKeys) do
            if key and key~='' then
                localList[#localList+1]=key
                claimed[key]=claimed[key] or {}
                claimed[key][#claimed[key]+1]=label
            end
        end
        local primary=(#localList>0 and localList[1]) or nativeList[1]
        local route=primary and routes[primary]
        local source=route and route.source or 'not routed'
        local status=route and (route.conflict and 'CONFLICT' or 'requested') or 'NOT ROUTED'
        if route and GetBindingAction then
            local ok,value=pcall(GetBindingAction,primary,true)
            if ok and type(value)=='string' and value~='' then
                if route.conflict then status='CONFLICT'
                elseif value:upper()==('CLICK '..tostring(route.button)..':LeftButton'):upper() then status='CLIENT VERIFIED'
                else status='CLIENT UNVERIFIED / '..value end
            end
        end
        lines[#lines+1]=string.format('%s | slot=%s | command=%s',label,tostring(slot or '?'),native or 'custom')
        lines[#lines+1]=string.format('  WoW: %s | Mixolas: %s | effective: %s | route: %s',
            table.concat(nativeList,', ')=='' and '-' or table.concat(nativeList,', '),
            table.concat(localList,', ')=='' and '-' or table.concat(localList,', '),source,status)
    end
    local reg=api.GetRegularButtons and api.GetRegularButtons() or {}
    for bar=1,2 do
        local selected={}
        for _,button in ipairs(reg) do
            if button.barNumber==bar then selected[button.barIndex]=button end
        end
        for n=1,12 do collect(selected[n],'BAR '..bar..' #'..n) end
    end
    local clusters=api.GetClusters and api.GetClusters() or {}
    for i=1,8 do
        local c=clusters[i]
        for j=1,4 do
            collect(c and c.buttons and c.buttons[j],
                'D'..i..' '..(i>=7 and '(hidden) ' or '')..'#'..j)
        end
    end
    for key,owners in pairs(claimed) do
        if #owners>1 then lines[#lines+1]='DUPLICATE custom '..key..' -> '..table.concat(owners,', ') end
    end
    lines[#lines+1]='Routes attempted: '..tostring(routed.attempted or 0)..
        '  Errors: '..tostring(#(routed.errors or {}))..
        '  Mismatches: '..tostring(#(routed.mismatches or {}))
    for _,err in ipairs(routed.errors or {}) do lines[#lines+1]='ROUTE ERROR: '..tostring(err) end
    for _,err in ipairs(routed.mismatches or {}) do lines[#lines+1]='ROUTE MISMATCH: '..tostring(err) end
    return table.concat(lines,'\n')
end
local function pageReport()
    local lines={'MIXOLAS BARS | READ-ONLY STANCE / FORM AUDIT'}
    local _,class=UnitClass and UnitClass('player')
    lines[#lines+1]='Class: '..tostring(class)
    local bonus=GetBonusBarOffset and GetBonusBarOffset() or 'unavailable'
    lines[#lines+1]='Bonus bar offset: '..tostring(bonus)
    local form=GetShapeshiftForm and GetShapeshiftForm() or 0
    lines[#lines+1]='Form index: '..tostring(form)
    if GetNumShapeshiftForms and GetShapeshiftFormInfo then
        for i=1,GetNumShapeshiftForms() do
            local _,name,active,castable=GetShapeshiftFormInfo(i)
            lines[#lines+1]='Form '..i..' = '..tostring(name)..' / active '..tostring(active)..' / castable '..tostring(castable)
        end
    end
    local reg=api.GetRegularButtons and api.GetRegularButtons() or {}
    for _,b in ipairs(reg) do
        if b.barNumber==1 then
            local ok,a=pcall(function() return b:GetAttribute('action') end)
            lines[#lines+1]='Main '..tostring(b.barIndex)..' actual slot: '..(ok and tostring(a) or 'client protected/unknown')
        end
    end
    if api.ValidateActionOwnership then
        local ok,result=pcall(api.ValidateActionOwnership)
        if ok then lines[#lines+1]=tostring(result) end
    end
    lines[#lines+1]='These observations do not simulate protected in-combat stance transitions.'
    return table.concat(lines,'\n')
end
local dialog,output
local function makePanel()
    if dialog then return dialog end
    local template=BackdropTemplateMixin and 'BackdropTemplate' or nil
    local f=CreateFrame('Frame','MixolasBarsAdvancedTools',UIParent,template)
    f:SetSize(720,725);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG')
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(self) self:StartMoving() end)
    f:SetScript('OnDragStop',function(self) self:StopMovingOrSizing() end)
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',edgeSize=24, insets={left=8,right=8,top=8,bottom=8}})
    end
    local title=f:CreateFontString(nil,'OVERLAY','GameFontNormalLarge')
    title:SetPoint('TOPLEFT',f,'TOPLEFT',25,-20);title:SetText('MIXOLAS BARS | DEVELOPER TOOLS')
    local close=CreateFrame('Button',nil,f,'UIPanelCloseButton');close:SetPoint('TOPRIGHT',-4,-4)
    local function btn(label,x,y,w,fn)
        local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate')
        b:SetSize(w or 130,25);b:SetPoint('TOPLEFT',f,'TOPLEFT',x,y)
        b:SetText(label);b:SetScript('OnClick',fn);return b
    end
    local function line(label,x,y)
        local t=f:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
        t:SetPoint('TOPLEFT',f,'TOPLEFT',x,y);t:SetText(label);return t
    end
    local db=api.GetDB() or {}
    local sliders={}
    local function slide(key,label,x,y,min,max,default,fn)
        line(label,x,y)
        local s=CreateFrame('Slider',nil,f,'OptionsSliderTemplate')
        s:SetPoint('TOPLEFT',f,'TOPLEFT',x,y-27)
        s:SetSize(250,16);s:SetOrientation('HORIZONTAL');s:EnableMouse(true);s:SetMinMaxValues(min,max);s:SetValueStep(1)
        if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
        local entry=CreateFrame('EditBox',nil,f,'InputBoxTemplate')
        entry:SetAutoFocus(false); entry:SetSize(62,23);entry:SetMaxLetters(12)
        entry:SetJustifyH('CENTER')
        entry:SetPoint('LEFT',s,'RIGHT',12,0)
        local suffix=(key=='armorOpacity' or key=='armorGlow') and '%' or ''
        local function sync()
            if not entry:HasFocus() then entry:SetText(math.floor(s:GetValue()+0.5)..suffix) end
        end
        local applying = false
        local historyForDrag=false
        local historyOwner="developer:"..key
        local function beginDragHistory()
            if historyForDrag or not api.BeginContinuousEdit then return end
            historyForDrag=api.BeginContinuousEdit('Adjust developer slider '..key,historyOwner)==true
        end
        local function endDragHistory()
            if historyForDrag and api.EndContinuousEdit then api.EndContinuousEdit(historyOwner) end
            historyForDrag=false
        end
        local function applyValue(v)
            v=math.max(min,math.min(max,math.floor(v+0.5)))
            if v == default then return true end
            if forbidden() or not fn(v) then
                applying = true; s:SetValue(default); applying = false
                sync()
                return false
            end
            default=v
            return true
        end
        s:SetValue(default)
        sync()
        -- Apply while the thumb moves, not only on mouse-up. A release over an
        -- adjacent value EditBox can otherwise leave the displayed value unsaved.
        s:SetScript('OnValueChanged',function(self,v,userInput)
            if applying then return end
            sync()
            if userInput or (type(IsMouseButtonDown)=='function' and IsMouseButtonDown('LeftButton')) then
                beginDragHistory()
                applyValue(v)
            end
        end)
        -- Do not overwrite a template's internal OnMouseUp handler.
        if s.HookScript then
            s:HookScript('OnMouseUp',function(self)
                if not applying then applyValue(self:GetValue());sync() end
                endDragHistory()
            end)
        end
        -- Same pointer-driven slider used by the main settings window.
        -- This also handles clients that fail to deliver native Slider drag
        -- callbacks when a neighboring text field is present.
        local pointer=CreateFrame('Frame',nil,s)
        pointer:SetAllPoints(s)
        pointer:SetFrameLevel(s:GetFrameLevel()+3)
        pointer:EnableMouse(true)
        local pointerActive=false
        local function fromCursor()
            if not pointerActive or not s:IsEnabled() or type(GetCursorPosition)~='function' then return end
            local left,widthPx,scale=s:GetLeft(),s:GetWidth(),s:GetEffectiveScale()
            if not left or not widthPx or widthPx<=16 or not scale or scale<=0 then return end
            local x=GetCursorPosition()
            local f=math.max(0,math.min(1,(x/scale-left-8)/(widthPx-16)))
            local value=math.max(min,math.min(max,math.floor(min+f*(max-min)+0.5)))
            if math.abs((s:GetValue() or min)-value)<0.0001 then return end
            applying=true; s:SetValue(value); applying=false
            sync()
            applyValue(value)
        end
        pointer:SetScript('OnMouseDown',function(self,buttonName)
            if buttonName~='LeftButton' or not s:IsEnabled() or forbidden() then return end
            if entry:HasFocus() then entry:ClearFocus() end
            -- Start a new transaction for each mouse press, even if an old
            -- release was dropped by the client.
            if historyForDrag then endDragHistory() end
            pointerActive=true
            beginDragHistory()
            fromCursor()
        end)
        pointer:SetScript('OnMouseUp',function(self,buttonName)
            if buttonName=='LeftButton' then
                if pointerActive then fromCursor() end
                pointerActive=false
                endDragHistory()
            end
        end)
        pointer:SetScript('OnUpdate',function()
            if not pointerActive then return end
            if type(IsMouseButtonDown)=='function' and not IsMouseButtonDown('LeftButton') then
                pointerActive=false;sync();endDragHistory()
            else
                fromCursor()
            end
        end)
        pointer:SetScript('OnHide',function() pointerActive=false;endDragHistory() end)
        entry:SetScript('OnEditFocusGained',function(self)self:HighlightText() end)
        entry:SetScript('OnEditFocusLost',function()sync()end)
        entry:SetScript('OnEscapePressed',function(self)self:ClearFocus();sync()end)
        entry:SetScript('OnEnterPressed',function(self)
            local text=self:GetText():gsub('^%s+',''):gsub('%s+$',''):gsub('%%$','')
            local valid=text:match('^[+-]?%d+%.?%d*$') or text:match('^[+-]?%d*%.%d+$')
            local v=valid and tonumber(text) or nil
            self:ClearFocus()
            if v then
                if applyValue(v) then
                    applying=true; s:SetValue(default); applying=false
                end
            end
            s:SetValue(default);sync()
        end)
        sliders[key]=s
    end
    slide('ew','East / West icon gap (0 = touch)',28,-70,0,24,db.diamondGapEW or db.gap or 3,function(n) return spacing('ew',n) end)
    slide('ns','North / South icon gap',375,-70,0,24,db.diamondGapNS or db.gap or 3,function(n) return spacing('ns',n) end)
    local theme=bridge and bridge.GetSettings and bridge.GetSettings() or {}
    slide('armorGlow','Armor illumination (%)',28,-159,0,100,math.floor((theme.armorGlow or .55)*100),function(n) return bridge and bridge.SetArmorGlow and bridge.SetArmorGlow(n/100) end)
    slide('armorOpacity','Armor opacity (%)',375,-159,0,100,math.floor((theme.armorOpacity or .92)*100),function(n) return bridge and bridge.SetArmorOpacity and bridge.SetArmorOpacity(n/100) end)
    local extraX,extraY=0,0
    slide('gridX','Extra distance between diamond columns (px)',28,-247,0,80,0,function(n) extraX=n;return true end)
    slide('gridY','Extra distance between diamond rows (px)',375,-247,0,80,0,function(n) extraY=n;return true end)
    line('Modifier preview: temporarily illuminate a diamond and Bar 1/2 without casting.',28,-329)
    for i=1,8 do
        btn(tostring(i)..' '..(NAMES[i]:match('^(%S+)') or ''),22+(i-1)%4*172,-355-math.floor((i-1)/4)*32,163,function() preview(i) end)
    end
    btn('Binding audit',25,-437,153,function() output:SetText(keyReport()); output:SetCursorPosition(0) end)
    btn('Stance / form audit',186,-437,160,function() output:SetText(pageReport()); output:SetCursorPosition(0) end)
    btn('Apply 6-diamond spacing',353,-437,172,function()
        if spreadColumns(extraX,extraY) then tell('Applied 2x3 grid with custom spacing and a saved undo snapshot.') end
    end)
    line('Read-only report (click the text, Ctrl+A / Cmd+A, then copy).',28,-482)
    local scroll=CreateFrame('ScrollFrame',nil,f,'UIPanelScrollFrameTemplate')
    scroll:SetPoint('TOPLEFT',f,'TOPLEFT',25,-505)
    scroll:SetSize(644,193)
    output=CreateFrame('EditBox',nil,scroll)
    output:SetMultiLine(true);output:SetAutoFocus(false);output:SetFontObject('ChatFontNormal')
    output:SetWidth(620);output:SetHeight(1600);output:EnableMouse(true)
    output:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
    scroll:SetScrollChild(output)
    output:SetText(keyReport());output:SetCursorPosition(0)
    f:Hide();dialog=f
    if UISpecialFrames then table.insert(UISpecialFrames,'MixolasBarsAdvancedTools') end
    return f
end
local function show(report)
    local f=makePanel();f:Show()
    if report=='pages' then output:SetText(pageReport())
    elseif report=='keys' then output:SetText(keyReport()) end
end
_G.MixolasBarsAdvanced={Spacing=spacing, ApplyGrid=spreadColumns,Preview=preview,KeyReport=keyReport,PageReport=pageReport,Show=show}
SLASH_MXBADVANCED1='/mxbadvanced'
SlashCmdList.MXBADVANCED=function() show() end
SLASH_MXBDIAGNOSTICS1='/mxbdiag'
SlashCmdList.MXBDIAGNOSTICS=function() show('keys') end
SLASH_MXBPAGES1='/mxbpages'
SlashCmdList.MXBPAGES=function() show('pages') end
SLASH_MXBGEOMETRY1='/mxbgeometry'
SlashCmdList.MXBGEOMETRY=function(input)
    local axis,n=(input or ''):lower():match('^%s*(ew)%s+(%d+)%s*$')
    if not axis then axis,n=(input or ''):lower():match('^%s*(ns)%s+(%d+)%s*$') end
    if axis then
        if spacing(axis,tonumber(n)) then tell('Diamond '..axis..' gap now '..n..'px.') end
    else tell('Use /mxbgeometry ew 0 or /mxbgeometry ns 3; /mxbadvanced opens sliders.') end
end
SLASH_MXBPREVIEWPHASE1='/mxbpreview'
SlashCmdList.MXBPREVIEWPHASE=function(input)
    local i=tonumber(input)
    if not i or i<1 or i>8 then tell('/mxbpreview 1-8 (white=5; triple=8)'); return end
    preview(i)
end
