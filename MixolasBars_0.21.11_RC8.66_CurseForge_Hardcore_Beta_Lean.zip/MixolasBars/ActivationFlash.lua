-- Mixolas Bars Classic Hardcore hc14: high-visibility cosmetic press flash.
-- Action execution, bindings, PreClick/PostClick scripts, pressedShade, cooldowns,
-- macros and protected attributes are NEVER changed by this module.
local feedback = _G.MixolasBarsPressFeedback
local api = _G.MixolasBarsAPI
local NAME = '|cff65baffMixolas Bars|r: '
local indexOf = setmetatable({}, {__mode='k'})
local overlays = setmetatable({}, {__mode='k'}) -- button -> fill texture
local rims = setmetatable({}, {__mode='k'}) -- button -> brighter steel outline
local flashes = {}
local installed, hooked = false, false
local clock = function() return GetTime and GetTime() or 0 end
local settings
local palette = {
    [1]={0.27,1.00,0.49},  -- Shift + Alt
    [2]={1.00,0.86,0.24},  -- Alt
    [3]={1.00,0.55,0.17},  -- Ctrl + Alt
    [4]={0.26,0.62,1.00},  -- Shift
    [5]={0.94,0.95,1.00},  -- default
    [6]={1.00,0.26,0.32},  -- Ctrl
    [7]={0.72,0.39,1.00},  -- Shift + Ctrl
    [8]={1.00,1.00,1.00},  -- triple gradient
}
-- Bar 1 (primary rotation) uses the held physical modifier chord at the
-- instant of the key press. The modifier color is visual feedback only;
-- no keybinding, spell selection, secure attribute, or action paging is changed.
local BAR1_PHASES = {
    [5] = 'none',
    [4] = 'shift',
    [6] = 'ctrl',
    [2] = 'alt',
    [1] = 'shift+alt',
    [3] = 'ctrl+alt',
    [7] = 'shift+ctrl',
    [8] = 'shift+ctrl+alt',
}
local lastBar1Press
local function heldBar1Index()
    local sh = IsShiftKeyDown and IsShiftKeyDown()
    local ct = IsControlKeyDown and IsControlKeyDown()
    local al = IsAltKeyDown and IsAltKeyDown()
    if sh and ct and al then return 8 end
    if sh and ct then return 7 end
    if sh and al then return 1 end
    if ct and al then return 3 end
    if sh then return 4 end
    if ct then return 6 end
    if al then return 2 end
    return 5
end
local function tintFlash(b, index)
    if not b or not overlays[b] or not rims[b] then return end
    local color = palette[index] or palette[5]
    if index == 8 then
        overlays[b]:SetTexture('Interface\\AddOns\\MixolasBars\\Media\\PrismaticPressFlash.tga')
        overlays[b]:SetVertexColor(1,1,1,1)
    else
        overlays[b]:SetTexture('Interface\\AddOns\\MixolasBars\\Media\\WarlordPressFill.tga')
        overlays[b]:SetVertexColor(color[1], color[2], color[3], 1)
    end
    rims[b]:SetVertexColor(color[1], color[2], color[3], 1)
end
local function getConfig()
    if type(MixolasBarsDB) ~= 'table' then return nil end
    if type(MixolasBarsDB.activationFlash) ~= 'table' then
        MixolasBarsDB.activationFlash={enabled=true,strength=0.90,duration=0.36}
    end
    local c=MixolasBarsDB.activationFlash
    if c.enabled == nil then c.enabled=true end
    if c.bar1ModifierColors == nil then c.bar1ModifierColors = true end
    if c.bar2ModifierColors == nil then c.bar2ModifierColors = true end
    -- Upgrade untouched hc10 defaults, preserve intentionally changed values.
    if not c.hc14FlashDefaultMigrated then
        if c.strength == nil or math.abs((tonumber(c.strength) or 0.65)-0.65)<0.00001 then c.strength=0.90 end
        if c.duration == nil or math.abs((tonumber(c.duration) or 0.23)-0.23)<0.00001 then c.duration=0.36 end
        c.hc14FlashDefaultMigrated=true
    end
    c.strength=math.min(1,math.max(0,tonumber(c.strength) or 0.90))
    c.duration=math.min(0.65,math.max(0.10,tonumber(c.duration) or 0.36))
    return c
end
local function say(s)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(NAME..tostring(s))
    end
end
local function install()
    if installed then return true end
    if InCombatLockdown and InCombatLockdown() then return false end
    if not api or not api.GetClusters or (api.IsReady and not api.IsReady()) then return false end
    local function attachButton(b, i)
        if not b then return end
        indexOf[b]=i
        if not overlays[b] then
            local t=b:CreateTexture(nil,'OVERLAY',nil,7)
            t:SetPoint('TOPLEFT',b,'TOPLEFT',-2,2)
            t:SetPoint('BOTTOMRIGHT',b,'BOTTOMRIGHT',2,-2)
            t:SetBlendMode('ADD')
            if i == 8 then
                t:SetTexture('Interface\\AddOns\\MixolasBars\\Media\\PrismaticPressFlash.tga')
            else
                local rgb=palette[i]
                t:SetTexture('Interface\\AddOns\\MixolasBars\\Media\\WarlordPressFill.tga')
                t:SetVertexColor(rgb[1],rgb[2],rgb[3],1)
            end
            t:SetAlpha(0)
            t:Hide()
            overlays[b]=t
            local rim=b:CreateTexture(nil,'OVERLAY',nil,6)
            rim:SetPoint('TOPLEFT',b,'TOPLEFT',-6,6)
            rim:SetPoint('BOTTOMRIGHT',b,'BOTTOMRIGHT',6,-6)
            rim:SetBlendMode('ADD')
            rim:SetTexture('Interface\\AddOns\\MixolasBars\\Media\\WarlordPressRim.tga')
            local rgb=palette[i]
            rim:SetVertexColor(rgb[1],rgb[2],rgb[3],1)
            rim:SetAlpha(0)
            rim:Hide()
            rims[b]=rim
        end
    end
    local cs=api.GetClusters()
    if type(cs) ~= 'table' then return false end
    for i=1,8 do
        if not cs[i] or type(cs[i].buttons)~='table' then return false end
    end
    for i=1,8 do
        for _,b in ipairs(cs[i].buttons) do attachButton(b,i) end
    end
    local regular = api.GetRegularButtons and api.GetRegularButtons() or nil
    if type(regular) == 'table' then
        for _,b in ipairs(regular) do
            if b and (b.barNumber == 1 or b.barNumber == 2) then attachButton(b,5) end
        end
    end
    installed=true
    return true
end
local function displayPress(b, isDown)
    local c=getConfig()
    if not c or not c.enabled or c.strength <= 0 or not installed then return end
    if not indexOf[b] or not overlays[b] then return end
    if b._mixolasSuppressClick or (GetCursorInfo and GetCursorInfo()) then return end
    if b.IsShown and not b:IsShown() then return end
    local t=clock()
    local existing=flashes[b]
    -- Handle both click-down and click-up notifications without a second flash.
    -- Classic sometimes gives only the Up event for bound action clicks.
    if isDown == false and existing and existing.lastDown and t-existing.lastDown < 2 then
        existing.lastDown=nil
        return
    end
    if isDown == true and existing and existing.lastDown and t-existing.lastDown < 0.06 then return end
    -- Snapshot the modifier while Steam Input is activating the ability.
    -- A later key-up will NOT recolor an already-running flash.
    local chosen = indexOf[b]
    if b.barNumber == 1 then
        chosen = c.bar1ModifierColors and heldBar1Index() or 5
        tintFlash(b,chosen)
        lastBar1Press = {slot = b.barIndex or '?', index = chosen, when = t}
    elseif b.barNumber == 2 then
        chosen = c.bar2ModifierColors and heldBar1Index() or 5
        tintFlash(b,chosen)
    end
    local v = _G.MixolasBarsObsidian
    if v and v.FlashArmor and chosen then pcall(v.FlashArmor,b,chosen,c.strength) end
    local state=existing or {}
    if isDown == true then state.lastDown=t else state.lastDown=nil end
    state.started=t
    flashes[b]=state
    local region=overlays[b]
    region:SetAlpha(math.min(1,c.strength*1.00))
    region:Show()
    if rims[b] then rims[b]:SetAlpha(math.min(1,c.strength*1.0));rims[b]:Show() end
end
local driver=CreateFrame('Frame')
local tick=0
local function update(_,dt)
    if not installed then
        tick=tick+(dt or 0)
        if tick > 0.3 then tick=0; pcall(install) end
        return
    end
    local c=getConfig()
    if not c then return end
    local now=clock()
    for b,state in pairs(flashes) do
        local delta=now-state.started
        if not c.enabled or delta>=c.duration or b._mixolasSuppressClick then
            if overlays[b] then overlays[b]:Hide() end
            if rims[b] then rims[b]:Hide() end
            -- Keep lastDown only until the corresponding Up event, bounded by 2s.
            if state.lastDown and now-state.lastDown < 2 then
                state.started=-100
            else
                flashes[b]=nil
            end
        else
            -- Prompt bright impact, 70ms hold, then a readable linear fade.
            -- hc13 peaked at 52% and faded quadratically after 35ms.
            local attack=math.min(1,delta/0.018)
            local hold=0.10
            local fade=delta <= hold and 1 or math.max(0,1-(delta-hold)/math.max(0.01,c.duration-hold))
            local alpha=math.min(1,c.strength*1.0)*attack*fade
            if overlays[b] then overlays[b]:SetAlpha(alpha) end
            if rims[b] then rims[b]:SetAlpha(math.min(1,c.strength*1.0)*attack*fade) end
        end
    end
end
-- A secure post-hook leaves the original PressFeedback.Press implementation
-- unchanged. No new clickable buttons or keybindings are added.
local function hookPress()
    if hooked then return end
    if not feedback or type(feedback.Press)~='function' or type(hooksecurefunc)~='function' then return end
    local ok=pcall(hooksecurefunc,feedback,'Press',function(b,isDown)
        local status, err=pcall(displayPress,b,isDown)
        if not status then
            local c=getConfig()
            if c then c.enabled=false end
            for button,texture in pairs(overlays) do if texture then pcall(texture.Hide,texture) end end
            -- Errors here MUST NOT bubble up through a secure action click.
        end
    end)
    if ok then hooked=true end
end
hookPress()
driver:RegisterEvent('PLAYER_LOGIN')
driver:RegisterEvent('PLAYER_ENTERING_WORLD')
driver:RegisterEvent('PLAYER_REGEN_ENABLED')
driver:SetScript('OnEvent',function() hookPress(); pcall(install) end)
driver:SetScript('OnUpdate',update)
_G.MixolasBarsActivationFlash={
    GetSettings=getConfig,
    SetEnabled=function(enabled)
        local c=getConfig(); if not c then return false end
        c.enabled=not not enabled
        if not c.enabled then
            for b,t in pairs(overlays) do t:Hide() end
            for b,t in pairs(rims) do t:Hide() end
            for b in pairs(flashes) do flashes[b]=nil end
        end
        return true
    end,
    SetStrength=function(value)
        local c=getConfig(); local v=tonumber(value)
        if not c or not v then return false end
        c.strength=math.max(0,math.min(1,v));return true
    end,
    SetDuration=function(value)
        local c=getConfig();local v=tonumber(value)
        if not c or not v then return false end
        c.duration=math.max(.10,math.min(.65,v));return true
    end,
    -- Cosmetic-only preview; no click or spell cast.
    SetBar1ModifierColors=function(enabled)
        local c=getConfig(); if not c then return false end
        c.bar1ModifierColors=not not enabled
        return true
    end,
    SetBar2ModifierColors=function(enabled)
        local c=getConfig(); if not c then return false end
        c.bar2ModifierColors=not not enabled
        return true
    end,
    GetLastBar1Press=function() return lastBar1Press end,
    PreviewBar=function(bar,slot,modifier)
        bar=tonumber(bar);slot=tonumber(slot)
        local index=tonumber(modifier) or 5
        if not installed or (bar~=1 and bar~=2) or not slot or slot<1 or slot>12 or not palette[index] then return false end
        local regular=api.GetRegularButtons and api.GetRegularButtons() or {}
        for _,b in ipairs(regular) do
            if b.barNumber==bar and b.barIndex==slot and overlays[b] then
                tintFlash(b,index)
                local state=flashes[b] or {}
                state.started=clock();state.lastDown=nil
                flashes[b]=state
                overlays[b]:Show()
                if rims[b] then rims[b]:Show() end
                return true
            end
        end
        return false
    end,
    PreviewBar1=function(slot, modifier)
        slot=tonumber(slot)
        if not installed or not slot or slot<1 or slot>12 then return false end
        local index=tonumber(modifier) or 5
        if not palette[index] then return false end
        local regular=api.GetRegularButtons and api.GetRegularButtons() or nil
        if type(regular)~='table' then return false end
        for _,b in ipairs(regular) do
            if b and b.barNumber == 1 and b.barIndex == slot and overlays[b] then
                tintFlash(b,index)
                local state=flashes[b] or {}
                state.started=clock();state.lastDown=nil
                flashes[b]=state
                overlays[b]:Show()
                if rims[b] then rims[b]:Show() end
                return true
            end
        end
        return false
    end,
    Preview=function(index)
        index=tonumber(index)
        if not index or index<1 or index>8 then return false end
        if not installed then return false end
        local cs=api.GetClusters()
        local b=cs[index] and cs[index].buttons and cs[index].buttons[1]
        if not b then return false end
        local state=flashes[b] or {}
        state.started=clock();state.lastDown=nil
        flashes[b]=state
        overlays[b]:Show()
        if rims[b] then rims[b]:Show() end
        return true
    end,
}
SLASH_MIXOLASFLASH1='/mxbflash'
SlashCmdList.MIXOLASFLASH=function(arg)
    local f=_G.MixolasBarsActivationFlash
    local s=(arg or ''):lower():match('^%s*(.-)%s*$')
    if s=='on' or s=='off' then f.SetEnabled(s=='on')
    elseif s=='bar1mod on' or s=='bar1mod off' then f.SetBar1ModifierColors(s=='bar1mod on')
    elseif s=='bar2mod on' or s=='bar2mod off' then f.SetBar2ModifierColors(s=='bar2mod on')
    elseif s=='last' then
        local info=f.GetLastBar1Press()
        if info then
            say('Last Bar 1 flash: slot '..tostring(info.slot)..' / '..(BAR1_PHASES[info.index] or 'unknown')..' / '..tostring(info.index)..' color.')
        else say('No Bar 1 press detected yet this session.') end
        return
    elseif s:match('^previewbar1%s+%d+%s+[%w+]+$') then
        local slot,phase=s:match('^previewbar1%s+(%d+)%s+([%w+]+)$')
        local idx
        for k,v in pairs(BAR1_PHASES) do if v==phase then idx=k end end
        if not idx or not f.PreviewBar1(tonumber(slot),idx) then
            say('Bar 1 preview unavailable. Usage: /mxbflash previewbar1 1 shift+alt')
        end
        return
    elseif s:match('^strength%s+%d+$') then f.SetStrength(tonumber(s:match('%d+'))/100)
    elseif s:match('^duration%s+%d+$') then f.SetDuration(tonumber(s:match('%d+'))/1000)
    elseif s:match('^preview%s+[1-8]$') then f.Preview(tonumber(s:match('[1-8]$')))
    elseif s~='' and s~='status' then
        say('Commands: /mxbflash on|off | strength 0-100 | duration 100-650 | preview 1-8 | bar1mod on|off | bar2mod on|off | previewbar1 1 shift+alt | last')
        return
    end
    local c=getConfig()
    if c then
        say(string.format('Colored button flash %s; strength %d%%, duration %d ms; Bar 1 modifier colors %s.',c.enabled and 'ON' or 'OFF',math.floor(c.strength*100+0.5),math.floor(c.duration*1000+0.5),c.bar1ModifierColors and 'ON' or 'OFF'))
        say('Bar 2 modifier colors: '..(c.bar2ModifierColors and 'ON' or 'OFF'))
    end
end
