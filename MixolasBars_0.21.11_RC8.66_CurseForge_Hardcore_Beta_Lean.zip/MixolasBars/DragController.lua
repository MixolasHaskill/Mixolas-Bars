-- Mixolas Bars: UIParent-coordinate dragging with precise grid snap and smooth edge limits.
-- Shared by diamond clusters and traditional bars; no secure attributes changed.
local api=_G.MixolasBarsAPI
if not api then return end

local GRID_STEP=10       -- UIParent units, independent of the user's UI scale.
local MAJOR_STEP=40      -- Only major guides are drawn to avoid visual clutter.
local GUIDE_COLOR={0.38,0.70,1.00,0.24}
local AXIS_RADIUS=12    -- Screen center and quarter-axis magnetic guides.

local guides=CreateFrame('Frame','MixolasBarsSnapGuides',UIParent)
guides:SetAllPoints(UIParent)
guides:SetFrameStrata('HIGH')
guides:EnableMouse(false)
local majorLines={}
local axisLines={}
local function makeLine(vertical,major)
    local t=guides:CreateTexture(nil,'OVERLAY')
    t:SetColorTexture(0.38,0.70,1,major and 0.24 or 0.36)
    if vertical then t:SetWidth(major and 1 or 2) else t:SetHeight(major and 1 or 2) end
    return t
end
for i=1,6 do axisLines[i]=makeLine(i<=3,false) end
local function showGuides()
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    -- Grid lines sit on the SAME center-relative origin as quantization.
    -- Reuse textures on resolution changes rather than making a new grid.
    local neededX=math.ceil(w/(2*MAJOR_STEP))
    local neededY=math.ceil(h/(2*MAJOR_STEP))
    local k=0
    for i=-neededX,neededX do
        k=k+1
        local t=majorLines[k] or makeLine(true,true)
        majorLines[k]=t
        t:ClearAllPoints();t:SetPoint('TOP',UIParent,'TOP',i*MAJOR_STEP,0)
        t:SetPoint('BOTTOM',UIParent,'BOTTOM',i*MAJOR_STEP,0)
        t:Show()
    end
    for i=-neededY,neededY do
        k=k+1
        local t=majorLines[k] or makeLine(false,true)
        majorLines[k]=t
        t:ClearAllPoints();t:SetPoint('LEFT',UIParent,'LEFT',0,i*MAJOR_STEP)
        t:SetPoint('RIGHT',UIParent,'RIGHT',0,i*MAJOR_STEP)
        t:Show()
    end
    for i=k+1,#majorLines do majorLines[i]:Hide() end
    for i,pos in ipairs({-0.25,0,0.25}) do
        local v=axisLines[i]
        v:ClearAllPoints();v:SetPoint('TOP',UIParent,'TOP',pos*w,0)
        v:SetPoint('BOTTOM',UIParent,'BOTTOM',pos*w,0)
        local hLine=axisLines[i+3]
        hLine:ClearAllPoints();hLine:SetPoint('LEFT',UIParent,'LEFT',0,pos*h)
        hLine:SetPoint('RIGHT',UIParent,'RIGHT',0,pos*h)
    end
    guides:Show()
end
guides:Hide()

local driver=CreateFrame('Frame','MixolasBarsDragDriver',UIParent)
driver:EnableMouse(false)
driver:Hide()
local active
local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
local function rounded(v,step)
    return math.floor(v/step+0.5)*step
end
local function nearAxis(value,coord,radius)
    return math.abs(value-coord)<=radius and coord or value
end
-- WoW interprets SetPoint offsets in the moved frame's scale, while cursor
-- movement and the snap grid are measured in UIParent coordinates.  Mixing
-- those systems was the reason a bar would stop visually above an edge even
-- when its stored center looked exactly docked.
--
-- Keep existing profile coordinates in the ORIGINAL frame-local SetPoint
-- units. Convert only during dragging; no SavedVariables migration required.
local function relativeScale(frame)
    local parentScale=UIParent:GetEffectiveScale() or 1
    local frameScale=frame:GetEffectiveScale() or parentScale
    return math.max(frameScale/math.max(parentScale,0.001),0.001)
end
local function dimensions(frame)
    local factor=relativeScale(frame)
    return frame:GetWidth()*factor/2,frame:GetHeight()*factor/2
end
local function constrain(frame,x,y)
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    local hw,hh=dimensions(frame)
    -- Clamp by the *visible* scaled bounds, not the centre.  A valid dock is
    -- flush against the viewport; never leave part of a diamond off-screen.
    hw=math.min(w/2,hw)
    hh=math.min(h/2,hh)
    return clamp(x,-w/2+hw,w/2-hw),clamp(y,-h/2+hh,h/2-hh)
end
-- The old drag helper forcibly docked whenever the bar's visible edge came
-- within 64 UI units of the viewport OR the cursor entered a 76-unit edge
-- zone. That caused the 2026-10-22 "jumps to bottom" regression. Dragging
-- must remain continuous; only clamp when the actual rendered frame reaches
-- the boundary. The explicit Dock Bottom/Top/Left/Right controls still place
-- regular bars exactly against an edge on demand.
local function snap(frame,x,y)
    local db=api.GetDB()
    local rawX,rawY=x,y
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    local grid=db and db.snapEnabled
    if grid then
        -- The user explicitly enabled the 10-unit position grid. Keep its
        -- small quantization and the existing alignment guides, but do NOT
        -- magnetize the frame to a SCREEN edge from a distance.
        x=rounded(x,GRID_STEP); y=rounded(y,GRID_STEP)
        for _,axis in ipairs({-w/4,0,w/4}) do
            if math.abs(x-axis)<=AXIS_RADIUS then x=axis;break end
        end
        for _,axis in ipairs({-h/4,0,h/4}) do
            if math.abs(y-axis)<=AXIS_RADIUS then y=axis;break end
        end
        -- Quantizing to a grid could round a bar a few units back INSIDE
        -- the viewport just as its unrounded edge reaches the boundary.
        -- In that case prefer an exact, visible edge over an interior grid
        -- point. No action occurs until the user actually drags that far.
        local hw,hh=dimensions(frame)
        hw=math.min(hw,w/2);hh=math.min(hh,h/2)
        local left,right=-w/2+hw,w/2-hw
        local bottom,top=-h/2+hh,h/2-hh
        if rawX<=left then x=left elseif rawX>=right then x=right end
        if rawY<=bottom then y=bottom elseif rawY>=top then y=top end
    end
    return constrain(frame,x,y)
end

local function update()
    if not active then return end
    local mx,my=GetCursorPosition()
    if not (mx and my) then return end
    local x=active.originalX+(mx-active.cursorX)/active.uiScale
    local y=active.originalY+(my-active.cursorY)/active.uiScale
    x,y=snap(active.frame,x,y)
    active.lastX,active.lastY=x,y
    local f=active.frame
    f:ClearAllPoints()
    local factor=relativeScale(f)
    f:SetPoint('CENTER',UIParent,'CENTER',x/factor,y/factor)
end
api.BeginLayoutDrag=function(frame,data)
    if active or api.IsInCombat() or api.GetDB().locked or not GetCursorPosition then return end
    if not frame or not data then return end
    local mx,my=GetCursorPosition()
    if not (mx and my) then return end
    local uiScale=math.max(UIParent:GetEffectiveScale() or 1,0.001)
    local factor=relativeScale(frame)
    active={frame=frame,data=data,cursorX=mx,cursorY=my,uiScale=uiScale,
        originalX=(data.x or 0)*factor,originalY=(data.y or 0)*factor,
        lastX=(data.x or 0)*factor,lastY=(data.y or 0)*factor}
    driver:SetScript('OnUpdate',update)
    driver:Show()
    if api.GetDB().snapEnabled then showGuides() else guides:Hide() end
end
api.EndLayoutDrag=function(frame)
    if not active or active.frame~=frame then return end
    update()
    local state=active
    driver:SetScript('OnUpdate',nil)
    driver:Hide();guides:Hide();active=nil
    -- Save the historical frame-local offsets, exactly as RefreshLayout and
    -- RegularBars.redraw expect.  This keeps existing named profiles intact.
    local factor=relativeScale(state.frame)
    state.data.x=state.lastX/factor
    state.data.y=state.lastY/factor
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
end
api.AbortLayoutDrag=function()
    if active then api.EndLayoutDrag(active.frame) end
end
api.RefreshLayoutGuides=function()
    if active and api.GetDB().snapEnabled then showGuides() else guides:Hide() end
end

-- Out-of-combat live sanity check for scaled-edge bugs.  GetBottom() is in
-- frame-scaled coordinates, so normalize before reporting the visible gap.
-- Usage: /mxbedge 6, /mxbedge 7, /mxbedge 8, /mxbedge diamond 1
SLASH_MIXOLASEDGE1='/mxbedge'
SlashCmdList=SlashCmdList or {}
SlashCmdList.MIXOLASEDGE=function(raw)
    if api.IsInCombat() then
        print('Mixolas Bars: Check screen edges outside combat.')
        return
    end
    raw=(raw or ''):lower():match('^%s*(.-)%s*$')
    local num=tonumber(raw)
    local kind='Bar'
    local frame
    if raw:find('^diamond%s+%d+$') then
        num=tonumber(raw:match('%d+'))
        kind='Diamond'
        local clusters=api.GetClusters and api.GetClusters()
        frame=clusters and clusters[num]
    else
        local bars=api.GetRegularBars and api.GetRegularBars()
        frame=bars and bars[num]
    end
    if not frame or not frame.GetBottom or not frame.GetEffectiveScale then
        print('Usage: /mxbedge 6 (or 7, 8) / /mxbedge diamond 1')
        return
    end
    local ok,edge,gap=pcall(function()
        local parentScale=math.max(UIParent:GetEffectiveScale() or 1,0.001)
        local parentBottom=UIParent:GetBottom() or 0
        local bottom=frame:GetBottom()
        if type(bottom)~='number' then return nil,nil end
        local diff=bottom*frame:GetEffectiveScale()/parentScale-parentBottom
        return bottom,diff
    end)
    if ok and type(gap)=='number' then
        print(('Mixolas Bars %s %d: bottom gap %.2f UI units, scale %.2f, shown %s'):format(
            kind,num,gap,relativeScale(frame),tostring(frame:IsShown())))
    else
        print('Mixolas Bars: Could not measure frame boundary; try while visible and outside combat.')
    end
end
