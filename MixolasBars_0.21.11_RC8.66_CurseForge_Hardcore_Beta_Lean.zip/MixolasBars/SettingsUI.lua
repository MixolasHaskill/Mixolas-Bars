-- Mixolas Bars v0.6.0-alpha: in-game editor, no chat commands required.
local api = _G.MixolasBarsAPI
if not api then return end

local window, updateControls
-- Do not rebuild the entire options window while Blizzard is handling a slider
-- thumb drag. The setting itself still changes immediately; repaint on release.
local draggingSlider
local sliderValueControls = {} -- numeric field mirrors for every settings slider
local CONTROLS = { updating = false, swatches = {}, counts = {}, alphas = {}, styles = {}, brights = {}, scales = {}, motions = {}, regular = {}, utility = {}, decor = {} }
local tabs = {}
local currentTab = 1
local regularSelected=1
local utilitySelected="pet"
local frameSelected=1
local diamondSelected=1 -- 0 = ALL diamonds
local diamondSection=1
local frameSection=1
local frameMode="attached"
local frameStudioTarget="bar1"
local frameStudioPage=1
local regularSection=1
local regularPetSelected=false -- Pet Bar is inside Action Bars, never a separate main page.
local editorScaleValue
local chosenProfile=1
local chosenSnapshot=1
local chosenSnapshotRef=nil
local profileNotice="Choose a saved layout and keybinding profile, or create a new one."
local HEADER = {0.52, 0.79, 1}
local NAMES = {
    "Green", "Yellow", "Orange", "Blue", "White", "Red",
    "Purple", "All / RGB",
}

local function label(parent, text, x, y, font, width)
    local l = parent:CreateFontString(nil, "OVERLAY", font or "GameFontNormal")
    l:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    l:SetText(text)
    if width then l:SetWidth(width); l:SetJustifyH("LEFT") end
    -- Older numeric value labels are retained as harmless update targets.
    -- Their visible replacement is the editable field beside each slider.
    if text == "" and x >= 450 and width and width <= 110 and parent ~= window then
        l:Hide()
    end
    return l
end
local function button(parent, width, height, text, x, y, handler)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", handler)
    return b
end
-- Compact contextual help buttons.  Tooltips are informational only and never
-- change a binding, profile, action, or setting.  Hover rather than click.
local function helpTip(parent,x,y,title,description)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(19,19)
    b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b:SetText("?")
    b:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine(title,1,0.82,0.35)
        GameTooltip:AddLine(description,0.9,0.9,0.9,true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave",function()
        if GameTooltip then GameTooltip:Hide() end
    end)
    return b
end

-- Quiet, noninteractive grouping panels.  BACKGROUND textures live on the
-- same frame as the controls and never consume mouse input or settings state.
-- The tinted header rule + four fine edges make page -> section -> control
-- boundaries discoverable even when every page uses the same dark palette.
local function sectionPanel(parent,x,y,width,height,kind)
    local emphasis=(kind=="subpage")
    local bg=parent:CreateTexture(nil,"BACKGROUND",nil,-7)
    bg:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    bg:SetSize(width,height)
    bg:SetColorTexture(0.06,0.085,0.13,emphasis and 0.36 or 0.23)
    local function edge(px,py,w,h,r,g,b,a)
        local t=parent:CreateTexture(nil,"BACKGROUND",nil,-6)
        t:SetPoint("TOPLEFT",parent,"TOPLEFT",px,py)
        t:SetSize(w,h)
        t:SetColorTexture(r,g,b,a)
        return t
    end
    local r,g,b=0.34,0.54,0.68
    edge(x,y,width,1,r,g,b,0.74)
    edge(x,y-height+1,width,1,r,g,b,0.38)
    edge(x,y,1,height,r,g,b,0.55)
    edge(x+width-1,y,1,height,r,g,b,0.38)
    edge(x+1,y-2,3,16,0.57,0.79,0.98,0.8)
end
local function subtabMark(b)
    local t=b:CreateTexture(nil,"OVERLAY")
    t:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",9,3)
    t:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-9,3)
    t:SetHeight(2)
    t:SetColorTexture(0.56,0.83,1,0.94)
    t:Hide()
    b.mixolasSelectionMark=t
    return b
end
local function selectSubtabMark(b,active)
    if b and b.mixolasSelectionMark then b.mixolasSelectionMark:SetShown(active) end
end

local function canEdit()
    if not api.IsReady() or api.IsInCombat() then
        api.Say("Editing action buttons and bindings is disabled during combat.")
        return false
    end
    return true
end
-- Every settings slider gets a directly editable value display. Slider dragging
-- keeps its original step; typed entries accept *any integer* in the allowed
-- min/max (e.g. 86%, even on a slider that drags in five-point increments).
local PERCENT_SLIDERS = {
    DiamondGlobal_glow=true, DiamondGlobal_borderAlpha=true,
    DiamondChosenScale=true, DiamondChosenAlpha=true,
    DiamondChosenCombatAlpha=true,
    DiamondChosenBright=true, DiamondChosenGlow=true,
    WarlordGlowStrength=true, WarlordFrameOpacity=true,
    RegV17_scale=true, RegV17_alpha=true,
    RegV17_alphaOut=true, RegV17_alphaCombat=true,
    Utility_scale=true, Utility_alpha=true,
    Utility_alphaOut=true, Utility_alphaCombat=true,
    RangeDim=true, CombatDim=true, GcdDarkness=true,
    FrameV17_alpha=true,
    FrameStudio_opacity=true, FrameStudio_illumination=true,
    FrameStudio_fieldStrength=true, FrameStudio_scale=true,
}
local POINT_SLIDERS = {HotkeyFont=true, ItemCountFont=true,
    FrameV17_fontSize=true, FrameStudio_labelSize=true}
local PIXEL_SLIDERS = {
    DiamondGlobal_buttonSize=true, DiamondGlobal_borderWidth=true,
    DiamondGapEastWest=true, DiamondGapNorthSouth=true,
    MinimapIcon=true, RegV17_padding=true, Utility_padding=true,
    FrameV17_width=true, FrameV17_height=true, FrameV17_labelGap=true,
    FrameV17_labelOffsetX=true, FrameV17_labelOffsetY=true,
    FrameV17_thickness=true, FrameStudio_fieldSize=true,
    FrameStudio_padding=true, FrameStudio_x=true, FrameStudio_y=true,
    FrameStudio_labelGap=true, FrameStudio_labelShift=true,
}
local function slider(parent, unique, x, y, width, minVal, maxVal, step, onValue)
    local s = CreateFrame("Slider", "MixolasBarsV11_" .. unique, parent, "OptionsSliderTemplate")
    s:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    s:SetSize(width, 17)
    s:SetOrientation("HORIZONTAL")
    s:EnableMouse(true)
    s:SetMinMaxValues(minVal, maxVal)
    s:SetValueStep(step)
    if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
    for _, suffix in ipairs({"Low", "High", "Text"}) do
        local t = _G[s:GetName() .. suffix]
        if t then t:SetText("") end
    end

    local suffix = PERCENT_SLIDERS[unique] and "%" or (POINT_SLIDERS[unique] and " pt" or (PIXEL_SLIDERS[unique] and " px" or ""))
    local entry = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    entry:SetAutoFocus(false)
    entry:SetSize(64, 23)
    entry:SetJustifyH("CENTER")
    entry:SetMaxLetters(14)
    -- The minimap and GCD sliders sit close to the right edge of their pages.
    local rightLimit = (parent:GetWidth() or 585) - 68
    entry:SetPoint("LEFT", parent, "TOPLEFT", math.min(x + width + 11, rightLimit), y - 8)
    entry:SetTextColor(1, 0.87, 0.57)
    entry:SetFontObject("GameFontHighlightSmall")
    s.valueEntry = entry
    sliderValueControls[#sliderValueControls+1] = s

    local function display(value)
        value = tonumber(value) or minVal
        return tostring(math.floor(value + 0.5)) .. suffix
    end
    local function refreshEntry()
        if not entry:HasFocus() then entry:SetText(display(s:GetValue())) end
    end
    local historyForDrag=false
    local historyOwner="settings:"..unique
    local function endSliderSession()
        if draggingSlider ~= s then return end
        draggingSlider = nil
        if historyForDrag and api.EndContinuousEdit then api.EndContinuousEdit(historyOwner) end
        historyForDrag=false
        if updateControls then updateControls() end
    end
    local function beginSliderSession()
        if draggingSlider == s then return end
        -- Defensive: leaving a previous pointer surface should never hold
        -- its undo transaction open while a different slider is adjusted.
        if draggingSlider and draggingSlider.EndMixolasSliderSession then
            draggingSlider.EndMixolasSliderSession()
        end
        draggingSlider=s
        if api.BeginContinuousEdit then
            historyForDrag=api.BeginContinuousEdit('Adjust '..unique,historyOwner)==true
        end
    end
    s.EndMixolasSliderSession=endSliderSession
    s:SetScript("OnValueChanged", function(self, value, userInput)
        -- Programmatic settings/profile refreshes still need to update the
        -- neighboring input. Suppress only applying the preference again,
        -- never the display synchronization.
        refreshEntry()
        if CONTROLS.updating then return end
        -- Some Classic client variants don't supply userInput; the actual
        -- pressed mouse button is a safe fallback for a real thumb movement.
        if userInput or (type(IsMouseButtonDown)=="function" and IsMouseButtonDown("LeftButton")) then
            beginSliderSession()
        end
        refreshEntry()
        if not canEdit() then
            if draggingSlider == self then endSliderSession()
            elseif updateControls then updateControls() end
            return
        end
        onValue(value)
    end)
    -- Explicit mouse surface for all settings sliders. The classic Slider
    -- template does not consistently transfer OnValueChanged mouse drags when
    -- we also provide an independent numeric EditBox. Bypass template mouse
    -- routing for pointer input, retain its appearance, thumb, and value API.
    -- This never routes keyboard input or touches action/combat buttons.
    local pointer = CreateFrame("Frame", nil, s)
    pointer:SetAllPoints(s)
    pointer:SetFrameLevel(s:GetFrameLevel() + 3)
    pointer:EnableMouse(true)
    local function setFromCursor()
        if not draggingSlider or draggingSlider ~= s then return end
        if not s:IsEnabled() or not canEdit() then return end
        if type(GetCursorPosition) ~= "function" then return end
        local left = s:GetLeft()
        local widthPx = s:GetWidth()
        local effectiveScale = s:GetEffectiveScale()
        if not left or not widthPx or widthPx <= 16 or not effectiveScale or effectiveScale <= 0 then return end
        local cursorX = GetCursorPosition()
        local fraction = (cursorX / effectiveScale - left - 8) / (widthPx - 16)
        fraction = math.max(0, math.min(1, fraction))
        local raw = minVal + fraction * (maxVal - minVal)
        local val = minVal + math.floor((raw - minVal) / step + 0.5) * step
        val = math.max(minVal, math.min(maxVal, val))
        if math.abs((s:GetValue() or minVal) - val) < 0.0001 then return end
        -- Set the visual thumb without sending a second apply from OnValueChanged.
        -- Apply the actual user input directly even if panel repaint is busy.
        local wasUpdating = CONTROLS.updating
        CONTROLS.updating = true
        s:SetValue(val)
        CONTROLS.updating = wasUpdating
        refreshEntry()
        onValue(val)
    end
    local function finishPointer()
        endSliderSession()
    end
    pointer:SetScript("OnMouseDown", function(self, buttonName)
        if buttonName ~= "LeftButton" or not s:IsEnabled() or not canEdit() then return end
        if entry:HasFocus() then entry:ClearFocus() end
        -- A new press is a new edit even if the prior mouse-up was lost.
        if draggingSlider == s then endSliderSession() end
        beginSliderSession()
        setFromCursor()
    end)
    pointer:SetScript("OnMouseUp", function(self, buttonName)
        if buttonName == "LeftButton" then
            if draggingSlider == s then setFromCursor() end
            finishPointer()
        end
    end)
    pointer:SetScript("OnUpdate", function()
        if draggingSlider ~= s then return end
        if type(IsMouseButtonDown) == "function" and not IsMouseButtonDown("LeftButton") then
            finishPointer()
        else
            setFromCursor()
        end
    end)
    pointer:SetScript("OnHide", finishPointer)
    s.valuePointer = pointer
    entry:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    entry:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        refreshEntry()
    end)
    entry:SetScript("OnEditFocusLost", function(self) refreshEntry() end)
    entry:SetScript("OnEnterPressed", function(self)
        local typed = self:GetText() or ""
        -- Accept 86, 86%, 8 pt, 12 px and signed offsets; reject garbage.
        typed = typed:gsub("^%s+", ""):gsub("%s+$", "")
        typed = typed:gsub("%s*[pP][xXtT]%s*$", ""):gsub("%s*%%%s*$", "")
        typed = typed:gsub("%s+$", "")
        local number = (typed:match("^[+-]?%d+%.?%d*$") or typed:match("^[+-]?%d*%.%d+$")) and tonumber(typed)
        self:ClearFocus()
        if not number or number ~= number or not s:IsEnabled() or not canEdit() then
            refreshEntry()
            return
        end
        number = math.max(minVal, math.min(maxVal, math.floor(number + 0.5)))
        -- Do not quantize text to slider drag steps. Apply through its normal
        -- change callback, preserving profile/undo updates and range checks.
        CONTROLS.updating = true
        s:SetValue(number)
        CONTROLS.updating = false
        onValue(number)
        if updateControls then updateControls() end
    end)
    -- Also synchronize after a full page refresh when the stored value is
    -- unchanged (WoW does not send OnValueChanged for identical values).
    s.RefreshValueEntry = refreshEntry
    if s.HookScript then
        s:HookScript("OnDisable", function() entry:Disable() end)
        s:HookScript("OnEnable", function() entry:Enable() end)
    end
    refreshEntry()
    return s
end

local function eachSelected(fn)
    if diamondSelected==0 then
        local function apply()
            local succeeded=true
            for i=1,8 do if fn(i)==false then succeeded=false end end
            return succeeded
        end
        if api.RunBatchEdit then return api.RunBatchEdit('All diamonds',apply) end
        return apply()
    end
    return fn(diamondSelected)
end

local function pickColor(i)
    if not canEdit() then return end
    local frame = ColorPickerFrame
    if not frame then return end
    local c = api.GetDB().colors[i==0 and 1 or i]
    local old = {c[1],c[2],c[3]}
    local function apply()
        if api.IsInCombat() then return end
        local r,g,b = frame:GetColorRGB()
        if eachSelected(function(n) return api.ChangeColor(n,r,g,b) end) then updateControls() end
    end
    local function cancel()
        if eachSelected(function(n) return api.ChangeColor(n,old[1],old[2],old[3]) end) then updateControls() end
    end
    if frame.SetupColorPickerAndShow then
        frame:SetupColorPickerAndShow({r=c[1],g=c[2],b=c[3], hasOpacity=false,
            swatchFunc=apply, func=apply, cancelFunc=cancel})
    else
        frame.func=apply
        frame.cancelFunc=cancel
        frame.hasOpacity=false
        frame:SetColorRGB(c[1],c[2],c[3])
        frame:Hide(); frame:Show()
    end
end

local function makePage(parent)
    local f=CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", 19, -178)
    f:SetSize(585, 400)
    sectionPanel(f,0,0,580,400,"page")
    return f
end

-- Shared diamond-wide appearance controls live with the per-diamond editor.
-- Each uses the original data key and unchanged slider/Undo/typed-entry pipeline.
local function diamondSharedSlider(parent,key,name,min,max,step,y,format,percentage)
    label(parent,name,16,y-2,"GameFontNormal",195)
    local val=label(parent,"",475,y-8,"GameFontHighlightSmall",62)
    local s=slider(parent,"DiamondGlobal_"..key,216,y,234,min,max,step,function(v)
        if api.Change(key,percentage and v/100 or v) then updateControls() end
    end)
    CONTROLS[key]={slider=s,value=val,fmt=format,percentage=percentage}
end

local function makeGeneral(page)
    sectionPanel(page,8,-33,560,106)
    sectionPanel(page,8,-143,560,144)
    label(page,"GENERAL",18,-4,"GameFontNormalLarge")
    label(page,"INTERFACE",18,-45,"GameFontNormal")
    label(page,"Minimap Icon Size",18,-92,"GameFontHighlight")
    CONTROLS.minimapSize={}
    CONTROLS.minimapSize.slider=slider(page,"MinimapIcon",200,-90,265,20,56,1,function(v)
        if api.Change("minimapSize",v) then updateControls() end
    end)
    CONTROLS.minimapSize.value=label(page,"",485,-98,"GameFontHighlightSmall",42)
    helpTip(page,156,-91,"Minimap Icon Size","Resize the Mixolas settings launcher around the minimap. This does not change action bar sizes.")

    label(page,"BLIZZARD ACTION BARS",18,-154,"GameFontNormal")
    CONTROLS.blizzard=button(page,235,29,"Hide Blizzard Buttons",18,-188,function()
        if canEdit() and api.SetHideBlizzard(not api.GetDB().hideBlizzard) then updateControls() end
    end)
    label(page,"Only native action buttons are affected by this option.",18,-238,"GameFontHighlightSmall",540)
    helpTip(page,263,-191,"Hide Blizzard Buttons","Hide the default Blizzard action buttons when Mixolas manages your bars. Blizzard Edit Mode remains responsible for decorative artwork.")
    label(page,"Blizzard's Edit Mode manages Blizzard artwork separately.",18,-260,"GameFontHighlightSmall",540)
end

-- v0.17: one focused diamond at a time, with real subsection pages.
-- The original eight stacked 146px sections overflowed the scroll region
-- and were unusable on smaller monitors. All settings remain accessible.
local function selectedEmptyChange(current)
    if diamondSelected~=0 then return current[diamondSelected]==false end
    for i=1,8 do
        if current[i]==false then return true end
    end
    return false
end

local function makeDiamonds(page)
    local d={sections={},nav={},sectionNav={}}
    CONTROLS.diamondEditor=d
    label(page,"SELECT DIAMOND",14,-5,"GameFontNormalLarge")
    for i=0,8 do
        d.nav[i]=button(page,57,26,i==0 and "ALL" or tostring(i),14+i*62,-34,function()
            diamondSelected=i
            updateControls()
        end)
    end
    local sectionNames={"Layout","Spacing","Border & Glow","Illumination"}
    for j,name in ipairs(sectionNames) do
        d.sectionNav[j]=subtabMark(button(page,125,26,name,14+(j-1)*138,-78,function()
            diamondSection=j
            updateControls()
        end))
        local f=CreateFrame("Frame",nil,page)
        f:SetPoint("TOPLEFT",page,"TOPLEFT",0,-114)
        f:SetSize(559,286)
        sectionPanel(f,0,0,559,286,"subpage")
        d.sections[j]=f
    end
    local layout=d.sections[1]
    d.title=label(layout,"",16,-3,"GameFontNormalLarge",520)
    d.info=label(layout,"",16,-31,"GameFontHighlightSmall",515)
    d.toggle=button(layout,202,29,"Hide diamond",16,-67,function()
        if not canEdit() then return end
        local db=api.GetDB()
        local desired=diamondSelected==0 and false or db.diamondEnabled[diamondSelected]==false
        if diamondSelected==0 then
            desired=true
            for i=1,8 do if db.diamondEnabled[i]~=false then desired=false;break end end
        end
        eachSelected(function(i) return api.SetDiamondEnabled(i,desired) end)
        updateControls()
    end)
    d.empty=button(layout,202,29,"Hide empty slots",250,-67,function()
        if not canEdit() then return end
        local db=api.GetDB()
        local current=db.diamondShowEmpty or {}
        local desired=selectedEmptyChange(current)
        if eachSelected(function(i) return api.SetDiamondShowEmpty(i,desired) end) then updateControls() end
    end)
    helpTip(layout,224,-71,"Show / Hide Diamond","Show or hide the selected diamond without erasing its actions. ALL applies to every diamond.")
    helpTip(layout,456,-71,"Show / Hide Empty Slots","Show unused spell slots for editing or hide them for a compact layout. Binding mode temporarily reveals hidden slots.")
    label(layout,"Visible spell slots",16,-118,"GameFontNormal")
    d.decrease=button(layout,37,28,"-",213,-110,function()
        if canEdit() then
            local target=(api.GetDB().counts[diamondSelected==0 and 1 or diamondSelected] or 4)-1
            eachSelected(function(i) return api.SetCount(i,target) end)
            updateControls()
        end
    end)
    d.count=label(layout,"4",267,-117,"GameFontHighlightLarge",35)
    d.increase=button(layout,37,28,"+",306,-110,function()
        if canEdit() then
            local target=(api.GetDB().counts[diamondSelected==0 and 1 or diamondSelected] or 4)+1
            eachSelected(function(i) return api.SetCount(i,target) end)
            updateControls()
        end
    end)
    helpTip(layout,354,-112,"Visible Spell Slots","Increase or decrease how many spell buttons appear within the selected diamond. ALL changes the count across diamonds.")
    diamondSharedSlider(layout,"buttonSize","Button Size (All Diamonds)",16,72,1,-148,"%d px",false)
    helpTip(layout,191,-150,"Button Size (All Diamonds)","Pixel size of the action buttons across all eight diamonds. Different from Diamond Scale, which scales the entire cluster.")
    label(layout,"Diamond scale",16,-188,"GameFontNormal")
    d.scale=slider(layout,"DiamondChosenScale",195,-187,266,35,150,5,function(v)
        if eachSelected(function(i) return api.SetScale(i,v/100) end) then updateControls() end
    end)
    d.scaleText=label(layout,"",470,-194,"GameFontHighlightSmall",65)
    helpTip(layout,159,-189,"Diamond Scale","Enlarge or shrink the selected diamond as a whole. ALL applies the same scale to every diamond.")
    label(layout,"Out of Combat Opacity",16,-223,"GameFontNormal")
    d.alpha=slider(layout,"DiamondChosenAlpha",235,-221,217,10,100,5,function(v)
        if eachSelected(function(i) return api.SetDiamondOutOpacity(i,v/100) end) then updateControls() end
    end)
    d.alphaText=label(layout,"",474,-230,"GameFontHighlightSmall",64)
    helpTip(layout,212,-224,"Out of Combat Opacity","Transparency of selected diamonds while out of combat. The decorative housing, glow and labels fade alongside their buttons.")
    label(layout,"In Combat Opacity",16,-261,"GameFontNormal")
    d.combatAlpha=slider(layout,"DiamondChosenCombatAlpha",235,-259,217,10,100,5,function(v)
        if eachSelected(function(i) return api.SetDiamondCombatOpacity(i,v/100) end) then updateControls() end
    end)
    d.combatAlphaText=label(layout,"",474,-268,"GameFontHighlightSmall",64)

    helpTip(layout,212,-262,"In Combat Opacity","Transparency of selected diamonds while in combat. Separate from the out-of-combat value; action assignments are unchanged.")
    -- These two spacing preferences are GLOBAL: they apply to the icon
    -- geometry in every diamond, irrespective of the selected diamond tab.
    -- Reuse the existing advanced geometry setter rather than creating a
    -- second source of truth, migration, or another SavedVariables field.
    local spacingPage=d.sections[2]
    label(spacingPage,"DIAMOND SPACING  /  ALL DIAMONDS",16,-7,"GameFontNormalLarge")
    label(spacingPage,"Both controls affect all eight diamonds, even when one is selected above.",16,-39,"GameFontHighlightSmall",530)
    label(spacingPage,"East / West icon gap",16,-91,"GameFontNormal")
    d.gapEW=slider(spacingPage,"DiamondGapEastWest",195,-117,265,0,24,1,function(v)
        local tools=_G.MixolasBarsAdvanced
        if tools and tools.Spacing and tools.Spacing("ew",v) then updateControls() end
    end)
    helpTip(spacingPage,183,-93,"East / West Icon Gap","Horizontal space between the west and east action buttons in every diamond. Zero makes their edges touch. Applies to all diamonds.")
    label(spacingPage,"North / South icon gap",16,-185,"GameFontNormal")
    d.gapNS=slider(spacingPage,"DiamondGapNorthSouth",195,-211,265,0,24,1,function(v)
        local tools=_G.MixolasBarsAdvanced
        if tools and tools.Spacing and tools.Spacing("ns",v) then updateControls() end
    end)
    helpTip(spacingPage,202,-187,"North / South Icon Gap","Vertical space between the action-button rows within each diamond. Applies to all diamonds; does not move diamond clusters apart.")
    label(spacingPage,"Range: 0 to 24 pixels. Slider drag, typed value and Undo/Redo supported.",16,-264,"GameFontHighlightSmall",535)
    local appearance=d.sections[3]
    label(appearance,"BORDER & GLOW",16,-7,"GameFontNormalLarge")
    d.swatch=appearance:CreateTexture(nil,"ARTWORK")
    d.swatch:SetPoint("TOPLEFT",appearance,"TOPLEFT",20,-45)
    d.swatch:SetSize(29,29)
    d.color=button(appearance,170,27,"Choose Border Color",60,-45,function() pickColor(diamondSelected) end)
    d.style=button(appearance,185,27,"Border: Solid",256,-45,function()
        if not canEdit() then return end
        local styles={"solid","double","none"}
        local i=diamondSelected==0 and 1 or diamondSelected
        local current=api.GetDB().borderStyles[i] or "solid"
        -- Legacy Etched profiles render as Solid; cycle to Double on click.
        if current=="etched" then current="solid" end
        local nextStyle=styles[1]
        for j,style in ipairs(styles) do if style==current then nextStyle=styles[j%#styles+1]; break end end
        if eachSelected(function(n) return api.SetDiamondBorderStyle(n,nextStyle) end) then updateControls() end
    end)
    helpTip(appearance,232,-49,"Choose Border Color","Pick the accent color of the selected diamond border. ALL applies the chosen color to all diamonds.")
    helpTip(appearance,445,-49,"Border Style","Cycle between Solid, Double and None border styles. Affects the selected diamond or ALL.")
    label(appearance,"Border Brightness",16,-99,"GameFontNormal")
    d.bright=slider(appearance,"DiamondChosenBright",216,-97,234,25,150,5,function(v)
        if eachSelected(function(i) return api.SetBrightness(i,v/100) end) then updateControls() end
    end)
    d.brightText=label(appearance,"",475,-105,"GameFontHighlightSmall",62)
    helpTip(appearance,185,-99,"Border Brightness","Brightness of the selected diamond's border. This differs from opacity, which controls transparency.")
    diamondSharedSlider(appearance,"glow","Diamond Border Glow (All)",0,100,1,-131,"%d%%",true)
    helpTip(appearance,191,-133,"Diamond Border Glow (All)","Shared border-glow strength across diamonds. Does not change the brightness of spell icons.")
    diamondSharedSlider(appearance,"borderAlpha","Diamond Border Opacity",15,100,1,-165,"%d%%",true)
    helpTip(appearance,191,-167,"Diamond Border Opacity","Transparency of the colored borders. Lower values make the frame less visible; button opacity is controlled in Layout.")
    diamondSharedSlider(appearance,"borderWidth","Diamond Border Thickness",1,6,1,-199,"%d px",false)
    helpTip(appearance,191,-201,"Diamond Border Thickness","Width of the colored border in pixels. Does not modify spell-button padding.")
    label(appearance,"Metal Finish Opacity",16,-235,"GameFontNormal")
    CONTROLS.warlordFrame = slider(appearance,"WarlordFrameOpacity",216,-233,234,0,100,1,function(v)
        local look=_G.MixolasBarsObsidian
        if look and look.SetFrameOpacity then look.SetFrameOpacity(v/100);updateControls() end
    end)

    helpTip(appearance,187,-236,"Metal Finish Opacity","Transparency of the decorative metal finish around diamonds. The overall frame also follows diamond combat opacity.")
    local effects=d.sections[4]
    label(effects,"DIAMOND ILLUMINATION",16,-7,"GameFontNormalLarge")
    d.motion=button(effects,255,32,"Animation: Static",18,-58,function()
        if not canEdit() then return end
        local modes={"static","pulse","hum"}
        local i=diamondSelected==0 and 1 or diamondSelected
        local current=api.GetDB().glowMotions[i] or "static"
        local nextMotion="static"
        for j,mode in ipairs(modes) do if mode==current then nextMotion=modes[j%#modes+1]; break end end
        if eachSelected(function(n) return api.SetDiamondGlowMotion(n,nextMotion) end) then updateControls() end
    end)
    d.illumination=button(effects,255,30,"Lighting: Refined",287,-58,function()
        if canEdit() then
            local db=api.GetDB()
            local i=diamondSelected==0 and 1 or diamondSelected
            local current=(db.diamondIlluminationStyles and db.diamondIlluminationStyles[i]) or db.illuminationStyle or "refined"
            if eachSelected(function(n) return api.SetDiamondLighting(n,current=="classic" and "refined" or "classic") end) then updateControls() end
        end
    end)
    helpTip(effects,248,-33,"Illumination Animation","Choose Static, Pulse or Hum for the selected diamond's decorative lighting. These are visual effects only.")
    helpTip(effects,519,-33,"Illumination Lighting","Switch between Refined and Classic lighting treatments. Does not affect abilities or keybindings.")
    label(effects,"Static, Pulse and Hum (Trail removed: the old blocky strips obscured icons).",18,-113,"GameFontHighlightSmall",510)
    label(effects,"Effects illuminate the spell frame without changing icon spacing.",18,-140,"GameFontHighlightSmall",510)
    label(effects,"Colored border glow is adjusted in Border & Glow.",18,-184,"GameFontHighlightSmall",510)
    label(effects,"Lighting and animation remain independently configurable per diamond.",18,-213,"GameFontHighlightSmall",510)
end

-- Each regular bar has a focused editor with top-level bar selectors and
-- two public sections: Layout and Visibility. The diamond-owned bars 3-5
-- deliberately cannot create duplicate action buttons.
local function makeRegular(page)
    local r={tabs={},sections={},sectionNav={}}
    CONTROLS.regular=r
    label(page,"ACTION BARS",14,-4,"GameFontNormalLarge")
    -- Bars 3/4/5 belong to the diamonds, and have no independent editor.
    -- Retain those hidden secure bars internally; only remove their UI tabs.
    -- Pet Bar stays here in Action Bars, not in a separate top-level page.
    for idx,n in ipairs({1,2,6,7,8}) do
        r.tabs[n]=button(page,83,25,"Bar "..n,14+(idx-1)*91,-31,function()
            regularSelected=n
            regularPetSelected=false
            updateControls()
        end)
    end
    r.petTab=button(page,93,25,"Pet Bar",469,-31,function()
        regularPetSelected=true
        updateControls()
    end)
    helpTip(page,520,-31,"Pet Bar","Configure Blizzard's existing pet action buttons. A pet must be present for the managed bar to display.")
    r.petPage=CreateFrame("Frame",nil,page)
    r.petPage:SetPoint("TOPLEFT",page,"TOPLEFT",0,-67)
    r.petPage:SetSize(575,350)
    sectionPanel(r.petPage,5,-34,558,300,"subpage")
    r.petPage:Hide()
    for i,name in ipairs({"Layout","Visibility"}) do
        r.sectionNav[i]=subtabMark(button(page,262,26,name,14+(i-1)*280,-73,function()
            regularSection=i;updateControls()
        end))
        local f=CreateFrame("Frame",nil,page)
        f:SetPoint("TOPLEFT",page,"TOPLEFT",0,-112)
        f:SetSize(559,275)
        sectionPanel(f,0,0,559,275,"subpage")
        r.sections[i]=f
    end
    local layout=r.sections[1]
    r.title=label(layout,"",15,-4,"GameFontNormalLarge",515)
    label(layout,"Bar dimensions and spacing",15,-37,"GameFontHighlightSmall",515)
    local layoutFields={{"count","Visible slots",0,12,1}, {"rows","Rows",1,12,1},
        {"padding","Button padding",0,25,1}, {"scale","Bar scale",35,200,5}}
    for idx,item in ipairs(layoutFields) do
        local key,name,lo,hi,step=unpack(item)
        local y=-78-(idx-1)*47
        label(layout,name,15,y,"GameFontNormal")
        local sl=slider(layout,"RegV17_"..key,178,y-3,265,lo,hi,step,function(v)
            if api.SetRegularBar(regularSelected,key,key=="scale" and v/100 or v) then updateControls() end
        end)
        local value=label(layout,"",455,y-10,"GameFontHighlightSmall",82)
        r[key]={slider=sl,text=value}
    end
    -- The four dimensions share their existing values and slider pipeline.
    for idx,spec in ipairs({{"Visible Slots","How many action slots are visible on the selected bar (zero hides its buttons)."},
        {"Rows","Number of rows used to arrange the selected bar's buttons."},
        {"Button Padding","Space between buttons on this bar; separate from overall scale."},
        {"Bar Scale","Size of the whole bar without changing action assignments."}}) do
        helpTip(layout,151,-81-(idx-1)*47,spec[1],spec[2])
    end
    local visible=r.sections[2]
    r.visibleTitle=label(visible,"",15,-4,"GameFontNormalLarge",520)
    r.enable=button(visible,198,32,"Enable bar",16,-59,function()
        if not canEdit() then return end
        local c=api.GetDB().regularBars[regularSelected]
        if api.SetRegularBar(regularSelected,"enabled",not c.enabled) then updateControls() end
    end)
    r.empty=button(visible,198,32,"Show empty slots",228,-59,function()
        if not canEdit() then return end
        local c=api.GetDB().regularBars[regularSelected]
        if api.SetRegularBar(regularSelected,"showGrid",not c.showGrid) then updateControls() end
    end)
    helpTip(visible,202,-40,"Enable Action Bar","Enable or disable this Mixolas action bar without deleting its saved spells or shortcuts.")
    helpTip(visible,432,-64,"Show Empty Slots","Show unused buttons on the selected action bar. Useful when arranging or binding additional actions.")
    -- Each regular bar has independent opacity for both combat states.
    -- Existing profiles inherit their former single alpha for both.
    for _,spec in ipairs({{"alphaOut","Out of Combat Opacity","RegV17_alphaOut",-119},
        {"alphaCombat","In Combat Opacity","RegV17_alphaCombat",-173}}) do
        local key,title,unique,y=unpack(spec)
        label(visible,title,18,y,"GameFontNormal")
        local field={}
        field.slider=slider(visible,unique,242,y,204,10,100,5,function(v)
            if api.SetRegularBar(regularSelected,key,v/100) then updateControls() end
        end)
        field.text=label(visible,"",459,y-10,"GameFontHighlightSmall",68)
        r[key]=field
    end
    helpTip(visible,218,-120,"Out of Combat Opacity","Transparency of the selected action bar when you are not fighting. Does not change click behavior.")
    helpTip(visible,218,-174,"In Combat Opacity","Transparency of the selected action bar in combat. Automatically applied on entering and leaving combat.")
    label(visible,"Opacity changes automatically when combat begins or ends.",18,-239,"GameFontHighlightSmall",530)
end

local function makeUtility(page)
    label(page,"PET BAR",16,-7,"GameFontNormalLarge")
    label(page,"Native pet actions; uses the existing pet bar, not duplicate buttons.",18,-31,"GameFontHighlightSmall",535)
    -- Only one native group exists. An extra selector labelled "Pet Bar"
    -- here had no visible effect and confused users; keep the actual tab.
    CONTROLS.utility.title=label(page,"",20,-112,"GameFontNormalLarge")
    CONTROLS.utility.enable=button(page,177,28,"Manage this group",20,-141,function()
        if not canEdit() then return end
        local d=api.GetDB().utilityBars[utilitySelected]
        api.SetUtilityBar(utilitySelected,"enabled",not d.enabled)
        updateControls()
    end)
    CONTROLS.utility.visible=button(page,178,28,"Hide group",223,-141,function()
        if not canEdit() then return end
        local d=api.GetDB().utilityBars[utilitySelected]
        api.SetUtilityBar(utilitySelected,"visible",not d.visible)
        updateControls()
    end)
    helpTip(page,199,-145,"Manage Pet Bar","Allow Mixolas to manage the existing native Pet Bar group. It does not create new pet action slots.")
    helpTip(page,405,-145,"Show / Hide Pet Bar","Toggle visibility of the managed Pet Bar group without changing pet abilities.")
    for idx,t in ipairs({{"scale","Scale",40,200},
        {"alphaOut","Out of Combat Opacity",10,100},
        {"alphaCombat","In Combat Opacity",10,100},
        {"padding","Spacing",0,16},{"rows","Rows",1,10}}) do
        local key,name,lo,hi=unpack(t)
        local y=-175-(idx-1)*30
        label(page,name,18,y,"GameFontHighlightSmall")
        local value=label(page,"",480,y-13,"GameFontHighlightSmall",65)
        local sl=slider(page,"Utility_"..key,167,y-10,285,lo,hi,1,function(v)
            local data=(key=="scale" or key=="alphaOut" or key=="alphaCombat") and v/100 or v
            if api.SetUtilityBar(utilitySelected,key,data) then updateControls() end
        end)
        CONTROLS.utility[key]={slider=sl,text=value}
    end
    for idx,spec in ipairs({{"Pet Bar Scale","Size of the managed Pet Bar as a whole."},
        {"Pet Bar Out of Combat Opacity","Pet Bar transparency outside combat; separate from combat transparency."},
        {"Pet Bar In Combat Opacity","Pet Bar transparency in combat; applies automatically at combat transitions."},
        {"Pet Bar Spacing","Space between the native Pet Bar action buttons."},
        {"Pet Bar Rows","How many rows the Pet Bar uses for its managed layout."}}) do
        helpTip(page,143,-185-(idx-1)*30,spec[1],spec[2])
    end
    label(page,"Opacity applies when Mixolas manages the Pet Bar.",18,-326,"GameFontHighlightSmall",540)
end

local function makeBindings(page)
    sectionPanel(page,9,-40,560,154)
    sectionPanel(page,9,-207,560,127)
    sectionPanel(page,9,-337,560,62)
    label(page,"MOUSEOVER KEYBIND EDITOR",17,-7,"GameFontNormalLarge")
    label(page,"Mixolas slots: up to 3 custom keys. Pet Bar: native WoW bindings.",20,-49,"GameFontHighlight",545)
    label(page,"Reusing a key immediately moves it to the hovered slot (no confirmation).",20,-79,"GameFontHighlightSmall",560)
    local note=label(page,"assigned addon shortcuts override conflicting bindings until removed.",20,-99,"GameFontHighlightSmall",560)
    note:SetText("Escape clears hovered bindings; Save & Exit commits, Cancel discards.")
    note:SetTextColor(1,0.72,0.5)
    button(page,290,36,"ENTER BINDING MODE",20,-147,function()
        if not canEdit() then return end
        if window then window:Hide() end
        if not api.StartBindingMode(window) and window then window:Show() end
    end)
    button(page,248,36,"IMPORT / EXPORT",330,-147,function()
        if canEdit() then api.OpenBindingImportExport() end
    end)
    helpTip(page,291,-126,"Mouseover Binding Mode","Hover a Mixolas action button and press a keyboard/controller shortcut. Reassigning an occupied key moves it immediately. Save & Exit or Cancel.")
    helpTip(page,557,-126,"Import / Export","Back up or load current profile shortcuts. Choose Mixolas bar keys (MXB1), native WoW keys (MXBN1), or both (MXBA1).")
    label(page,"HOW IT WORKS",20,-220,"GameFontNormal")
    label(page,"1. Enter binding mode. Hover an action or pet button.\n" ..
        "2. Press your key combination (for example Shift+Ctrl+1).\n" ..
        "3. Repeat, then click Save & Exit. Or Cancel to discard changes.\n" ..
        "4. ESCAPE clears the hovered button's bindings (without leaving).\n" ..
        "5. Export a shareable text string or import one in the next window.",
        20,-250,"GameFontHighlight",560)
    CONTROLS.clearBarHeader=label(page,"KEYBINDING MANAGEMENT",20,-344,"GameFontNormal",570)
    CONTROLS.clearBarBindings=button(page,270,29,"CLEAR BAR KEYBINDS",20,-364,function()
        if not canEdit() then return end
        if api.OpenBindingClearManager then api.OpenBindingClearManager()
        elseif api.Say then api.Say("Keybinding management has not loaded.") end
    end)
    helpTip(page,293,-368,"Clear Bar Keybinds","Clear bar-related keybindings in the active profile after two warnings. Does not reset unrelated movement or interface keys. Can be undone or redone.")
    CONTROLS.bindInfo=label(page,"Two-stage confirmation | Current profile only",310,-370,"GameFontHighlightSmall",270)
end

local function makeButtons(page)
    sectionPanel(page,9,-51,560,127)
    sectionPanel(page,9,-186,560,55)
    sectionPanel(page,9,-246,560,150)
    label(page,"BUTTON APPEARANCE & BEHAVIOR",16,-7,"GameFontNormalLarge")
    label(page,"Settings apply to both diamonds and regular action bars.",18,-34,"GameFontHighlightSmall",540)

    -- Three visual sections, same nine settings and same saved profile keys.
    label(page,"TEXT & LABELS",20,-56,"GameFontNormal",545)
    CONTROLS.hotkeyVisibility = button(page,205,28,"Show hotkey text",20,-79,function()
        if canEdit() and api.Change("showHotkeys",not api.GetDB().showHotkeys) then updateControls() end
    end)
    helpTip(page,232,-83,"Show Hotkey Text","Show the keyboard/controller shortcut assigned to each action button. This changes display only, not the bindings.")
    CONTROLS.macroNames = button(page,210,28,"Show macro names: ON",294,-79,function()
        if canEdit() and api.Change("showMacroNames",not api.GetDB().showMacroNames) then updateControls() end
    end)
    helpTip(page,512,-83,"Show Macro Names","Show the macro name on button icons. This does not rename or modify macros.")

    label(page,"Hotkey font size",20,-121,"GameFontHighlightSmall")
    helpTip(page,149,-118,"Hotkey Font Size","Text size of the shortcut label shown on action buttons. Does not change keybindings.")
    CONTROLS.hotkeySize = slider(page,"HotkeyFont",185,-120,260,6,12,1,function(v)
        if api.Change("hotkeyFontSize",v) then updateControls() end
    end)
    CONTROLS.hotkeySizeLabel = label(page,"",461,-128,"GameFontHighlightSmall",70)

    label(page,"Item count font size",20,-155,"GameFontHighlightSmall")
    helpTip(page,149,-152,"Item Count Font Size","Text size of stack counts for consumables and other items on the action buttons.")
    CONTROLS.itemCountSize = slider(page,"ItemCountFont",185,-154,260,6,18,1,function(v)
        if api.Change("itemCountFontSize",v) then updateControls() end
    end)

    label(page,"BUTTON FEEDBACK",20,-190,"GameFontNormal",545)
    CONTROLS.flashToggle = button(page,250,28,"Colored press flash: ON",20,-213,function()
        if not canEdit() then return end
        local flash=_G.MixolasBarsActivationFlash
        local cfg=flash and flash.GetSettings and flash.GetSettings()
        if cfg and flash.SetEnabled then
            flash.SetEnabled(not cfg.enabled)
            updateControls()
        end
    end)
    helpTip(page,280,-217,"Colored Press Flash","Brief colored highlight when an action is pressed. Cosmetic feedback only; it does not cast or alter spells.")

    label(page,"AVAILABILITY & COOLDOWNS",20,-252,"GameFontNormal",545)
    label(page,"Out-of-range icon brightness",20,-278,"GameFontHighlightSmall")
    helpTip(page,228,-274,"Out-of-Range Icon Brightness","How bright a button icon stays when its action is out of range. Out-of-range dimming requires a target.")
    CONTROLS.rangeDim = slider(page,"RangeDim",260,-277,190,20,100,5,function(v)
        if api.Change("rangeDim",v/100) then updateControls() end
    end)
    CONTROLS.rangeDimLabel = label(page,"",461,-286,"GameFontHighlightSmall",70)

    label(page,"Combat unusable brightness",20,-311,"GameFontHighlightSmall")
    helpTip(page,228,-308,"Combat Unusable Brightness","How bright an action icon remains when the action cannot be used during combat. This fade is always active.")
    CONTROLS.combatDim=slider(page,"CombatDim",260,-309,190,20,100,5,function(v)
        if api.Change("combatDim",v/100) then updateControls() end
    end)
    CONTROLS.combatDimLabel=label(page,"",461,-318,"GameFontHighlightSmall",60)

    CONTROLS.gcd=button(page,225,27,"GCD clockwise sweep: ON",20,-350,function()
        if canEdit() and api.Change("gcdSweep",not api.GetDB().gcdSweep) then updateControls() end
    end)
    helpTip(page,252,-353,"GCD Clockwise Sweep","Show the global cooldown (GCD) sweep clockwise on the affected action button icons.")
    label(page,"GCD shading",291,-358,"GameFontHighlightSmall")
    helpTip(page,374,-354,"GCD Shading","Darkness of the overlay during a global cooldown sweep. This does not change cooldown timing.")
    CONTROLS.gcdDarkness=slider(page,"GcdDarkness",400,-353,86,10,80,5,function(v)
        if api.Change("gcdDarkness",v/100) then updateControls() end
    end)
end

-- Custom frames are selected by their own captions. These display helpers
-- never touch the stable numeric frame IDs used by saved profiles/layouts.
local function customFrameName(c,id)
    local name=c and type(c.label)=="string" and c.label:match("^%s*(.-)%s*$") or ""
    return name~="" and name or ("Frame "..id)
end
-- The editor fits six frame selectors per bank. Abbreviate only what is
-- displayed on the tab; hovering reveals the complete saved caption.
-- Deleting a custom frame creates a tombstone rather than renumbering the
-- SavedVariables array. The selector shows only surviving IDs, in ID order.
local function liveCustomFrameIds()
    local ids={}
    for id,c in ipairs((api.GetDecor and api.GetDecor()) or {}) do
        if c and not c.deleted then ids[#ids+1]=id end
    end
    return ids
end
local function customFrameTabName(name)
    local chars={}
    local i=1
    while i<=#name do
        local b=name:byte(i)
        local size=b>=240 and 4 or b>=224 and 3 or b>=192 and 2 or 1
        chars[#chars+1]=name:sub(i,i+size-1)
        i=i+size
    end
    if #chars<=10 then return name end
    return table.concat(chars,"",1,7).."..."
end

-- Frame editor: independent pearl-style grouping objects; nothing in this
-- module changes a spell action, diamond color or keybinding.
local function makeFrames(page)
    local d={sections={},sectionNav={},studio={}}
    CONTROLS.decor=d
    local home=page
    d.modeAttached=subtabMark(button(home,250,27,"ATTACHED BAR FRAMES",15,-3,function()
        frameMode="attached";updateControls()
    end))
    d.modeCustom=subtabMark(button(home,250,27,"CUSTOM DECORATIVE FRAMES",289,-3,function()
        frameMode="custom";updateControls()
    end))
    local custom=CreateFrame("Frame",nil,home)
    custom:SetPoint("TOPLEFT",home,"TOPLEFT",0,-37)
    custom:SetSize(575,362)
    sectionPanel(custom,1,0,570,360,"subpage")
    d.customRoot=custom
    page=custom
    d.title=label(page,"CUSTOM FRAMES",15,-4,"GameFontNormalLarge",535)
    -- Three adjacent actions must not overlap their 19 px ? help buttons.
    -- Each clickable surface gets a real gutter, including the Create help
    -- icon that formerly covered the left edge of the Delete button.
    d.create=button(page,125,26,"Create frame",15,-30,function()
        if not canEdit() then return end
        local id=api.AddDecor()
        if id then
            frameSelected=id
            profileNotice="Frame created and saved automatically to the active profile."
            updateControls()
        end
    end)
    helpTip(page,145,-33,"Create Decorative Frame","Add a freely positioned decorative frame to the active profile. It does not consume any action slots.")
    d.delete=button(page,174,26,"Delete selected frame",185,-30,function()
        if not canEdit() then return end
        if not api.RemoveDecor or not api.ShowConfirm then
            if api.Say then api.Say("Custom frame deletion is not available.") end
            return
        end
        local frames=api.GetDecor and api.GetDecor()
        local id=frameSelected
        local c=frames and frames[id]
        if not c or c.deleted then
            if api.Say then api.Say("Select an existing custom frame to delete.") end
            return
        end
        local displayName=customFrameName(c,id)
        -- Preserve the currently selected frame and saved profile across the
        -- modal. Switching profiles before accepting never deletes the wrong
        -- frame even if its numeric ID coincides with this one.
        api.ShowConfirm("Delete custom frame?",
            "Delete '"..displayName.."' from this profile? The frame will disappear from the list. Use Undo to restore it.",
            function()
                if not canEdit() then return end
                local current=api.GetDecor and api.GetDecor()
                if current~=frames or current[id]~=c or c.deleted then
                    if api.Say then api.Say("Frame or profile changed; deletion cancelled. Select the frame again.") end
                    return
                end
                if api.RemoveDecor(id) then
                    local ids=liveCustomFrameIds()
                    local nextId=ids[1] or 0
                    for _,candidate in ipairs(ids) do
                        if candidate>id then nextId=candidate;break end
                        nextId=candidate
                    end
                    frameSelected=nextId
                    updateControls()
                    if api.Say then api.Say("Deleted custom frame '"..displayName.."'. Undo to restore it.") end
                elseif api.Say then
                    api.Say("Could not delete '"..displayName.."'. No frame was changed.")
                end
            end,"DELETE FRAME")
    end)
    helpTip(page,365,-33,"Delete Selected Frame","Remove the selected decorative frame from this profile after confirmation. Undo can restore the deleted frame; Hide Frame only conceals it.")
    -- Visible tabs select each saved custom frame directly. Older Previous / Next
    -- were insufficient once multiple frames existed. Show six tabs per bank.
    d.tabs={}
    d.bank=1
    for i=1,6 do
        local pos=i
        local b=button(page,76,24,"",30+(i-1)*86,-57,function()
            local id=d.visibleIds and d.visibleIds[(d.bank-1)*6+pos]
            if id then frameSelected=id;updateControls() end
        end)
        b:SetScript("OnEnter",function(self)
            if not GameTooltip then return end
            local id=d.visibleIds and d.visibleIds[(d.bank-1)*6+pos]
            local c=id and ((api.GetDecor and api.GetDecor() or {})[id])
            if not c then return end
            GameTooltip:SetOwner(self,"ANCHOR_TOP")
            GameTooltip:AddLine(customFrameName(c,id),1,0.82,0.35)
            GameTooltip:AddLine("Custom frame "..id.." | Click to edit",0.9,0.9,0.9)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave",function()
            if GameTooltip then GameTooltip:Hide() end
        end)
        d.tabs[i]=b
    end
    d.bankPrev=button(page,23,23,"<",3,-57,function()
        local ids=d.visibleIds or liveCustomFrameIds()
        local bank=math.max(1,d.bank-1)
        frameSelected=ids[(bank-1)*6+1] or frameSelected
        updateControls()
    end)
    d.bankNext=button(page,23,23,">",552,-57,function()
        local ids=d.visibleIds or liveCustomFrameIds()
        if d.bank*6>=#ids then return end
        frameSelected=ids[d.bank*6+1] or frameSelected
        updateControls()
    end)
    d.visible=button(page,143,26,"Hide frame",403,-30,function()
        if not canEdit() then return end
        local c=api.GetDecor()[frameSelected]
        if c and api.SetDecor(frameSelected,"visible",c.visible==false) then updateControls() end
    end)
    helpTip(page,551,-33,"Show / Hide Decorative Frame","Toggle the selected custom decorative frame's visibility without deleting it.")
    for n,name in ipairs({"Dimensions","Label","Border"}) do
        d.sectionNav[n]=subtabMark(button(page,171,27,name,15+(n-1)*183,-90,function()
            frameSection=n;updateControls()
        end))
        local f=CreateFrame("Frame",nil,page)
        f:SetPoint("TOPLEFT",page,"TOPLEFT",0,-121)
        f:SetSize(558,254)
        sectionPanel(f,0,0,558,254,"subpage")
        d.sections[n]=f
    end
    local dim=d.sections[1]
    label(dim,"FRAME POSITION & DIMENSIONS",16,-6,"GameFontNormalLarge")
    for idx,item in ipairs({{"width","Width",40,700,1},{"height","Height",40,550,1},
        {"alpha","Opacity",10,100,5}}) do
        local key,name,lo,hi,step=unpack(item)
        local y=-60-(idx-1)*53
        label(dim,name,16,y,"GameFontNormal")
        local sl=slider(dim,"FrameV17_"..key,197,y-1,250,lo,hi,step,function(value)
            if api.SetDecor(frameSelected,key,key=="alpha" and value/100 or value) then updateControls() end
        end)
        local val=label(dim,"",466,y-10,"GameFontHighlightSmall",76)
        d[key]={slider=sl,value=val}
    end
    for idx,spec in ipairs({{"Frame Width","Width of the selected custom decorative frame in pixels."},
        {"Frame Height","Height of the selected custom decorative frame in pixels."},
        {"Frame Opacity","Transparency of this decorative frame; independent of action buttons."}}) do
        helpTip(dim,166,-63-(idx-1)*53,spec[1],spec[2])
    end
    button(dim,157,29,"Make square",16,-222,function()
        local c=api.GetDecor()[frameSelected]
        if c and canEdit() and api.SetDecor(frameSelected,"height",c.width) then updateControls() end
    end)
    label(dim,"Unlock Layout to move this frame using its full editing mask.",190,-229,"GameFontHighlightSmall",350)

    helpTip(dim,175,-225,"Make Square","Set the selected decorative frame's height equal to its current width.")
    local txt=d.sections[2]
    label(txt,"LABEL OPTIONS",16,-7,"GameFontNormalLarge")
    label(txt,"Caption (Enter saves)",16,-37,"GameFontNormal")
    local input=CreateFrame("EditBox","MixolasBarsFrameLabelEditor",txt,"InputBoxTemplate")
    input:SetSize(287,26)
    input:SetPoint("TOPLEFT",txt,"TOPLEFT",213,-34)
    input:SetAutoFocus(false)
    input:SetMaxLetters(48)
    input:SetScript("OnEnterPressed",function(self)
        if canEdit() and api.SetDecor(frameSelected,"label",self:GetText()) then self:ClearFocus();updateControls() end
    end)
    input:SetScript("OnEscapePressed",function(self) self:ClearFocus();updateControls() end)
    helpTip(txt,187,-37,"Custom Frame Caption","Edit the caption for the selected frame. Press Enter to save; Escape cancels editing.")
    d.label=input
    d.sideButton=button(txt,171,26,"Change label side",16,-69,function()
        if canEdit() and api.SetDecor(frameSelected,"labelSide",true) then updateControls() end
    end)
    d.side=label(txt,"",209,-76,"GameFontHighlightSmall",125)
    button(txt,168,26,"Cycle outline: Thin/Thick",16,-103,function()
        if canEdit() and api.SetDecor(frameSelected,"fontOutline",true) then updateControls() end
    end)
    helpTip(txt,189,-73,"Change Label Side","Move the custom frame caption to another side of the border.")
    helpTip(txt,192,-107,"Label Font Outline","Cycle the custom frame caption's font outline between Thin and Thick. This does not turn the outline off.")

    -- Keep all label placement in one page. Compact rows fit the existing
    -- Frame section without a scrollable region or overlapping slider fields.
    local labelRows={
        {key="fontSize",text="Font size",y=-142,lo=8,hi=30,description="Size of the selected decorative frame caption text."},
        {key="labelGap",text="Distance from border",y=-170,lo=0,hi=20,description="Gap from the chosen edge. Works on Top, Bottom, Left and Right labels."},
        {key="labelOffsetX",text="Label X offset",y=-198,lo=-150,hi=150,description="Move only this label horizontally. Negative is left; positive is right. Does not move the decorative frame."},
        {key="labelOffsetY",text="Label Y offset",y=-226,lo=-150,hi=150,description="Move only this label vertically. Negative is down; positive is up. Does not move the decorative frame."},
    }
    for _,spec in ipairs(labelRows) do
        label(txt,spec.text,16,spec.y,"GameFontHighlightSmall",154)
        local key=spec.key
        local sl=slider(txt,"FrameV17_"..key,194,spec.y,250,spec.lo,spec.hi,1,function(v)
            if api.SetDecor(frameSelected,key,v) then updateControls() end
        end)
        d[key]={slider=sl,value=label(txt,"",466,spec.y-7,"GameFontHighlightSmall",70)}
        helpTip(txt,169,spec.y-3,spec.text,spec.description)
    end
    local border=d.sections[3]
    label(border,"FRAME BORDER",16,-7,"GameFontNormalLarge")
    button(border,174,30,"Choose border color",16,-58,function()
        if not canEdit() then return end
        local picker=ColorPickerFrame
        local c=api.GetDecor()[frameSelected]
        if not picker or not c then return end
        local id=frameSelected
        local old={c.color[1],c.color[2],c.color[3]}
        local function apply() local rr,g,b=picker:GetColorRGB();api.SetDecorColor(id,rr,g,b) end
        local function cancel() api.SetDecorColor(id,old[1],old[2],old[3]);updateControls() end
        if picker.SetupColorPickerAndShow then
            picker:SetupColorPickerAndShow({r=old[1],g=old[2],b=old[3],hasOpacity=false,
                swatchFunc=apply,func=apply,cancelFunc=cancel})
        else
            picker.func=apply;picker.cancelFunc=cancel;picker.hasOpacity=false
            picker:SetColorRGB(old[1],old[2],old[3]);picker:Hide();picker:Show()
        end
    end)
    helpTip(border,195,-62,"Custom Border Color","Select the border color for this decorative frame without changing diamond borders.")
    label(border,"Border thickness",16,-126,"GameFontNormal")
    d.thickness={}
    d.thickness.slider=slider(border,"FrameV17_thickness",196,-126,250,1,12,1,function(v)
        if api.SetDecor(frameSelected,"thickness",v) then updateControls() end
    end)
    d.thickness.value=label(border,"",465,-135,"GameFontHighlightSmall",66)
    label(border,"Left label: bottom-to-top; right label: top-to-bottom.",16,-190,"GameFontHighlightSmall",525)
    label(border,"Decorative frames never consume action slots.",16,-211,"GameFontHighlightSmall",525)
    helpTip(border,169,-127,"Custom Border Thickness","Border line width for the selected decorative frame, in pixels.")
    -- The original custom Frames editor above is preserved verbatim in its own
    -- mode. Attached frames are created on existing BAR hosts, not user drag-
    -- positioned rectangles. They follow movement/scale with ZERO slot edits.
    local a=CreateFrame("Frame",nil,home)
    a:SetPoint("TOPLEFT",home,"TOPLEFT",0,-37)
    a:SetSize(575,359)
    d.attachedRoot=a
    local xTargets={{"BAR 1","bar1"},{"BAR 2","bar2"},{"DIAMONDS","diamonds"},{"PET BAR","pet"}}
    d.studioTargets={}
    for i,item in ipairs(xTargets) do
        local target=item[2]
        d.studioTargets[i]=button(a,128,27,item[1],12+(i-1)*137,-4,function()
            frameStudioTarget=target
            frameStudioPage=1
            updateControls()
        end)
    end
    d.studioReset=button(a,82,24,"Reset",485,-69,function()
        if canEdit() and api.ResetFrameStudioStyle and api.ResetFrameStudioStyle(frameStudioTarget) then updateControls() end
    end)
    helpTip(a,464,-70,"Reset Attached Frame","Reset the selected attached frame's style options to their defaults. Does not delete buttons, macros or bindings.")
    d.studioNumbers={}
    for i=0,8 do
        local target=(i==0) and "diamonds" or "d"..i
        d.studioNumbers[i]=button(a,55,24,i==0 and "ALL" or tostring(i),13+i*61,-41,function()
            frameStudioTarget=target
            updateControls()
        end)
    end
    d.studioInfo=label(a,"",15,-75,"GameFontHighlightSmall",448)
    d.studioPageNav={}
    d.studioPages={}
    for i,name in ipairs({"FRAME STYLE","ACTIVE FIELD","SIZE & FIT","LABEL"}) do
        d.studioPageNav[i]=subtabMark(button(a,132,26,name,12+(i-1)*138,-97,function()
            frameStudioPage=i;updateControls()
        end))
        local section=CreateFrame("Frame",nil,a)
        section:SetPoint("TOPLEFT",a,"TOPLEFT",0,-127)
        section:SetSize(560,231)
        sectionPanel(section,0,0,560,231,"subpage")
        d.studioPages[i]=section
    end
    local look=d.studioPages[1]
    label(look,"Choose an actual frame style (not just a border color)",12,-1,"GameFontNormal",535)
    d.studioStyles={}
    local styleButtons={
        {"None","off"},{"Minimal","minimal"},{"Forged","forged"},
    }
    for i,item in ipairs(styleButtons) do
        local style=item[2]
        d.studioStyles[i]=button(look,82,26,item[1],12+(i-1)*90,-28,function()
            if canEdit() and api.SetFrameStudioOption and api.SetFrameStudioOption(frameStudioTarget,"style",style) then updateControls() end
        end)
    end
    helpTip(look,296,-32,"Attached Frame Style","Choose None, Minimal or Forged. Minimal is a slim, subdued housing; Forged has a more pronounced metal edge and brighter lighting. Existing saved Shield choices are preserved but cannot be newly selected.")
    local function studioSlider(tab,key,caption,y,minVal,maxVal,step,converter,format)
        label(tab,caption,16,y,"GameFontNormal",200)
        -- Every attached-frame slider gets its own contextual '?' beside the caption.
        local explanations={
            opacity="Transparency of the attached frame/armor artwork. Final visibility also follows the selected diamond's combat opacity.",
            illumination="Brightness of the attached housing's lighting accents; does not change spell icon brightness.",
            fieldStrength="Strength of the modifier-reactive aura that appears around the active diamond.",
            fieldSize="How far the modifier field extends beyond the frame in pixels.",
            scale="Scale of the decorative housing, without resizing spell action icons.",
            padding="Extra visual spacing inside the housing, without changing bar button padding.",
            x="Move the decorative housing horizontally relative to its bar or diamond, without moving actions.",
            y="Move the decorative housing vertically relative to its bar or diamond, without moving actions.",
            labelSize="Font size of the attached frame label, in points.",
            labelGap="Gap between the attached label and its frame edge.",
            labelShift="Slide the label along its selected frame edge in pixels."
        }
        helpTip(tab,178,y-1,caption,explanations[key] or "Customize this attached frame setting.")
        local textLabel=label(tab,"",470,y-12,"GameFontHighlight",74)
        local ctl=slider(tab,"FrameStudio_"..key,201,y-5,244,minVal,maxVal,step,function(v)
            if api.SetFrameStudioOption and api.SetFrameStudioOption(frameStudioTarget,key,converter(v)) then updateControls() end
        end)
        d.studio[key]={slider=ctl,value=textLabel,format=format}
    end
    studioSlider(look,"opacity","Frame / armor opacity",-83,0,100,5,function(v)return v/100 end,"percent")
    studioSlider(look,"illumination","Frame illumination",-146,0,100,5,function(v)return v/100 end,"percent")
    label(look,"Minimal: restrained outline  |  Forged: bolder metal and luminous edge",14,-211,"GameFontHighlightSmall",545)
    local field=d.studioPages[2]
    label(field,"DIAMOND MODIFIER FIELD",16,-4,"GameFontNormalLarge",510)
    label(field,"Only the matching modifier triggers the outer aura; inactive diamonds stay slim.",16,-32,"GameFontHighlightSmall",535)
    studioSlider(field,"fieldStrength","Active field strength",-76,0,100,5,function(v)return v/100 end,"percent")
    studioSlider(field,"fieldSize","Outer field reach",-139,0,28,1,function(v)return v end,"px")
    label(field,"The field sits behind armor and icons. It does not alter spell gaps, bar size or position.",16,-204,"GameFontHighlightSmall",535)
    local fit=d.studioPages[3]
    label(fit,"Frame controls never change spell icon size or bar padding.",16,-5,"GameFontHighlightSmall",538)
    studioSlider(fit,"scale","Housing scale",-37,70,150,5,function(v)return v/100 end,"percent")
    studioSlider(fit,"padding","Frame padding",-88,0,16,1,function(v)return v end,"px")
    studioSlider(fit,"x","Horizontal offset",-139,-48,48,1,function(v)return v end,"px")
    studioSlider(fit,"y","Vertical offset",-190,-48,48,1,function(v)return v end,"px")
    -- Labels belong to attached frames; they never increase action-button gaps.
    local lab=d.studioPages[4]
    label(lab,"Frame label (Enter saves)",15,-3,"GameFontNormal")
    d.studioLabel=CreateFrame("EditBox","MixolasBarsStudioAttachedLabel",lab,"InputBoxTemplate")
    d.studioLabel:SetSize(353,27)
    d.studioLabel:SetPoint("TOPLEFT",lab,"TOPLEFT",22,-29)
    d.studioLabel:SetAutoFocus(false)
    d.studioLabel:SetMaxLetters(48)
    helpTip(lab,190,-4,"Attached Frame Label","Edit the selected attached frame label. Press Enter to save the new text, or Escape to cancel.")
    d.studioLabel:SetScript("OnEnterPressed",function(self)
        if not canEdit() then self:ClearFocus();updateControls();return end
        if api.SetFrameStudioOption and api.SetFrameStudioOption(frameStudioTarget,"label",self:GetText()) then
            self:ClearFocus();updateControls()
        end
    end)
    d.studioLabel:SetScript("OnEscapePressed",function(self)self:ClearFocus();updateControls() end)
    d.studioLabelToggle=button(lab,141,27,"Label: ON",399,-27,function()
        if not canEdit() then return end
        local c=api.GetFrameStudioStyle and api.GetFrameStudioStyle(frameStudioTarget)
        if c and api.SetFrameStudioOption(frameStudioTarget,"labelEnabled",not c.labelEnabled) then updateControls() end
    end)
    helpTip(lab,542,-31,"Enable Frame Label","Show or hide the selected attached frame label without clearing its text.")
    local sides={"TOP","BOTTOM","LEFT","RIGHT"}
    local outlines={"NONE","OUTLINE","THICKOUTLINE"}
    local palette={"match","white","gold"}
    d.studioLabelSide=button(lab,171,25,"Position: Top",15,-70,function()
        if not canEdit() then return end
        local c=api.GetFrameStudioStyle and api.GetFrameStudioStyle(frameStudioTarget)
        if not c then return end
        local idx=1
        for i,v in ipairs(sides) do if v==c.labelSide then idx=i end end
        if api.SetFrameStudioOption(frameStudioTarget,"labelSide",sides[idx%#sides+1]) then updateControls() end
    end)
    d.studioLabelOutline=button(lab,172,25,"Outline: Thin",197,-70,function()
        if not canEdit() then return end
        local c=api.GetFrameStudioStyle and api.GetFrameStudioStyle(frameStudioTarget)
        if not c then return end
        local idx=1
        for i,v in ipairs(outlines) do if v==c.labelOutline then idx=i end end
        if api.SetFrameStudioOption(frameStudioTarget,"labelOutline",outlines[idx%#outlines+1]) then updateControls() end
    end)
    d.studioLabelColor=button(lab,172,25,"Color: Modifier",379,-70,function()
        if not canEdit() then return end
        local c=api.GetFrameStudioStyle and api.GetFrameStudioStyle(frameStudioTarget)
        if not c then return end
        local idx=1
        for i,v in ipairs(palette) do if v==c.labelColor then idx=i end end
        if api.SetFrameStudioOption(frameStudioTarget,"labelColor",palette[idx%#palette+1]) then updateControls() end
    end)
    helpTip(lab,164,-74,"Label Position","Choose the frame edge on which the label appears: top, bottom, left or right.")
    helpTip(lab,346,-74,"Label Outline","Cycle the label's outline between none, thin and thick.")
    helpTip(lab,529,-74,"Label Color","Set the label to its modifier color, white or gold.")
    studioSlider(lab,"labelSize","Font size",-109,8,26,1,function(v)return v end,"pt")
    studioSlider(lab,"labelGap","Distance from frame",-152,0,30,1,function(v)return v end,"px")
    studioSlider(lab,"labelShift","Along-edge offset",-195,-90,90,1,function(v)return v end,"px")
end

-- Live account profiles: choose, create, copy, delete, and restore snapshots.
-- No Load Selected or Save Changes buttons: edits save to the active profile.
local renameDialog
local function showProfileRenameDialog(profileName,onRename)
    if not renameDialog then
        local d=CreateFrame("Frame","MixolasBarsRenameProfileWindow",UIParent,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        d:SetSize(440,166)
        d:SetPoint("CENTER",UIParent,"CENTER",0,0)
        d:SetFrameStrata("FULLSCREEN_DIALOG")
        d:SetFrameLevel(500)
        d:SetClampedToScreen(true)
        if d.SetBackdrop then
            d:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=24,
                insets={left=5,right=5,top=5,bottom=5}})
        end
        local title=d:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        title:SetPoint("TOP",d,"TOP",0,-16)
        title:SetText("Rename Profile")
        d.name=CreateFrame("EditBox",nil,d,"InputBoxTemplate")
        d.name:SetSize(352,29)
        d.name:SetPoint("TOP",d,"TOP",0,-62)
        d.name:SetAutoFocus(false)
        d.name:SetMaxLetters(32)
        local accept=CreateFrame("Button",nil,d,"UIPanelButtonTemplate")
        accept:SetSize(156,27)
        accept:SetPoint("BOTTOM",d,"BOTTOM",-83,15)
        accept:SetText("RENAME PROFILE")
        local cancel=CreateFrame("Button",nil,d,"UIPanelButtonTemplate")
        cancel:SetSize(156,27)
        cancel:SetPoint("BOTTOM",d,"BOTTOM",83,15)
        cancel:SetText("CANCEL")
        accept:SetScript("OnClick",function()
            local newName=d.name:GetText()
            d:Hide()
            if d.onAccept then d.onAccept(d.originalName,newName) end
        end)
        cancel:SetScript("OnClick",function() d:Hide() end)
        d.name:SetScript("OnEnterPressed",function() accept:Click() end)
        d.name:SetScript("OnEscapePressed",function() d:Hide() end)
        if UISpecialFrames then table.insert(UISpecialFrames,"MixolasBarsRenameProfileWindow") end
        d:Hide()
        renameDialog=d
    end
    renameDialog.originalName=profileName
    renameDialog.onAccept=onRename
    renameDialog.name:SetText(profileName)
    renameDialog.name:HighlightText(0)
    renameDialog:Show()
    renameDialog.name:SetFocus()
end
local function makeProfiles(page)
    local p={}
    CONTROLS.profile=p
    sectionPanel(page,8,-76,560,112)
    sectionPanel(page,8,-188,560,64)
    sectionPanel(page,8,-259,560,46)
    sectionPanel(page,8,-305,560,94)
    label(page,"PROFILES",16,-5,"GameFontNormalLarge")
    label(page,"Personal/shared profiles can be renamed or deleted. Only MIXOLAS is protected.",16,-33,"GameFontHighlightSmall",555)
    label(page,"Editing MIXOLAS creates a personal profile. Personal changes auto-save.",16,-53,"GameFontHighlightSmall",555)
    p.current=label(page,"Current profile",18,-80,"GameFontNormal",520)
    p.selection=button(page,492,30,"Select profile  ▼",18,-110,function()
        if p.menu:IsShown() then p.menu:Hide(); return end
        local names=api.ListProfiles() or {}
        for i,item in ipairs(p.items) do
            item:SetShown(names[i]~=nil)
            if names[i] then item:SetText(names[i]=="MIXOLAS" and "MIXOLAS  [BUILT-IN]" or names[i]) end
        end
        p.menu:Show()
    end)
    helpTip(page,516,-114,"Active Profile","MIXOLAS is the protected default. Editing it creates a new renameable personal profile. Selecting MIXOLAS again creates another personal copy after confirmation.")
    p.menu=CreateFrame("Frame",nil,UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    p.menu:SetFrameStrata("FULLSCREEN_DIALOG")
    p.menu:SetFrameLevel(250)
    p.menu:SetSize(492,386)
    p.menu:SetPoint("TOPLEFT",p.selection,"BOTTOMLEFT",0,-3)
    if p.menu.SetBackdrop then p.menu:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=20,insets={left=5,right=5,top=5,bottom=5}}) end
    p.items={}
    for i=1,17 do
        local idx=i
        p.items[i]=button(p.menu,466,21,"",12,-6-(i-1)*22,function()
            p.menu:Hide()
            local name=(api.ListProfiles() or {})[idx]
            if not name then return end
            if api.IsBuiltInProfile and api.IsBuiltInProfile(name) then
                if not api.ShowConfirm then
                    profileNotice="Confirmation unavailable. Your WoW keybindings were NOT changed."
                    updateControls()
                    return
                end
                local target,isNew=api.GetBuiltInPresetTarget and api.GetBuiltInPresetTarget()
                api.ShowConfirm("Create profile from MIXOLAS?",
                    "Creates a NEW editable profile named '"..tostring(target or "New Profile").."'. No existing profiles are replaced. "..
                    "Includes Mixolas bars, frames and shortcuts. "..
                    "WARNING: REPLACES this character's native WoW keys, including movement and interface shortcuts. "..
                    "A backup is saved first; spells and macros are untouched.",
                    function()
                        local ok,msg=api.ApplyBuiltInPreset()
                        profileNotice=msg or "MIXOLAS setup could not be applied."
                        if api.Say then api.Say(profileNotice) end
                        updateControls()
                    end,"APPLY & REPLACE KEYS",nil,"CANCEL")
                return
            end
            local ok,msg=api.SwitchNamedProfile(name)
            profileNotice=msg or "Cannot switch profile."
            if api.Say then api.Say(profileNotice) end
            updateControls()
        end)
    end
    p.menu:Hide()
    p.selection:SetScript("OnHide",function() p.menu:Hide() end)
    p.name=CreateFrame("EditBox",nil,page,"InputBoxTemplate")
    p.name:SetSize(282,27)
    p.name:SetPoint("TOPLEFT",page,"TOPLEFT",18,-154)
    p.name:SetAutoFocus(false)
    p.name:SetMaxLetters(32)
    p.create=button(page,190,28,"CREATE BLANK PROFILE",320,-154,function()
        if not canEdit() then return end
        local name=p.name:GetText()
        if api.HasNamedProfile(name) then
            profileNotice="That profile already exists. Select it above, or use another name."
        else
            local ok,msg=api.CreateNamedProfile(name)
            profileNotice=msg or "Could not create profile."
            if ok then p.name:SetText("") end
        end
        updateControls()
    end)
    helpTip(page,297,-158,"Profile Name","Enter a unique name here to create a blank profile. Rename has its own window below.")
    helpTip(page,513,-158,"Create Blank Profile","Create and activate a new named profile with independent saved layout, appearance and shortcut data.")
    label(page,"COPY FROM (replaces the selected profile's settings)",18,-193,"GameFontHighlightSmall",548)
    p.copySource=nil
    p.copySelect=button(page,288,28,"Choose source profile  ▼",18,-215,function()
        if p.copyMenu:IsShown() then p.copyMenu:Hide();return end
        local names=api.ListProfiles() or {}
        local current=api.GetActiveProfileName and api.GetActiveProfileName()
        p.availableSources={}
        for _,name in ipairs(names) do
            if name~=current then p.availableSources[#p.availableSources+1]=name end
        end
        if #p.availableSources==0 then
            profileNotice=#names==0 and "Create a profile first, then another to copy from."
                or "Copy From needs a second profile. Create another profile, then choose it here."
            updateControls()
            return
        end
        for i,item in ipairs(p.copyItems) do
            local name=p.availableSources[i]
            item:SetShown(name~=nil)
            if name then item:SetText(name=="MIXOLAS" and "MIXOLAS  [BUILT-IN]" or name) end
        end
        p.copyMenu:Show()
    end)
    helpTip(page,307,-218,"Copy From Profile","Choose an existing profile as the source to copy from. Does not change the active profile until copied.")
    p.copyMenu=CreateFrame("Frame",nil,UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    p.copyMenu:SetFrameStrata("FULLSCREEN_DIALOG")
    p.copyMenu:SetFrameLevel(250)
    p.copyMenu:SetSize(300,386)
    p.copyMenu:SetPoint("TOPLEFT",p.copySelect,"BOTTOMLEFT",0,-3)
    if p.copyMenu.SetBackdrop then p.copyMenu:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=20,insets={left=5,right=5,top=5,bottom=5}}) end
    p.copyItems={}
    for i=1,17 do
        local idx=i
        p.copyItems[i]=button(p.copyMenu,274,21,"",12,-6-(i-1)*22,function()
            p.copySource=p.availableSources and p.availableSources[idx]
            p.copyMenu:Hide()
            profileNotice=p.copySource and ("Ready to copy '"..p.copySource.."' into the active profile. Click COPY INTO CURRENT to review.")
                or "Select a source profile."
            updateControls()
        end)
    end
    p.copyMenu:Hide()
    p.copySelect:SetScript("OnHide",function() p.copyMenu:Hide() end)
    p.copy=button(page,190,28,"COPY INTO CURRENT",320,-215,function()
        if not canEdit() then return end
        local dest=api.GetActiveProfileName()
        if not dest then
            profileNotice="Choose an active profile before copying settings."
            updateControls()
            return
        end
        if not p.copySource or p.copySource==dest or not api.HasNamedProfile(p.copySource) then
            profileNotice="Choose a DIFFERENT source profile on the left before copying."
            updateControls()
            return
        end
        local function go()
            local ok,msg=api.CopyNamedProfile(p.copySource)
            profileNotice=msg or "Copy failed."
            if api.Say then api.Say(profileNotice) end
            updateControls()
        end
        if api.ShowConfirm then api.ShowConfirm("Copy profile settings?","Replace layout, Mixolas keys, and saved WoW native bindings in '"..dest.."' with '"..p.copySource.."'? Spells are not copied.",go,"Copy")
        else go() end
    end)
    helpTip(page,511,-218,"Copy Into Current","Replace the active profile's saved settings with the selected source profile. Confirmation required; spell assignments are not copied.")
    p.rename=button(page,204,28,"RENAME CURRENT PROFILE",18,-266,function()
        if not canEdit() then return end
        local current=api.GetActiveProfileName and api.GetActiveProfileName()
        if not current or not api.HasNamedProfile(current) then
            profileNotice="Select a personal or shared profile before renaming."
        elseif api.IsBuiltInProfile and api.IsBuiltInProfile(current) then
            profileNotice="The built-in MIXOLAS preset cannot be renamed."
        else
            showProfileRenameDialog(current,function(original,newName)
                if not canEdit() then return end
                if api.GetActiveProfileName()~=original then
                    profileNotice="Active profile changed; rename canceled."
                else
                    local ok,msg=api.RenameNamedProfile(original,newName)
                    profileNotice=msg or "Could not rename profile."
                end
                updateControls()
            end)
            return
        end
        updateControls()
    end)
    helpTip(page,226,-270,"Rename Current Profile",
        "Opens a dedicated rename window, prefilled with the current profile name. MIXOLAS cannot be renamed.")
    -- Keep the RC8.58-confirmed Delete button position; confirmation now uses
    -- the existing standalone modal, not an inline re-labeled button.
    p.delete=button(page,204,28,"DELETE CURRENT PROFILE",274,-266,function()
        if not canEdit() then return end
        local name=api.GetActiveProfileName and api.GetActiveProfileName()
        if api.IsBuiltInProfile and api.IsBuiltInProfile(name) then
            profileNotice="The built-in MIXOLAS default cannot be deleted. All personal profiles can be deleted."
            updateControls()
            return
        end
        if not name or not api.HasNamedProfile(name) then
            profileNotice="Choose a saved profile above before deleting it."
            updateControls()
            return
        end
        -- Never delete directly when the modal is unavailable. Snapshot the
        -- requested name so changing page/profile cannot delete a different one.
        if not api.ShowConfirm then
            profileNotice="Delete confirmation is unavailable; nothing was deleted."
            updateControls()
            return
        end
        api.ShowConfirm("Delete profile: "..name.."?",
            "Permanently delete the saved profile '"..name.."'? "..
            "You will return to the protected MIXOLAS default. "..
            "A restore point is saved before deleting the active profile.",
            function()
                -- Confirm ONLY the originally selected named profile, and
                -- recheck that it still exists and is active before deleting.
                local current=api.GetActiveProfileName and api.GetActiveProfileName()
                if current~=name or not api.HasNamedProfile(name) then
                    profileNotice="Active profile changed. Deletion canceled; nothing was deleted."
                    updateControls()
                    return
                end
                if not canEdit() then
                    profileNotice="Cannot delete profiles during combat. Nothing was deleted."
                    updateControls()
                    return
                end
                local ok,msg=api.DeleteNamedProfile(name)
                profileNotice=msg or (ok and "Profile deleted." or "Delete failed.")
                if api.Say then api.Say(profileNotice) end
                if ok and p.copySource==name then p.copySource=nil end
                updateControls()
            end,
            "DELETE PROFILE",
            function()
                profileNotice="Deletion canceled. Your profiles are unchanged."
                updateControls()
            end,
            "CANCEL")
    end)
    helpTip(page,486,-270,"Delete Current Profile",
        "Open a confirmation window before permanently deleting the active saved profile. Cancel safely to keep it.")
    -- Make restore points self-explanatory: 1 Save, 2 Choose, 3 Restore.
    -- The underlying character-owned snapshots and restore mechanics are
    -- unchanged. Never apply a backup merely by selecting it in this menu.
    label(page,"BACKUP & RESTORE",16,-307,"GameFontNormalLarge")
    label(page,"Save a backup before experimenting. Choose an older backup to undo changes.",18,-330,"GameFontHighlightSmall",535)
    p.capture=button(page,151,27,"1. SAVE BACKUP",18,-351,function()
        if not canEdit() then return end
        local ok=api.TakeLayoutSnapshot("Manual restore point")
        profileNotice=ok and "Backup saved. Use Choose Backup to find and restore it later."
            or "Could not create a backup. Try again outside combat."
        if ok then
            chosenSnapshot=1
            chosenSnapshotRef=(api.GetLayoutSnapshots() or {})[1]
        end
        updateControls()
    end)
    p.snapSelect=button(page,229,27,"2. CHOOSE BACKUP  ▼",177,-351,function()
        if p.snapMenu:IsShown() then p.snapMenu:Hide();return end
        local snapshots=api.GetLayoutSnapshots and api.GetLayoutSnapshots() or {}
        if #snapshots==0 then
            profileNotice="No backups yet. Click 1. SAVE BACKUP to create your first one."
            updateControls()
            return
        end
        for i,item in ipairs(p.snapItems) do
            local snap=snapshots[i]
            item:SetShown(snap~=nil)
            if snap then
                local saved=tostring(snap.saved or "Unknown date")
                local reason=tostring(snap.label or "Backup"):gsub("[%c]"," ")
                item:SetText(i.." / "..#snapshots.."   "..saved.."   "..reason:sub(1,32))
            end
        end
        p.snapMenu:Show()
        if p.snapMenu.Raise then p.snapMenu:Raise() end
    end)
    p.snapMenu=CreateFrame("Frame",nil,UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    p.snapMenu:SetFrameStrata("FULLSCREEN_DIALOG")
    p.snapMenu:SetFrameLevel(260)
    p.snapMenu:SetSize(376,192)
    -- Open upwards so the last row of the Profiles page is not obscured.
    p.snapMenu:SetPoint("BOTTOMLEFT",p.snapSelect,"TOPLEFT",0,3)
    if p.snapMenu.SetBackdrop then
        p.snapMenu:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=20,
            insets={left=5,right=5,top=5,bottom=5}})
    end
    p.snapItems={}
    for i=1,8 do
        local idx=i
        p.snapItems[i]=button(p.snapMenu,354,21,"",11,-8-(i-1)*22,function()
            local snaps=api.GetLayoutSnapshots and api.GetLayoutSnapshots() or {}
            p.snapMenu:Hide()
            if not snaps[idx] then
                profileNotice="That backup is no longer available. Choose another one."
                updateControls()
                return
            end
            chosenSnapshot=idx
            chosenSnapshotRef=snaps[idx]
            profileNotice="Backup selected. Click 3. RESTORE BACKUP to review before applying."
            updateControls()
        end)
    end
    p.snapMenu:Hide()
    p.snapSelect:SetScript("OnHide",function() p.snapMenu:Hide() end)
    p.restore=button(page,148,27,"3. RESTORE BACKUP",414,-351,function()
        if not canEdit() then return end
        local snaps=api.GetLayoutSnapshots and api.GetLayoutSnapshots() or {}
        local index=chosenSnapshot
        local selected=snaps[index]
        if not selected then
            profileNotice="First select an available backup from the dropdown."
            updateControls()
            return
        end
        if not api.ShowConfirm then
            profileNotice="Restore confirmation is unavailable. No changes were made."
            updateControls()
            return
        end
        local saved=tostring(selected.saved or "Unknown date")
        local reason=tostring(selected.label or "Backup")
        api.ShowConfirm("Restore backup from "..saved.."?",
            "Backup: "..reason..". This replaces your current Mixolas layout, saved extra actions and shortcuts. "..
            "Blizzard spell-slot placements are not restored. Cancel to keep everything as it is.",
            function()
                -- An automatic snapshot can insert into the list while a
                -- dialog is open. Never apply a different indexed backup.
                local current=api.GetLayoutSnapshots and api.GetLayoutSnapshots() or {}
                if current[index]~=selected then
                    profileNotice="Backup list changed. Choose the backup again before restoring."
                    updateControls()
                    return
                end
                if not canEdit() then return end
                local ok,msg=api.RestoreLayoutSnapshot(index)
                profileNotice=msg or (ok and "Backup restored." or "Restore failed.")
                updateControls()
            end,"RESTORE BACKUP",nil,"CANCEL")
    end)
    helpTip(page,541,-308,"What Are Restore Points?",
        "Restore points are per-character backups (up to eight, newest first). "..
        "They save supported layout settings, extra actions and keybindings, not Blizzard spell-slot placements. "..
        "Save a backup before making changes; choose a dated backup, then confirm Restore Backup.")
    p.snapshot=label(page,"No saved backups yet. Save one to protect your layout.",18,-384,"GameFontHighlightSmall",541)
    p.notice=label(page,"",18,-400,"GameFontHighlightSmall",548)
end

-- Read-only diagnostics help distinguish saved Mixolas shortcuts from actual
-- client bindings and missing secure dispatch buttons. No state is altered.
local function buildDiagnosticReport()
    local db=api.GetDB()
    if not db then return "Settings have not loaded." end
    local keys,duplicates={},{}
    local savedButtonCount=0
    for id,list in pairs(db.bindings or {}) do
        if type(list)=="table" and #list>0 then
            savedButtonCount=savedButtonCount+1
            for _,key in ipairs(list) do
                if keys[key] and keys[key]~=id then duplicates[#duplicates+1]=key end
                keys[key]=id
            end
        end
    end
    local proxies,missing=0,0
    local total=0
    local function auditButton(b)
        total=total+1
        if b.keyProxy and b.keyProxy.GetName and b.keyProxy:GetName() then
            proxies=proxies+1
        else
            missing=missing+1
        end
    end
    for _,cluster in ipairs(api.GetClusters() or {}) do
        for _,b in ipairs(cluster.buttons or {}) do auditButton(b) end
    end
    for _,b in ipairs(api.GetRegularButtons() or {}) do auditButton(b) end
    local _,class=UnitClass and UnitClass("player")
    local lines={
        "CLASS: "..tostring(class or "unknown"),
        "ACTION BUTTONS: "..total.."     SECURE KEY PROXIES: "..proxies,
        "MISSING PROXIES: "..missing,
        "MIXOLAS-ASSIGNED BUTTONS: "..savedButtonCount,
        "DUPLICATE SAVED SHORTCUTS: "..#duplicates,
        "",
        "ACTION OWNERSHIP",
        "Bar 1 = main / stance-paged",
        "Bar 2 = left-stick and Space group",
        "Bar 3 = Diamonds 1-3 (native slots 49-60)",
        "Bar 4 = Diamonds 4-6 (native slots 25-36)",
        "Bar 5 = Diamonds 7-8 (native slots 37-44)",
        "Bars 7-8 = independent addon actions",
        "",
        "Binding mode reveals Mixolas vs. inherited WoW key sources.",
        "Only the WoW client can confirm whether a key casts correctly.",
    }
    if #duplicates>0 then lines[#lines+1]="Warning: duplicate stored keys: "..table.concat(duplicates,", ") end
    if missing>0 then lines[#lines+1]="Warning: shortcut proxy creation is incomplete." end
    if api.ValidateActionOwnership then
        local owned=api.ValidateActionOwnership()
        lines[#lines+1]=""
        lines[#lines+1]=owned
    end
    return table.concat(lines,"\n")
end
local function makeDiagnostics(page)
    label(page,"BINDING & ACTION DIAGNOSTICS",16,-7,"GameFontNormalLarge")
    label(page,"Read-only report. No spells, bindings or bar positions are changed.",16,-39,"GameFontHighlightSmall",535)
    local output=label(page,"",18,-91,"GameFontHighlightSmall",537)
    output:SetJustifyH("LEFT")
    CONTROLS.diagnostics=output
    local testOutput=label(page,"",18,-91,"GameFontHighlightSmall",530)
    testOutput:SetJustifyH("LEFT")
    local keyTester=CreateFrame("Frame",nil,page)
    keyTester:SetAllPoints(UIParent)
    keyTester:EnableMouse(false)
    keyTester:EnableKeyboard(true)
    keyTester:SetScript("OnKeyDown",function(self,raw)
        if self.SetPropagateKeyboardInput then self:SetPropagateKeyboardInput(false) end
        local prefix=""
        if IsAltKeyDown and IsAltKeyDown() then prefix=prefix.."ALT-" end
        if IsControlKeyDown and IsControlKeyDown() then prefix=prefix.."CTRL-" end
        if IsShiftKeyDown and IsShiftKeyDown() then prefix=prefix.."SHIFT-" end
        self:Hide()
        output:Hide()
        testOutput:Show()
        if raw=="ESCAPE" then
            testOutput:SetText("Key routing test canceled. Refresh to view the general diagnostics.")
        else
            local key=prefix..raw
            testOutput:SetText(api.AuditKeyRouting and api.AuditKeyRouting(key) or "Routing diagnostics unavailable.")
        end
    end)
    keyTester:Hide()
    testOutput:Hide()
    button(page,170,29,"CAPTURE TEST KEY",15,-320,function()
        if canEdit() then
            output:Hide()
            testOutput:Show()
            testOutput:SetText("Press a key or key chord. ESC cancels. No binding is changed.")
            keyTester:Show()
        end
    end)
    button(page,196,29,"Refresh diagnostics",196,-354,function()
        testOutput:Hide()
        output:Show()
        output:SetText(buildDiagnosticReport())
    end)
    button(page,170,29,"Binding editor",405,-354,function()
        if not canEdit() then return end
        if window then window:Hide() end
        if not api.StartBindingMode(window) and window then window:Show() end
    end)
    helpTip(page,164,-298,"Capture Test Key","Press a key or modifier combination to audit the active routing. It does not assign or clear any bindings; Escape cancels.")
    helpTip(page,372,-327,"Refresh Diagnostics","Rebuild the read-only action/button/shortcut diagnostic report for your current character.")
    helpTip(page,554,-327,"Open Binding Editor","Open mouseover keybinding mode from Diagnostics. Save & Exit commits changes; Cancel discards them.")
end

local function showTab(which)
    currentTab=which
    if which==8 and api.GetActiveProfileName and api.ListProfiles then
        -- Select this character's active profile when opening Profiles;
        -- alphabetic slot 1 may belong to an entirely different character.
        local active=api.GetActiveProfileName()
        if active then
            for i,name in ipairs(api.ListProfiles()) do
                if name==active then chosenProfile=i;break end
            end
        end
    end
    for i,page in ipairs(tabs) do page:SetShown(i==which) end
    for i,b in ipairs(CONTROLS.tabs) do
        b:Disable() -- disabled highlight is intentional for the selected tab
        if i~=which then b:Enable() end
        selectSubtabMark(b,i==which)
    end
    if updateControls then updateControls() end
end

updateControls=function()
    if not window or not api.IsReady() then return end
    -- api.Change / SetRegularBar / undo observers can invoke this synchronously
    -- from OnValueChanged. Calling SetValue on the actively dragged thumb and
    -- rebuilding tab visibility during that callback interrupts dragging.
    if draggingSlider then return end
    CONTROLS.updating=true
    local db=api.GetDB()
    if db.editorScale and math.abs((window:GetScale() or 1)-db.editorScale)>0.001 then
        window:SetScale(db.editorScale)
    end
    if CONTROLS.macroNames then CONTROLS.macroNames:SetText(db.showMacroNames and "Show macro names: ON" or "Show macro names: OFF") end
    CONTROLS.lock:SetText(db.locked and "Unlock layout" or "Lock layout")
    if CONTROLS.snapCheck then CONTROLS.snapCheck:SetChecked(db.snapEnabled ~= false) end
    CONTROLS.visibility:SetText(db.visible and "Hide all" or "Show all")
    if CONTROLS.blizzard then
        CONTROLS.blizzard:SetText(db.hideBlizzard and "Show Blizzard Buttons" or "Hide Blizzard Buttons")
    end
    if CONTROLS.minimapSize then
        CONTROLS.minimapSize.slider:SetValue(db.minimapSize or 31)
        CONTROLS.minimapSize.value:SetText(tostring(db.minimapSize or 31))
    end
    if CONTROLS.buttonLockCheck then CONTROLS.buttonLockCheck:SetChecked(db.buttonLock) end
    if api.GetUndoRedoStatus then
        local canUndo,canRedo=api.GetUndoRedoStatus()
        if CONTROLS.undo then CONTROLS.undo:SetEnabled(canUndo and not api.IsInCombat()) end
        if CONTROLS.redo then CONTROLS.redo:SetEnabled(canRedo and not api.IsInCombat()) end
    end
    for _,key in ipairs({"buttonSize","glow","borderAlpha","borderWidth"}) do
        local c=CONTROLS[key]
        local v=db[key]*(c.percentage and 100 or 1)
        c.slider:SetValue(v)
        c.value:SetText(string.format(c.fmt,v))
    end
    local editor=CONTROLS.diamondEditor
    if editor then
        local selected=diamondSelected
        local i=selected==0 and 1 or selected
        local bar=i<=3 and 3 or (i<=6 and 4 or 5)
        for n=0,8 do
            local b=editor.nav[n]
            if b then b:SetEnabled(n~=selected) end
        end
        for n,b in ipairs(editor.sectionNav) do
            b:SetEnabled(n~=diamondSection)
            selectSubtabMark(b,n==diamondSection)
            editor.sections[n]:SetShown(n==diamondSection)
        end
        editor.title:SetText(selected==0 and "ALL DIAMONDS  /  EDIT TOGETHER" or ("DIAMOND "..i.."  /  "..NAMES[i]))
        editor.info:SetText(selected==0 and "Settings on this page apply to every diamond (1–8)." or ("Action Bar "..bar.."  |  Independent native spell slots  |  Optional bindings"))
        editor.toggle:SetText(selected==0 and "Show / hide all diamonds" or (db.diamondEnabled[i]~=false and "Hide diamond" or "Show diamond"))
        local empty=db.diamondShowEmpty or {}
        if selected==0 then
            local allOn=true
            for n=1,8 do if empty[n]==false then allOn=false;break end end
            editor.empty:SetText(allOn and "Hide empty slots" or "Show empty slots")
        else
            editor.empty:SetText(empty[i]==false and "Show empty slots" or "Hide empty slots")
        end
        editor.count:SetText(tostring(db.counts[i]))
        -- The historical db.gap remains a compatibility fallback; the live
        -- East/West and North/South keys are never overwritten on load.
        if editor.gapEW then editor.gapEW:SetValue(db.diamondGapEW ~= nil and db.diamondGapEW or (db.gap or 3)) end
        if editor.gapNS then editor.gapNS:SetValue(db.diamondGapNS ~= nil and db.diamondGapNS or (db.gap or 3)) end
        editor.scale:SetValue((db.scales[i] or 1)*100)
        editor.scaleText:SetText(string.format("%d%%",(db.scales[i] or 1)*100))
        editor.alpha:SetValue((db.alphas[i] or 1)*100)
        editor.alphaText:SetText(string.format("%d%%",(db.alphas[i] or 1)*100))
        local ca=(db.combatAlphas and db.combatAlphas[i]) or (db.alphas[i] or 1)
        editor.combatAlpha:SetValue(ca*100)
        editor.combatAlphaText:SetText(string.format("%d%%",ca*100))
        local col=db.colors[i]
        editor.swatch:SetColorTexture(col[1],col[2],col[3],1)
        editor.style:SetText("Border: "..((db.borderStyles[i]=="etched" and "solid") or db.borderStyles[i] or "solid"):upper())
        editor.bright:SetValue((db.brightness[i] or 1)*100)
        editor.brightText:SetText(string.format("%d%%",(db.brightness[i] or 1)*100))
        editor.motion:SetText("Animation: "..((db.glowMotions[i]=="trail" and "static") or db.glowMotions[i] or "static"):upper())
        editor.illumination:SetText("Lighting: "..((db.diamondIlluminationStyles and db.diamondIlluminationStyles[i]) or db.illuminationStyle or "refined"):upper())
    end
    if CONTROLS.flashToggle then
        local flash=_G.MixolasBarsActivationFlash
        local cfg=flash and flash.GetSettings and flash.GetSettings()
        CONTROLS.flashToggle:SetText(cfg and (cfg.enabled and "Colored press flash: ON" or "Colored press flash: OFF")
            or "Colored press flash: unavailable")
    end
    local look=_G.MixolasBarsObsidian
    local lookCfg=look and look.GetSettings and look.GetSettings()
    if lookCfg then
        if CONTROLS.warlordFrame then CONTROLS.warlordFrame:SetValue(math.floor((lookCfg.frameOpacity or 1)*100+0.5)) end
    end
    if CONTROLS.regular.title and db.regularBars then
        local r=CONTROLS.regular
        local c=db.regularBars[regularSelected]
        if c then
            local reserved=api.IsRegularReserved and api.IsRegularReserved(regularSelected)
            for n,b in pairs(r.tabs) do b:SetEnabled(regularPetSelected or n~=regularSelected) end
            if r.petTab then r.petTab:SetEnabled(not regularPetSelected) end
            if r.petPage then r.petPage:SetShown(regularPetSelected) end
            for n,b in ipairs(r.sectionNav) do
                b:SetShown(not regularPetSelected)
                b:SetEnabled(n~=regularSection)
                selectSubtabMark(b,not regularPetSelected and n==regularSection)
                r.sections[n]:SetShown(not regularPetSelected and n==regularSection)
            end
            local title="BAR "..regularSelected..(regularSelected==1 and "  /  MAIN / STANCE" or reserved and "  /  DIAMONDS" or "")
            r.title:SetText(title)
            r.visibleTitle:SetText(title)
            r.enable:SetText(reserved and "Owned by diamonds" or (c.enabled and "Disable bar" or "Enable bar"))
            r.empty:SetText(c.showGrid and "Hide empty slots" or "Show empty slots")
            r.enable:SetEnabled(not reserved)
            r.empty:SetEnabled(not reserved)
            for _,key in ipairs({"count","rows","scale","padding"}) do
                local field=r[key]
                field.slider:SetEnabled(not reserved)
                local v=c[key]*((key=="scale" or key=="alpha") and 100 or 1)
                field.slider:SetValue(v)
                field.text:SetText(string.format(key=="scale" and "%d%%" or "%d",v))
            end
            for _,key in ipairs({"alphaOut","alphaCombat"}) do
                local field=r[key]
                if field then
                    field.slider:SetEnabled(not reserved)
                    local v=math.floor(((c[key] or c.alpha or 1)*100)+0.5)
                    field.slider:SetValue(v)
                    field.text:SetText(string.format("%d%%",v))
                end
            end
        end
    end
    if CONTROLS.utility.title and db.utilityBars then
        local c=db.utilityBars[utilitySelected]
        if c then
            local name=utilitySelected
            for _,info in ipairs(api.UtilityCatalog or {}) do
                if info.id==utilitySelected then name=info.title end
            end
            CONTROLS.utility.title:SetText(name)
            CONTROLS.utility.enable:SetText(c.enabled and "Restore default" or "Manage this group")
            CONTROLS.utility.visible:SetText(c.visible and "Hide group" or "Show group")
            for _,key in ipairs({"scale","alphaOut","alphaCombat","padding","rows"}) do
                local control=CONTROLS.utility[key]
                local v=(c[key] or (key=="alphaOut" or key=="alphaCombat") and c.alpha or 1)
                    *((key=="scale" or key=="alphaOut" or key=="alphaCombat") and 100 or 1)
                control.slider:SetValue(v)
                control.text:SetText(string.format((key=="scale" or key=="alphaOut" or key=="alphaCombat") and "%d%%" or "%d",v))
            end
        end
    end
    if CONTROLS.hotkeyVisibility then
        CONTROLS.hotkeyVisibility:SetText(db.showHotkeys and "Hide hotkey text" or "Show hotkey text")
        if CONTROLS.actionLock then CONTROLS.actionLock:SetText(db.buttonLock and "Unlock button contents" or "Lock button contents") end
        CONTROLS.hotkeySize:SetValue(db.hotkeyFontSize or 8)
        CONTROLS.hotkeySizeLabel:SetText(tostring(db.hotkeyFontSize or 8).." pt")
        if CONTROLS.itemCountSize then CONTROLS.itemCountSize:SetValue(db.itemCountFontSize or 8) end
        if CONTROLS.gcd then CONTROLS.gcd:SetText(db.gcdSweep ~= false and "GCD clockwise sweep: ON" or "GCD clockwise sweep: OFF") end
        if CONTROLS.gcdDarkness then CONTROLS.gcdDarkness:SetValue((db.gcdDarkness or 0.48)*100) end
        CONTROLS.rangeDim:SetValue((db.rangeDim or 0.55)*100)
        CONTROLS.rangeDimLabel:SetText(math.floor((db.rangeDim or 0.55)*100+0.5).."%")
        if CONTROLS.combatDim then CONTROLS.combatDim:SetValue((db.combatDim or 0.39)*100) end
        if CONTROLS.combatDimLabel then CONTROLS.combatDimLabel:SetText(math.floor((db.combatDim or 0.39)*100+0.5).."%") end
    end
    if CONTROLS.decor.attachedRoot then
        local d=CONTROLS.decor
        d.customRoot:SetShown(frameMode=="custom")
        d.attachedRoot:SetShown(frameMode=="attached")
        d.modeAttached:SetEnabled(frameMode~="attached")
        d.modeCustom:SetEnabled(frameMode~="custom")
        selectSubtabMark(d.modeAttached,frameMode=="attached")
        selectSubtabMark(d.modeCustom,frameMode=="custom")
        if frameMode=="attached" and api.GetFrameStudioStyle then
            local target=frameStudioTarget
            local isDiamond=(target=="diamonds" or target:match('^d[1-8]$'))
            local c=api.GetFrameStudioStyle(target)
            if c then
                for i,b in ipairs(d.studioTargets) do
                    local selected=(i==1 and target=="bar1") or (i==2 and target=="bar2")
                        or (i==3 and isDiamond) or (i==4 and target=="pet")
                    b:SetEnabled(not selected)
                end
                for i=0,8 do
                    local b=d.studioNumbers[i]
                    b:SetShown(isDiamond)
                    local selected=(i==0 and target=="diamonds") or target=="d"..i
                    b:SetEnabled(not selected)
                end
                d.studioInfo:SetText(isDiamond and (target=="diamonds"
                    and "All diamonds: compact shell follows modifier colors" or
                    ("Diamond "..target:sub(2)..": independent frame override"))
                    or ((target=="bar1" and "Primary rotation" or target=="bar2" and "Left stick / Space"
                    or "Native Pet Bar (enable Manage this group in Action Bars)")..
                    " | follows bar automatically"))
                for i,page in ipairs(d.studioPages) do page:SetShown(frameStudioPage==i) end
                for i,b in ipairs(d.studioPageNav) do
                    b:SetEnabled(frameStudioPage~=i and (i~=2 or isDiamond))
                    selectSubtabMark(b,frameStudioPage==i)
                end
                if not isDiamond and frameStudioPage==2 then
                    frameStudioPage=1
                    for i,page in ipairs(d.studioPages) do page:SetShown(frameStudioPage==i) end
                    for i,b in ipairs(d.studioPageNav) do
                        b:SetEnabled(frameStudioPage~=i and i~=2)
                        selectSubtabMark(b,frameStudioPage==i)
                    end
                end
                local styles={"off","minimal","forged"}
                for i,b in ipairs(d.studioStyles) do b:SetEnabled(c.style~=styles[i]) end
                if c.style=="shield" then
                    d.studioInfo:SetText("Legacy Shield style preserved in this profile  |  choose a new style above to replace it")
                end
                if d.studioLabel then
                    if not d.studioLabel.HasFocus or not d.studioLabel:HasFocus() then
                        d.studioLabel:SetText(c.label or "")
                    end
                    d.studioLabelToggle:SetText(c.labelEnabled and "Label: ON" or "Label: OFF")
                    d.studioLabelSide:SetText("Position: "..(({TOP="Top",BOTTOM="Bottom",LEFT="Left",RIGHT="Right"})[c.labelSide] or "Top"))
                    d.studioLabelOutline:SetText("Outline: "..(({NONE="None",OUTLINE="Thin",THICKOUTLINE="Thick"})[c.labelOutline] or "Thin"))
                    d.studioLabelColor:SetText("Color: "..(({match="Accent",white="White",gold="Gold"})[c.labelColor] or "Accent"))
                end
                for _,key in ipairs({"opacity","illumination","fieldStrength","fieldSize","padding","scale","x","y","labelSize","labelGap","labelShift"}) do
                    local ctl=d.studio[key]
                    if ctl then
                        local value=c[key] or 0
                        if ctl.format=="percent" then value=value*100 end
                        ctl.slider:SetValue(value)
                        ctl.value:SetText(tostring(math.floor(value+(value>=0 and .5 or -.5)))..
                            (ctl.format=="percent" and "%" or key=="labelSize" and " pt" or " px"))
                    end
                end
            end
        end
    end
    if CONTROLS.decor.title then
        local frames=api.GetDecor and api.GetDecor() or {}
        local ids=liveCustomFrameIds()
        local selectedPosition
        for pos,id in ipairs(ids) do
            if id==frameSelected then selectedPosition=pos;break end
        end
        if not selectedPosition then
            frameSelected=ids[1] or 0
            selectedPosition=#ids>0 and 1 or nil
        end
        local c=frames[frameSelected]
        CONTROLS.decor.title:SetText(c and ("CUSTOM FRAME: "..customFrameName(c,frameSelected)) or "No frame selected — click Create frame")
        local bank=math.floor(((selectedPosition or 1)-1)/6)+1
        CONTROLS.decor.bank=bank
        CONTROLS.decor.visibleIds=ids
        local count=#ids
        for i,b in ipairs(CONTROLS.decor.tabs or {}) do
            local id=ids[(bank-1)*6+i]
            b:SetShown(id~=nil)
            if id then
                b:SetText(customFrameTabName(customFrameName(frames[id],id)))
                b:SetEnabled(id~=frameSelected)
            end
        end
        CONTROLS.decor.bankPrev:SetEnabled(bank>1)
        CONTROLS.decor.bankNext:SetEnabled(bank*6<count)
        for n,b in ipairs(CONTROLS.decor.sectionNav) do
            b:SetEnabled(n~=frameSection)
            selectSubtabMark(b,n==frameSection)
            CONTROLS.decor.sections[n]:SetShown(n==frameSection)
        end
        if CONTROLS.decor.delete then CONTROLS.decor.delete:SetEnabled(c~=nil) end
        if CONTROLS.decor.visible then
            CONTROLS.decor.visible:SetEnabled(c~=nil)
            CONTROLS.decor.visible:SetText(c and (c.visible==false and "Show frame" or "Hide frame") or "Hide frame")
        end
        if c then
            local input=CONTROLS.decor.label
            if input and (not input.HasFocus or not input:HasFocus()) then input:SetText(c.label or "") end
            local side=c.labelSide or "TOP"
            CONTROLS.decor.side:SetText(side=="LEFT" and "LEFT (up)" or side=="RIGHT" and "RIGHT (down)" or side)
            for _,key in ipairs({"width","height","fontSize","thickness","alpha","labelGap","labelOffsetX","labelOffsetY"}) do
                local ctl=CONTROLS.decor[key]
                if ctl then
                    local saved=c[key]
                    if saved==nil then saved=(key=="labelGap") and 3 or 0 end
                    local value=saved*(key=="alpha" and 100 or 1)
                    ctl.slider:SetValue(value)
                    ctl.value:SetText(tostring(math.floor(value+0.5)))
                end
            end
        end
    end
    if CONTROLS.profile and CONTROLS.profile.selection then
        local p=CONTROLS.profile
        local names=api.ListProfiles and api.ListProfiles() or {}
        local activeName=api.GetActiveProfileName and api.GetActiveProfileName()
        p.selection:SetText(activeName and ("Profile: "..activeName.."  ▼") or "Choose profile  ▼")
        local nativeSaved,nativeCountSaved=api.GetNamedProfileNativeStatus and api.GetNamedProfileNativeStatus(activeName)
        if activeName=="MIXOLAS" then
            p.current:SetText("Current: MIXOLAS [READ-ONLY DEFAULT] | Native WoW keys require confirmation")
        else
            p.current:SetText(activeName and ("Current: "..activeName.." | WoW keys: "..
                (nativeSaved and ("AUTO-SAVED ("..nativeCountSaved..")") or "INITIALIZING")) or "No active profile")
        end
        p.selection:SetEnabled(#names>0)
        -- Keep selectors/actions clickable so insufficient profile state can
        -- be EXPLAINED in-page rather than presenting unexplained grey buttons.
        -- An obsolete or now-active copy source is never silently used.
        if p.copySource and (p.copySource==activeName or not api.HasNamedProfile(p.copySource)) then
            p.copySource=nil
        end
        p.copySelect:SetEnabled(true)
        p.copySelect:SetText(p.copySource and ("Source: "..p.copySource.."  ▼")
            or (#names<2 and "Copy From: create a second profile" or "Choose source profile  ▼"))
        p.copy:SetEnabled(true)
        -- Delete stays an ordinary button: the separate confirmation window
        -- owns both destructive confirmation and cancellation.
        p.delete:SetText("DELETE CURRENT PROFILE")
        p.delete:SetEnabled(true)
        if p.rename then p.rename:SetEnabled(true) end
        local snaps=api.GetLayoutSnapshots and api.GetLayoutSnapshots() or {}
        -- Preserve an explicitly chosen backup if automatic snapshots arrive
        -- ahead of it. Never silently switch to another backup by index.
        if chosenSnapshotRef then
            local found=nil
            for i,backup in ipairs(snaps) do
                if backup==chosenSnapshotRef then found=i;break end
            end
            if found then chosenSnapshot=found
            else chosenSnapshot=0;chosenSnapshotRef=nil end
        elseif chosenSnapshot>#snaps then
            chosenSnapshot=0
        end
        local snap=snaps[chosenSnapshot]
        if snap then chosenSnapshotRef=snap end
        if snap then
            local saved=tostring(snap.saved or "Unknown date")
            local reason=tostring(snap.label or "Backup"):gsub("[%c]"," ")
            p.snapSelect:SetText("2. "..chosenSnapshot.."/"..#snaps.." "..saved:sub(6).." ▼")
            p.snapshot:SetText("Selected: "..reason:sub(1,43).."  |  "..#snaps.." of 8 backup slots used")
        else
            p.snapSelect:SetText("2. CHOOSE BACKUP  ▼")
            p.snapshot:SetText(#snaps==0 and "No saved backups yet. Save one to protect your layout."
                or "Previously selected backup is unavailable. Choose another.")
        end
        p.restore:SetEnabled(snap~=nil)
        p.snapSelect:SetEnabled(#snaps>0)
        p.notice:SetText(profileNotice)
    end
    if CONTROLS.diagnostics and CONTROLS.diagnostics:IsShown() then CONTROLS.diagnostics:SetText(buildDiagnosticReport()) end
    if CONTROLS.bindInfo then
        CONTROLS.bindInfo:SetText("Bar / Native / All  •  Restore available after reload")
        if CONTROLS.clearBarBindings then
            CONTROLS.clearBarBindings:SetEnabled(not api.IsInCombat())
        end
    end
    CONTROLS.status:SetText(api.IsInCombat() and "Editing unavailable during combat" or
        (db.locked and "Locked: unlock to drag bars" or "Unlocked: drag the tinted bar or diamond body (Snap optional)"))
    -- A slider might retain the same value on a subsequent refresh, so it may
    -- not fire OnValueChanged. Make every visible numeric value authoritative
    -- from its slider rather than leaving an initial 0/minimum placeholder.
    for _, control in ipairs(sliderValueControls) do
        if control.RefreshValueEntry then control.RefreshValueEntry() end
    end
    CONTROLS.updating=false
end

local function createWindow()
    local template=BackdropTemplateMixin and "BackdropTemplate" or nil
    local f=CreateFrame("Frame","MixolasBarsSettingsWindow",UIParent,template)
    f:SetSize(780,650)
    f:SetPoint("CENTER",UIParent,"CENTER",0,0)
    local settingsDB=api.GetDB()
    local initialScale=settingsDB and tonumber(settingsDB.editorScale) or 1
    f:SetScale(math.max(0.70, math.min(1.30, initialScale or 1)))
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(90)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self) self:StartMoving() end)
    f:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    -- Classic/Blizzard appearance: traditional parchment-dark panel, gold edging,
    -- and native Blizzard fonts/buttons. This is independent artwork, not Bartender4 code.
    if f.SetBackdrop then
        f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
            tile=true,tileSize=32,edgeSize=30,
            insets={left=9,right=9,top=9,bottom=9}})
        f:SetBackdropColor(0.8,0.8,0.8,0.99)
        f:SetBackdropBorderColor(1,1,1,1)
    end
    window=f
    if api.MakeMovableWindow then api.MakeMovableWindow(f,"settings") end
    if UISpecialFrames then table.insert(UISpecialFrames,"MixolasBarsSettingsWindow") end
    label(f,"MIXOLAS BARS",20,-17,"GameFontNormalLarge")
    label(f,"Steam Controller 2  |  Classic Hardcore  |  Default Appearance",21,-44,"GameFontHighlightSmall")
    -- Navigation lives outside the content page and does not overlap controls.
    local rail=f:CreateTexture(nil,"BACKGROUND")
    rail:SetPoint("TOPLEFT",f,"TOPLEFT",621,-116)
    rail:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-17,52)
    rail:SetColorTexture(0.035,0.045,0.068,0.72)
    local heading=label(f,"PAGES",645,-129,"GameFontNormal",110)
    heading:SetJustifyH("CENTER")
    -- Resize grip changes the entire panel uniformly; all controls remain
    -- aligned. No slider inside the panel that moves under the mouse.
    editorScaleValue=label(f,"",534,-18,"GameFontHighlightSmall",62)
    local grip=CreateFrame("Button",nil,f)
    grip:SetSize(28,28)
    grip:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-7,7)
    grip:SetFrameLevel(f:GetFrameLevel()+12)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    local gripMark=grip:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    gripMark:SetAllPoints(grip)
    gripMark:SetJustifyH("CENTER")
    gripMark:SetText("◢")
    grip:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:AddLine("Resize Mixolas menu")
        GameTooltip:AddLine("Drag this corner to scale the menu",0.8,0.8,0.8)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave",function() GameTooltip:Hide() end)
    local resizeStartX,resizeStartY,resizeScale,resizeWidth,resizeHeight
    grip:SetScript("OnDragStart",function(self)
        resizeStartX,resizeStartY=GetCursorPosition()
        resizeScale=f:GetScale() or 1
        local effective=f:GetEffectiveScale() or 1
        resizeWidth=math.max(1,f:GetWidth()*effective)
        resizeHeight=math.max(1,f:GetHeight()*effective)
        self:SetScript("OnUpdate",function()
            local x,y=GetCursorPosition()
            local xRatio=1+(x-resizeStartX)/resizeWidth
            local yRatio=1+(resizeStartY-y)/resizeHeight
            local ratio=(xRatio+yRatio)/2
            local value=math.max(0.70,math.min(1.50,resizeScale*ratio))
            f:SetScale(value)
            editorScaleValue:SetText(math.floor(value*100+0.5).."%")
        end)
    end)
    grip:SetScript("OnDragStop",function(self)
        self:SetScript("OnUpdate",nil)
        local d=api.GetDB()
        if d then d.editorScale=f:GetScale() end
    end)
    editorScaleValue:SetText(math.floor((f:GetScale() or 1)*100+0.5).."%")
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",f,"TOPRIGHT",-4,-5)
    CONTROLS.lock=button(f,160,26,"Unlock layout",20,-72,function()
        if canEdit() and api.Change("locked",not api.GetDB().locked) then updateControls() end
    end)
    CONTROLS.visibility=button(f,148,26,"Hide all",191,-72,function()
        if canEdit() and api.Change("visible",not api.GetDB().visible) then updateControls() end
    end)
    CONTROLS.buttonLockCheck=CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    CONTROLS.buttonLockCheck:SetSize(26,26)
    CONTROLS.buttonLockCheck:SetPoint("TOPLEFT",f,"TOPLEFT",355,-72)
    local lockLabel=label(f,"Button lock",384,-78,"GameFontHighlightSmall",100)
    CONTROLS.buttonLockCheck:SetScript("OnClick",function(self)
        if canEdit() and api.Change("buttonLock",self:GetChecked()) then updateControls()
        else updateControls() end
    end)
    -- Layout-wide snap belongs in the permanent toolbar next to Button Lock,
    -- not on General: it must be accessible while positioning any bar.
    CONTROLS.snapCheck=CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    CONTROLS.snapCheck:SetSize(26,26)
    CONTROLS.snapCheck:SetPoint("TOPLEFT",f,"TOPLEFT",355,-102)
    label(f,"Snap to Grid",384,-108,"GameFontHighlightSmall",111)
    CONTROLS.snapCheck:SetScript("OnClick",function(self)
        if canEdit() and api.Change("snapEnabled",self:GetChecked()) then updateControls()
        else updateControls() end
    end)
    -- Simple U-turn arrows beside the existing button/spell lock checkbox.
    helpTip(f,164,-103,"Layout Lock","Lock or unlock repositioning and resizing Mixolas bars and diamonds. Unlock before dragging the layout; spells remain usable.")
    helpTip(f,318,-103,"Show / Hide All","Show or hide all Mixolas action bars and diamonds without deleting actions or changing their bindings.")
    helpTip(f,481,-76,"Button Lock","Prevent accidental changes to spell placements while using the bars. Independent of whether the bar layout is unlocked.")
    helpTip(f,504,-107,"Snap to Grid","Align bars, diamonds and frames to the layout grid when positioning them. Disable for free placement.")
    -- These operate on the complete *Mixolas-owned* edit history, not merely
    -- the current settings tab; they do NOT rewrite native Blizzard spells.
    local function historyArrow(x,kind,texture,labelText,tooltip)
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate")
        b:SetSize(27,27)
        b:SetPoint("TOPLEFT",f,"TOPLEFT",x,-72)
        b:SetText("")
        local icon=b:CreateTexture(nil,"ARTWORK")
        icon:SetPoint("CENTER",b,"CENTER",0,0)
        icon:SetSize(20,20)
        icon:SetTexture("Interface\\AddOns\\MixolasBars\\Media\\"..texture)
        b:SetScript("OnEnter",function(self)
            GameTooltip:SetOwner(self,"ANCHOR_TOP")
            GameTooltip:AddLine(labelText,1,0.82,0.35)
            GameTooltip:AddLine(tooltip,0.82,0.82,0.82,true)
            GameTooltip:AddLine("Only addon-owned changes; native WoW spell placements are not in this history.",0.65,0.75,0.85,true)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave",function() GameTooltip:Hide() end)
        b:SetScript("OnClick",function()
            if not api.IsInCombat() and api[kind] then
                local ok,reason=api[kind]()
                if not ok and api.Say then api.Say(reason) end
                updateControls()
            end
        end)
        return b
    end
    CONTROLS.undo=historyArrow(503,"UndoMixolasEdit","WarlordUndoArrow.tga","Undo","Undo the last Mixolas change (this session).")
    CONTROLS.redo=historyArrow(533,"RedoMixolasEdit","WarlordRedoArrow.tga","Redo","Redo the most recently undone Mixolas change.")
    if api.SetUndoRedoChanged then
        api.SetUndoRedoChanged(function() if window and window:IsShown() then updateControls() end end)
    end
    CONTROLS.tabs={}
    for i,text in ipairs({"General","Diamonds","Action Bars","Keybindings","Buttons","Frames","Diagnostics","Profiles"}) do
        -- Diagnostics is a developer-only page, accessible via /mxbdiagui.
        -- Keep page id 7 so all existing page references and behavior remain
        -- unchanged; move Profiles up to the vacated seventh visible tab slot.
        local visiblePosition=(i==8) and 7 or i
        local b=subtabMark(button(f,129,36,text,636,-162-(visiblePosition-1)*44,function() showTab(i) end))
        if i==7 then b:Hide() end
        CONTROLS.tabs[i]=b
        tabs[i]=makePage(f)
    end
    makeGeneral(tabs[1])
    makeDiamonds(tabs[2])
    makeRegular(tabs[3])
    makeUtility(CONTROLS.regular.petPage)
    makeBindings(tabs[4])
    makeButtons(tabs[5])
    makeFrames(tabs[6])
    makeDiagnostics(tabs[7])
    makeProfiles(tabs[8])
    button(f,146,27,"Reset Positions",308,-596,function()
        if not canEdit() or not api.ShowConfirm then return end
        api.ShowConfirm("Reset ALL Mixolas positions?",
            "Restore default positions for all diamonds, bars, the Pet Bar, custom frames, attached-frame offsets and Mixolas windows. Spells, sizes, padding, frames and shortcuts stay unchanged. Continue?",
            function()
                if api.ResetPositions() then updateControls()
                else api.Say("Could not reset positions; make sure you are out of combat.") end
            end,"Yes, Reset")
    end)
    button(f,133,27,"Reset All",467,-596,function()
        if not canEdit() or not api.ShowConfirm then return end
        api.ShowConfirm("Restore Mixolas factory defaults?",
            "Reset ALL Mixolas layout, bars, positions, Frames, illumination, animations and appearance to factory settings. Saved profiles, spell assignments and keybindings are preserved. Continue?",
            function()
                if api.Reset() then updateControls()
                else api.Say("Reset rejected; make sure you are out of combat.") end
            end,"Yes, Reset")
    end)
    helpTip(f,432,-600,"Reset Positions","Return Mixolas bars, diamonds, frames and editor windows to default positions. Does not clear spells, bindings or appearance settings.")
    helpTip(f,578,-600,"Reset All","Reset Mixolas layout and visual options to factory defaults while preserving named profiles, spell assignments and bindings. Confirmation required.")
    CONTROLS.status=label(f,"",21,-602,"GameFontHighlightSmall",274)
    showTab(currentTab)
    f:Hide()
    f:SetScript("OnShow",updateControls)
end


local function togglePanel()
    if not window then createWindow() end
    if window:IsShown() then window:Hide() else window:Show() end
end

local launch=CreateFrame("Button","MixolasBarsMinimapButton",Minimap)
launch:SetSize(31,31)
launch:RegisterForClicks("LeftButtonUp", "RightButtonUp")
launch:RegisterForDrag("LeftButton")
launch:SetFrameStrata("MEDIUM")
launch:SetFrameLevel((Minimap:GetFrameLevel() or 1)+8)
-- Brand minimap launcher: transparent, authored MH compass artwork.
-- Keep the full image: cropped texcoords and a portrait mask cut off compass points.
local emblem=launch:CreateTexture(nil,"ARTWORK")
emblem:SetTexture("Interface\\AddOns\\MixolasBars\\Media\\MHMinimapIcon.tga")
emblem:SetPoint("CENTER",launch,"CENTER",0,0)
emblem:SetTexCoord(0,1,0,1)
local lastMinimapWidth,lastMinimapHeight,lastMinimapSize
local function positionIcon()
    local db=api.GetDB()
    local size=math.max(20,math.min(56,(db and tonumber(db.minimapSize)) or 31))
    local width=math.max(1,Minimap:GetWidth() or 140)
    local height=math.max(1,Minimap:GetHeight() or 140)
    -- An elliptical minimap boundary is the natural generalization of the
    -- original hardcoded circular radius, preserving its contour under resized
    -- and non-square minimaps. A half-icon offset keeps the clickable circle
    -- immediately outside the map instead of partly covering the map texture.
    local a=math.rad((db and db.minimapAngle) or 220)
    local ca,sa=math.cos(a),math.sin(a)
    local halfW,halfH=width/2,height/2
    local shape=(type(GetMinimapShape)=="function" and GetMinimapShape()) or "ROUND"
    -- Use a radial boundary calculation. This keeps the *whole* icon outside
    -- the minimap instead of assuming its center may sit on the 81px ring.
    -- Respect square minimap skins that expose the conventional shape API.
    local boundary
    if shape=="SQUARE" then
        boundary=math.min(halfW/math.max(0.0001,math.abs(ca)),
            halfH/math.max(0.0001,math.abs(sa)))
    else
        boundary=1/math.sqrt((ca/halfW)^2+(sa/halfH)^2)
    end
    local radius=boundary+size/2+2
    launch:ClearAllPoints()
    launch:SetPoint("CENTER",Minimap,"CENTER",ca*radius,sa*radius)
    if lastMinimapSize~=size then
        launch:SetSize(size,size)
        emblem:SetSize(size,size)
        lastMinimapSize=size
    end
    lastMinimapWidth,lastMinimapHeight=width,height
end
api.UpdateMinimapIcon=positionIcon
local dragging=false
launch:SetScript("OnDragStart",function(self)
    dragging=true
    self:SetScript("OnUpdate",function()
        local x,y=GetCursorPosition()
        local scale=Minimap:GetEffectiveScale()
        local cx,cy=Minimap:GetCenter()
        if cx and scale then
            local angle=math.deg(math.atan2(y/scale-cy,x/scale-cx))
            local db=api.GetDB()
            if db then db.minimapAngle=angle end
            positionIcon()
        end
    end)
end)
launch:SetScript("OnDragStop",function(self)
    dragging=false
    self:SetScript("OnUpdate",nil)
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
end)
launch:SetScript("OnClick",function(_,mouseButton)
    if dragging then return end
    if mouseButton=="RightButton" then
        if api.IsBindingMode and api.IsBindingMode() then return end
        if not api.IsReady() or api.IsInCombat() then
            api.Say("Keybinding mode is unavailable during combat or before the addon loads.")
            return
        end
        if window then window:Hide() end
        if api.StartBindingMode then
            local result=api.StartBindingMode(nil)
            if not result and window then window:Show() end
        end
    else
        togglePanel()
    end
end)
launch:SetScript("OnEnter",function(self)
    GameTooltip:SetOwner(self,"ANCHOR_LEFT")
    GameTooltip:AddLine("Mixolas Bars",1,0.82,0.25)
    GameTooltip:AddLine("Left-click: settings  |  Right-click: keybind mode",1,1,1)
    GameTooltip:AddLine("Left-drag: position around minimap | Size: General settings",0.7,0.7,0.7)
    GameTooltip:Show()
end)
launch:SetScript("OnLeave",function() GameTooltip:Hide() end)
local minimapInit=CreateFrame("Frame")
minimapInit:RegisterEvent("PLAYER_LOGIN")
minimapInit:SetScript("OnEvent",positionIcon)
-- Follow minimap resizes and scale/layout changes, even when performed by
-- another addon after PLAYER_LOGIN. The attachment is calculated in its own
-- frame units, so the minimap's effective scale is inherited automatically.
local sizeWatch=CreateFrame("Frame",nil,Minimap)
local elapsedSinceSizeCheck=0
sizeWatch:SetScript("OnUpdate",function(_,elapsed)
    elapsedSinceSizeCheck=elapsedSinceSizeCheck+(elapsed or 0)
    if elapsedSinceSizeCheck<0.35 then return end
    elapsedSinceSizeCheck=0
    local w,h=Minimap:GetWidth(),Minimap:GetHeight()
    if w~=lastMinimapWidth or h~=lastMinimapHeight then positionIcon() end
end)

api.UpdateSettingsUI=updateControls

local category=CreateFrame("Frame","MixolasBarsOptionsCategory",UIParent)
category:SetSize(550,350)
label(category,"Mixolas Bars",20,-20,"GameFontNormalLarge")
label(category,"Fragmented controller-inspired action bars.",20,-55,"GameFontHighlight")
button(category,180,28,"Open Editor",20,-113,togglePanel)
local registered=false
if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
    registered=pcall(function()
        local item=Settings.RegisterCanvasLayoutCategory(category,"Mixolas Bars")
        Settings.RegisterAddOnCategory(item)
    end)
end
if not registered and InterfaceOptions_AddCategory then
    category.name="Mixolas Bars"
    InterfaceOptions_AddCategory(category)
end
-- Legacy slash command retained for troubleshooting only; normal use is 100% graphical.
SLASH_MIXOLASBARSGUI1="/mixolas"
SlashCmdList["MIXOLASBARSGUI"]=togglePanel

-- Preserve the original read-only Diagnostics report, key-capture test and
-- Binding Editor entry point without exposing Diagnostics as a public tab.
-- /mxbdiag and /mxbadvanced continue to open the separate advanced utility.
SLASH_MXBDIAGUI1="/mxbdiagui"
SlashCmdList["MXBDIAGUI"]=function()
    if not window then createWindow() end
    showTab(7)
    window:Show()
end
