-- Mixolas Bars RC8.16: read-only, category-scoped keybinding exports.
-- Step 1 of the import/export overhaul. Import behavior remains MXB1-only.
-- Never updates SavedVariables, profile state, or WoW native bindings.
local api = _G.MixolasBarsAPI
if not api then return end

local MAX_EXPORT = 60000 -- keep below the transfer EditBox 65535-character limit
local function encode(text)
    return (text:gsub('([^A-Za-z0-9_%-])', function(char)
        return string.format('%%%02X', string.byte(char))
    end))
end

local function exportNative()
    if type(api.CaptureNativeBindings) ~= 'function' then
        return nil, 'Native WoW binding capture is unavailable.'
    end
    local snapshot,err=api.CaptureNativeBindings()
    if not snapshot then return nil,err or 'Could not capture native WoW bindings.' end
    if snapshot.version ~= 1 or type(snapshot.keys) ~= 'table' then
        return nil,'Native binding data has an unsupported format.'
    end
    local ordered={}
    for key,command in pairs(snapshot.keys) do
        if type(key) ~= 'string' or #key==0 or #key>64 or key:find('%c')
          or type(command) ~= 'string' or #command==0 or #command>256 or command:find('%c') then
            return nil,'Native WoW returned an invalid key or command.'
        end
        ordered[#ordered+1]=key
        if #ordered>4096 then return nil,'Too many native WoW bindings.' end
    end
    table.sort(ordered)
    local parts={'MXBN1'}
    for _,key in ipairs(ordered) do
        parts[#parts+1]=encode(key)..'='..encode(snapshot.keys[key])
    end
    return table.concat(parts,';'),#ordered
end

local function generate(mode)
    if mode~='bar' and mode~='native' and mode~='all' then
        return nil,'Choose Bar, Native WoW, or All Keybinds.'
    end
    if not api.IsReady or not api.IsReady() then
        return nil,'Wait for Mixolas Bars to finish loading.'
    end
    if api.IsInCombat and api.IsInCombat() then
        return nil,'Export keybindings after leaving combat.'
    end
    local bar,native,count
    if mode=='bar' or mode=='all' then
        if type(api.GetBindingExport)~='function' then
            return nil,'Bar binding export is unavailable.'
        end
        bar=api.GetBindingExport() -- original MXB1 format, byte-for-byte compatible
    end
    if mode=='native' or mode=='all' then
        native,count=exportNative()
        if not native then return nil,count end
    end
    local output
    if mode=='bar' then output=bar
    elseif mode=='native' then output=native
    else
        -- Length-prefixed segments make the combined format unambiguous even
        -- when its MXB1 and MXBN1 payloads contain '=' and ';' characters.
        output='MXBA1;B='..#bar..':'..bar..';N='..#native..':'..native
    end
    if #output>MAX_EXPORT then
        return nil,'Export exceeds '..MAX_EXPORT..' characters; no data was changed.'
    end
    local label=mode=='bar' and 'Bar Keybinds (MXB1)'
       or (mode=='native' and 'Native WoW Keybinds (MXBN1)'
                         or 'All Keybinds (MXBA1)')
    local explanation=label..' exported ('..#output..' characters).'
    if count then explanation=explanation..' '..count..' native WoW shortcuts included.' end
    return output,explanation
end
api.GenerateKeybindingExport=generate
