-- Mixolas Bars 0.21.3: modifier-only diamond energy field, independent size/strength.
-- Cosmetic only. Secure actions, spell slots, key routing and action paging are
-- deliberately not accessed or changed. Build/anchor textures outside combat.
local api = _G.MixolasBarsAPI
if not api then return end
local ROOT = 'Interface\\AddOns\\MixolasBars\\Media\\'
local specs = {
    minimal   = {'StudioMinimal.tga',  'StudioGlow.tga', 'StudioDiamondMinimal.tga', 'StudioDiamondGlow.tga'},
    forged    = {'StudioForged.tga',   'StudioGlow.tga', 'StudioDiamondForged.tga', 'StudioDiamondGlow.tga'},
    shield    = {'StudioWarriorShield.tga','StudioShieldGlow.tga'},
}
local colors = {
    [1]={.27,1,.49}, [2]={1,.86,.24}, [3]={1,.55,.17}, [4]={.26,.62,1},
    [5]={.94,.95,1}, [6]={1,.26,.32}, [7]={.72,.39,1}, [8]={1,1,1},
}
local phases = {'shiftalt','alt','ctrlalt','shift','idle','ctrl','shiftctrl','triple'}
local defaults = {style='off', padding=2, opacity=.88, illumination=.55,
    fieldStrength=.78, fieldSize=14,
    scale=1, x=0, y=0, label='', labelEnabled=true, labelSide='TOP',
    labelSize=12, labelGap=3, labelShift=0, labelOutline='OUTLINE', labelColor='match'}
local attached = {}
local dirty=true
local tick=0
local stopped=false
local function legal()
    return api.IsReady and api.IsReady() and not (api.IsInCombat and api.IsInCombat())
        and not (InCombatLockdown and InCombatLockdown())
end
local function getDB()
    local db=api.GetDB and api.GetDB()
    if not db then return nil end
    if type(db.frameStudio)~='table' then db.frameStudio={} end
    return db.frameStudio
end
local function getRaw(target)
    local all=getDB()
    if not all then return nil end
    if target=='bar1' or target=='bar2' or target=='pet' or target=='diamonds' then return all[target] end
    if type(target)=='string' and target:match('^d[1-8]$') then return all[target] end
    return nil
end
local function get(target)
    if target~='bar1' and target~='bar2' and target~='pet' and target~='diamonds'
        and not (type(target)=='string' and target:match('^d[1-8]$')) then return nil end
    local out={}
    for k,v in pairs(defaults) do out[k]=v end
    -- Individual diamond overrides layer ON TOP of all-diamond defaults.
    -- A global style change must not be blocked by a per-diamond padding edit.
    if target:match('^d[1-8]$') then
        local common=getRaw('diamonds')
        if type(common)=='table' then
            for k,v in pairs(common) do if defaults[k]~=nil then out[k]=v end end
        end
    end
    local item=getRaw(target)
    if type(item)=='table' then
        for k,v in pairs(item) do if defaults[k]~=nil then out[k]=v end end
    end
    -- Legacy 'Existing' is no longer a selectable style. Older saved profiles
    -- resolve to None without rewriting or deleting any saved configuration.
    if out.style=='inherit' then out.style='off' end
    -- Retired RC1 Glow/RGB frame styles fall back to their nearest static
    -- housing, without rewriting a stored profile or losing label/fit options.
    if out.style=='luminous' then out.style='minimal' end
    if out.style=='prismatic' then out.style='forged' end
    return out
end
local function safeNum(n,lo,hi)
    if type(n)~='number' or n~=n then return nil end
    return math.max(lo,math.min(hi,n))
end
local function getHost(target)
    if target=='pet' then
        return api.GetManagedPetBarHost and api.GetManagedPetBarHost()
    elseif target=='bar1' or target=='bar2' then
        local list=api.GetRegularButtons and api.GetRegularButtons() or {}
        for _,b in ipairs(list) do
            if b and b.barNumber==(target=='bar1' and 1 or 2) and b.GetParent then
                return b:GetParent()
            end
        end
    elseif type(target)=='string' and target:match('^d[1-8]$') then
        local index=tonumber(target:sub(2))
        local clusters=api.GetClusters and api.GetClusters() or {}
        return clusters[index]
    end
end
local function ensure(target)
    if attached[target] then return attached[target] end
    local host=getHost(target)
    if not host or not host.CreateTexture then return nil end
    local a={host=host}
    -- These are decorative textures on an EXISTING frame, never new buttons.
    a.base=host:CreateTexture(nil,'BACKGROUND',nil,-6)
    -- Sharp light sits above the frame metal; the independent soft pass stays
    -- behind it. Both have transparent centers and cannot cover spell icons.
    a.light=host:CreateTexture(nil,'BORDER',nil,-1)
    a.light:SetBlendMode('ADD')
    a.bloom=host:CreateTexture(nil,'BACKGROUND',nil,-5)
    a.bloom:SetBlendMode('ADD')
    if type(target)=='string' and target:match('^d[1-8]$') then
        -- The field is behind the existing armor and buttons, but its graphic
        -- extends past the diamond silhouette; it does not enlarge the host.
        a.field=host:CreateTexture(nil,'BACKGROUND',nil,-7)
        a.field:SetBlendMode('ADD')
        a.field:SetTexture(ROOT..'StudioDiamondModifierField.tga')
        a.field:Hide()
        a.fieldEnergy=0
    end
    a.base:Hide();a.light:Hide();a.bloom:Hide()
    a.title=host:CreateFontString(nil,'OVERLAY','GameFontNormal')
    a.title:Hide()
    attached[target]=a
    return a
end
local function held()
    local s=IsShiftKeyDown and IsShiftKeyDown()
    local c=IsControlKeyDown and IsControlKeyDown()
    local a=IsAltKeyDown and IsAltKeyDown()
    if s and c and a then return 'triple' end
    if s and c then return 'shiftctrl' end
    if s and a then return 'shiftalt' end
    if c and a then return 'ctrlalt' end
    if s then return 'shift' end
    if c then return 'ctrl' end
    if a then return 'alt' end
    return 'idle'
end
local function activeTint(target,phase)
    if target=='pet' then return .58,.78,1,1 end
    if target=='bar1' then return 1,.39,.19,1 end
    if target=='bar2' then return 1,.69,.30,1 end
    local i=tonumber(target:sub(2))
    local tint=colors[i] or colors[5]
    return tint[1],tint[2],tint[3], (phases[i]==phase and 1 or .34)
end
-- The diamond buttons fade individually, but Frame Studio housings and labels
-- are owned by the *cluster*, not by a button.  Multiply their existing visual
-- opacity by the matching diamond's current combat/out-of-combat alpha without
-- changing the protected buttons, the cluster alpha, or saved visual settings.
-- Never fade custom standalone decor frames or regular action-bar housings here.
local function diamondVisualAlpha(target)
    if type(target)~='string' then return 1 end
    local index=tonumber(target:match('^d([1-8])$'))
    if not index then return 1 end
    local db=api.GetDB and api.GetDB()
    if type(db)~='table' then return 1 end
    local value=tonumber(db.alphas and db.alphas[index]) or 1
    if api.IsInCombat and api.IsInCombat() then
        value=tonumber(db.combatAlphas and db.combatAlphas[index]) or value
    end
    return math.max(0.1,math.min(1,value))
end
-- Labels are optional annotations owned by the attached frame host. They never
-- alter the size, scale, padding, visibility or secure attributes of spell slots.
-- An attached label can be used with the None frame style.
local function paintLabel(a,c)
    local title=a.title
    if not title then return end
    local text=type(c.label)=='string' and c.label:sub(1,48) or ''
    if c.labelEnabled==false or text=='' then title:Hide();return end
    local side=({TOP=true,BOTTOM=true,LEFT=true,RIGHT=true})[c.labelSide] and c.labelSide or 'TOP'
    local size=safeNum(c.labelSize,8,26) or 12
    local gap=safeNum(c.labelGap,0,30) or 3
    local shift=safeNum(c.labelShift,-90,90) or 0
    local outline=({NONE=true,OUTLINE=true,THICKOUTLINE=true})[c.labelOutline] and c.labelOutline or 'OUTLINE'
    local opts=outline=='NONE' and '' or outline
    local font=STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF'
    title:SetFont(font,size,opts)
    title:SetText(text)
    title:SetWidth(0);title:SetHeight(0)
    title:ClearAllPoints()
    -- LEFT: read from bottom to top. RIGHT: read from top to bottom.
    -- Keep the label anchored by its center so the same gap and vertical
    -- position settings work after rotating a horizontal FontString.
    local vertical=(side=='LEFT' or side=='RIGHT')
    local rotated=false
    if title.SetRotation then
        rotated=pcall(title.SetRotation,title,
            side=='LEFT' and math.pi/2 or side=='RIGHT' and -math.pi/2 or 0)
    end
    if vertical and not rotated then
        -- Older Classic clients may lack FontString rotation entirely.
        -- Preserve reading direction with a vertical-letter fallback.
        local letters={}
        local i=1
        while i<=#text do
            local byte=text:byte(i)
            local bytes=byte>=240 and 4 or byte>=224 and 3 or byte>=192 and 2 or 1
            letters[#letters+1]=text:sub(i,i+bytes-1)
            i=i+bytes
        end
        if side=='LEFT' then
            local reversed={}
            for j=#letters,1,-1 do reversed[#reversed+1]=letters[j] end
            letters=reversed
        end
        title:SetText(table.concat(letters,'\n'))
    end
    -- No fixed overlay panels. Labels follow the host without touching any
    -- spell-button anchors or protected bar layouts.
    if side=='BOTTOM' then
        title:SetPoint('TOP',a.host,'BOTTOM',shift,-(gap+2))
    elseif side=='LEFT' then
        title:SetPoint('CENTER',a.host,'LEFT',-(gap+2+size/2),shift)
    elseif side=='RIGHT' then
        title:SetPoint('CENTER',a.host,'RIGHT',gap+2+size/2,shift)
    else
        title:SetPoint('BOTTOM',a.host,'TOP',shift,gap+2)
    end
    title:SetShown(true)
end
local function paint(target)
    local a=attached[target]
    if not a then return end
    local c=get(target)
    if not c then return end
    paintLabel(a,c)
    local style=c.style
    if style=='off' or (style=='shield' and target:match('^d')) then
        a.base:Hide();a.light:Hide();a.bloom:Hide();if a.field then a.field:Hide();a.fieldEnergy=0 end;return
    end
    local files=specs[style]
    if not files then a.base:Hide();a.light:Hide();a.bloom:Hide();if a.field then a.field:Hide();a.fieldEnergy=0 end;return end
    if a.style~=style then
        local diamond=(target:match('^d[1-8]$')~=nil)
        a.base:SetTexture(ROOT..(diamond and files[3] or files[1]))
        if diamond then
            a.light:SetTexture(ROOT..'StudioDiamondGlowVivid.tga')
            a.bloom:SetTexture(ROOT..'StudioDiamondBloom.tga')
            if a.field then
                local isTriple=target=='d8'
                a.field:SetTexture(ROOT..(isTriple
                    and 'StudioDiamondModifierFieldPrismatic.tga' or 'StudioDiamondModifierField.tga'))
            end
        else
            a.light:SetTexture(ROOT..files[2])
            a.bloom:SetTexture(ROOT..files[2])
        end
        a.style=style
    end
    local w=a.host:GetWidth() or 0
    local h=a.host:GetHeight() or 0
    if w<8 or h<8 then a.base:Hide();a.light:Hide();a.bloom:Hide();if a.field then a.field:Hide();a.fieldEnergy=0 end;return end
    local padding=safeNum(c.padding,0,16) or 2
    local scale=safeNum(c.scale,.70,1.5) or 1
    local x=safeNum(c.x,-48,48) or 0
    local y=safeNum(c.y,-48,48) or 0
    local width=(w+padding*2)*scale
    local height=(h+padding*2)*scale
    -- Forged is an intentionally heavier housing, not a barely brighter
    -- Minimal.  This cosmetic 5% outer rim does not alter any saved scale,
    -- button geometry, modifier field reach, protected frame or position.
    if style=='forged' then width=width*1.05;height=height*1.05 end
    if style=='shield' then
        -- Heraldic shield remains aspect-correct when a bar is reoriented.
        -- It sits behind the icons and never adjusts action-button spacing.
        local crest=math.min(width,height*0.88)
        width=crest;height=crest*1.20
    end
    for _,tex in ipairs({a.base,a.light,a.bloom}) do
        tex:ClearAllPoints()
        tex:SetPoint('CENTER',a.host,'CENTER',x,y)
        tex:SetSize(width,height)
    end
    a.base:Show();a.light:Show();a.bloom:Show()
    if a.field then
        local reach=safeNum(c.fieldSize,0,28) or 14
        a.field:ClearAllPoints()
        a.field:SetPoint('CENTER',a.host,'CENTER',x,y)
        a.field:SetSize(width+2*reach,height+2*reach)
        -- Do not show at rest: light() manages smooth activation and release.
    end
end
local function light(dt)
    local phase=held()
    for target,a in pairs(attached) do
        local c=get(target)
        if c then
            local fade=diamondVisualAlpha(target)
            local title=a.title
            if title and title:IsShown() then
                local mode=c.labelColor or 'match'
                local r,g,b=1,1,1
                if mode=='gold' then r,g,b=1,.82,.44
                elseif mode=='match' then r,g,b=activeTint(target,phase) end
                title:SetTextColor(r,g,b,fade)
            end
            local style=c.style
            if style~='off' and a.base:IsShown() then
                local opacity=safeNum(c.opacity,0,1) or .88
                local glow=safeNum(c.illumination,0,1) or .55
                local r,g,b,power=activeTint(target,phase)
                local diamond=target:match('^d[1-8]$')~=nil
                -- Keep Minimal neutral/quiet. Forged has a warmer metal
                -- face and noticeably stronger lit edge; independent saved
                -- opacity and illumination still control both styles.
                if style=='forged' then
                    a.base:SetVertexColor(1,.89,.73,opacity*fade)
                else
                    a.base:SetVertexColor(1,1,1,opacity*fade)
                end
                if diamond then
                    -- 0% is fully off; 100% actually makes the outline vivid.
                    -- Inactive diamonds retain their hue but remain dimmer than
                    -- the exact active modifier. Minimal is restrained, not 16%
                    -- of the requested slider value as in 0.21.1.
                    local stylePower=(style=='minimal' and .52 or style=='forged' and 1.18 or 1.00)
                    local activePower=(power >= .99) and 1.00 or .66
                    local alpha=math.min(1,glow*stylePower*activePower)
                    -- Independent second pass makes 70-100% visibly brighter
                    -- without growing housing, padding, icons or their spacing.
                    local bright=math.max(0,(glow-.35)/.65)
                    local boost=bright*bright*stylePower*activePower*(style=='forged' and .95 or .45)
                    a.light:SetVertexColor(r,g,b,alpha*fade)
                    a.bloom:SetVertexColor(r,g,b,math.min(1,boost)*fade)
                    if a.field then
                        -- Exact modifier only; no field when unrelated buttons
                        -- are held. Ease in and out without moving a single icon.
                        local expected=phases[tonumber(target:sub(2))]
                        local isActive=(phase==expected and phase~="idle")
                        local goal=isActive and 1 or 0
                        local rate=goal==1 and 19 or 12
                        local step=math.min(1,math.max(.016,dt or .05)*rate)
                        a.fieldEnergy=(a.fieldEnergy or 0)+(goal-(a.fieldEnergy or 0))*step
                        local strength=safeNum(c.fieldStrength,0,1) or .78
                        local energy=strength * a.fieldEnergy
                        if energy > .012 then
                            -- Triple-modifier field is multicolor; the other
                            -- diamonds inherit their modifier tint.
                            if target=='d8' then
                                a.field:SetVertexColor(1,1,1,math.min(1,energy)*fade)
                            else
                                a.field:SetVertexColor(r,g,b,math.min(1,energy)*fade)
                            end
                            a.field:Show()
                        else
                            a.field:Hide()
                        end
                    end
                else
                    -- Preserve the existing bar housing illumination response.
                    local powerScale=(style=='minimal' and .13 or style=='forged' and .83 or .78)
                    a.light:SetVertexColor(r,g,b,math.min(1,glow*powerScale*power))
                    a.bloom:SetVertexColor(r,g,b,style=='forged' and math.min(.43,glow*.32*power) or 0)
                end
            end
        end
    end
end
local function refresh(rebuildLegacy)
    if not legal() then dirty=true;return false end
    for _,target in ipairs({'bar1','bar2','pet','d1','d2','d3','d4','d5','d6','d7','d8'}) do
        local c=get(target)
        if c and ((c.style~='off')
            or (c.labelEnabled~=false and type(c.label)=='string' and c.label~='')) then
            ensure(target)
        end
        if attached[target] then paint(target) end
    end
    light(.05)
    dirty=false
    -- Reapply the underlying per-button theme after undo/profile imports.
    -- Retired legacy large plate housings remain disabled; attached frames own housing.
    if rebuildLegacy~=false then
        local legacy=_G.MixolasBarsObsidian
        if legacy and legacy.Apply then pcall(legacy.Apply) end
    end
    return true
end
local function apply(target,key,value)
    if not legal() then return false end
    local db=getDB()
    local current=get(target)
    if not db or not current then return false end
    if key=='style' then
        if value~='off' and not specs[value] then return false end
        if value=='shield' and (target=='diamonds' or target:match('^d')) then return false end
    elseif key=='padding' then value=safeNum(value,0,16)
    elseif key=='opacity' or key=='illumination' or key=='fieldStrength' then value=safeNum(value,0,1)
    elseif key=='fieldSize' then value=safeNum(value,0,28)
    elseif key=='scale' then value=safeNum(value,.70,1.50)
    elseif key=='x' or key=='y' then value=safeNum(value,-48,48)
    elseif key=='label' then
        if type(value)~='string' then return false end
        value=value:gsub('[\r\n]', ' '):sub(1,48)
    elseif key=='labelEnabled' then value=not not value
    elseif key=='labelSide' then
        if value~='TOP' and value~='BOTTOM' and value~='LEFT' and value~='RIGHT' then return false end
    elseif key=='labelSize' then value=safeNum(value,8,26)
    elseif key=='labelGap' then value=safeNum(value,0,30)
    elseif key=='labelShift' then value=safeNum(value,-90,90)
    elseif key=='labelOutline' then
        if value~='NONE' and value~='OUTLINE' and value~='THICKOUTLINE' then return false end
    elseif key=='labelColor' then
        if value~='match' and value~='white' and value~='gold' then return false end
    else return false end
    if value==nil then return false end
    -- The pet housing is drawn on the managed native pet holder. Previously
    -- styling an unmanaged pet bar silently stored the style with no host,
    -- giving the appearance that the style selector did nothing.
    if target=='pet' and key=='style' and value~='off' then
        local dbMain=api.GetDB and api.GetDB()
        local pet=dbMain and dbMain.utilityBars and dbMain.utilityBars.pet
        if pet and not pet.enabled then
            if not (api.SetUtilityBar and api.SetUtilityBar('pet','enabled',true)) then
                return false
            end
        end
    end
    current[key]=value
    -- Editing 'all diamonds' changes the shared style and clears the individual
    -- overrides only for the same property, preserving their other adjustments.
    if target=='diamonds' then
        for i=1,8 do
            local d=db['d'..i]
            if type(d)=='table' then d[key]=nil end
        end
    end
    db[target]=current
    dirty=true
    local ok=pcall(refresh,key=='style')
    if not ok then stopped=true end
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return ok
end
local function reset(target)
    if not legal() then return false end
    local db=getDB()
    if not db or not get(target) then return false end
    db[target]=nil
    if target=='diamonds' then for i=1,8 do db['d'..i]=nil end end
    dirty=true
    local ok=pcall(refresh)
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return ok
end
api.GetFrameStudioStyle=get
api.SetFrameStudioOption=apply
api.ResetFrameStudioStyle=reset
api.RefreshFrameStudio=refresh
local driver=CreateFrame('Frame')
driver:RegisterEvent('PLAYER_LOGIN')
driver:RegisterEvent('PLAYER_ENTERING_WORLD')
driver:RegisterEvent('PLAYER_REGEN_ENABLED')
driver:SetScript('OnEvent',function() dirty=true end)
driver:SetScript('OnUpdate',function(_,dt)
    if stopped then return end
    tick=tick+(dt or 0)
    if tick<.05 then return end
    local period=tick
    tick=0
    if dirty then
        if legal() then
            local ok=pcall(refresh)
            if not ok then stopped=true; if api.Say then api.Say('Frame Studio visuals disabled after an error; action bars remain active.') end end
        end
    else
        local ok=pcall(light,period)
        if not ok then stopped=true end
    end
end)
