-- Mixolas Bars: windows belong to the addon, remain independently draggable,
-- and remember their positions via SavedVariables. No layout unlock required.
local api=_G.MixolasBarsAPI
if not api then return end
-- Record the window's real factory anchor before SavedVariables move it.
local originalWindows={}
local function clonePoints(frame)
    local points={}
    if not frame.GetNumPoints or not frame.GetPoint then return points end
    for i=1,frame:GetNumPoints() do
        local point,relative,relativePoint,x,y=frame:GetPoint(i)
        points[i]={point=point,relative=relative,relativePoint=relativePoint,x=x,y=y}
    end
    return points
end
api.ResetWindowPositions=function()
    if api.IsInCombat and api.IsInCombat() then return false end
    local db=api.GetDB()
    if not db then return false end
    db.windowPositions={}
    for frame,pts in pairs(originalWindows) do
        if frame and frame.ClearAllPoints and frame.SetPoint then
            frame:ClearAllPoints()
            for _,point in ipairs(pts) do
                frame:SetPoint(point.point,point.relative,point.relativePoint,point.x,point.y)
            end
        end
    end
    return true
end
local function coords(frame)
    local x,y=frame:GetCenter()
    local cx,cy=UIParent:GetCenter()
    if not x or not cx then return nil end
    local scale=(frame:GetEffectiveScale() or 1)/math.max(UIParent:GetEffectiveScale() or 1,0.001)
    return x*scale-cx,y*scale-cy
end
api.MakeMovableWindow=function(frame, key)
    if not frame then return end
    if not originalWindows[frame] then originalWindows[frame]=clonePoints(frame) end
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",function(self)
        if self.IsShown and self:IsShown() then self:StartMoving() end
    end)
    frame:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local d=api.GetDB()
        local x,y=coords(self)
        if d and x and y then
            d.windowPositions=d.windowPositions or {}
            d.windowPositions[key]={x,y}
        end
    end)
    local db=api.GetDB()
    local p=db and db.windowPositions and db.windowPositions[key]
    if type(p)=="table" and type(p[1])=="number" and type(p[2])=="number" then
        frame:ClearAllPoints()
        frame:SetPoint("CENTER",UIParent,"CENTER",p[1],p[2])
    end
end
