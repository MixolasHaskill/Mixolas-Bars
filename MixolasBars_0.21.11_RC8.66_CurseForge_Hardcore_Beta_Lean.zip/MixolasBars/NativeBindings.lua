-- Native WoW binding snapshots for Mixolas named profiles.
-- Covers every command exposed by GetNumBindings/GetBindingKey, including
-- interface panels, targeting, movement and traditional action-bar keys.
-- NEVER transfers spells or macros from action slots. All writes are out of combat.
local api = _G.MixolasBarsAPI
if not api then return end

local MAX_COMMANDS, MAX_KEYS = 4096, 4096
local function ready()
    return type(GetNumBindings)=='function' and type(GetBinding)=='function'
        and type(GetBindingKey)=='function' and type(GetBindingAction)=='function'
end
local function knownCommands()
    if not ready() then return nil,'Native binding API is unavailable.' end
    local ok,n=pcall(GetNumBindings)
    if not ok or type(n)~='number' or n<0 or n>MAX_COMMANDS then
        return nil,'WoW returned an invalid binding count.'
    end
    local commands={}
    for i=1,n do
        local success,command=pcall(GetBinding,i)
        if not success then return nil,'Cannot enumerate WoW binding '..i..'.' end
        if type(command)=='string' and command~='' then commands[command]=true end
    end
    return commands
end
local function capture()
    local commands,err=knownCommands()
    if not commands then return nil,err end
    local keys={}
    local count=0
    for command in pairs(commands) do
        local ok,list=pcall(function() return {GetBindingKey(command)} end)
        if not ok then return nil,'Cannot inspect keys for '..command..'.' end
        for _,key in ipairs(list) do
            if type(key)=='string' and key~='' then
                if keys[key] and keys[key]~=command then
                    return nil,'WoW reported duplicate key ownership: '..key
                end
                keys[key]=command
                count=count+1
                if count>MAX_KEYS then return nil,'Too many native keys to snapshot.' end
            end
        end
    end
    return {version=1,keys=keys,sourceSet=(GetCurrentBindingSet and GetCurrentBindingSet()) or 1}
end
local function count(snapshot)
    local n=0
    for _ in pairs((type(snapshot)=='table' and snapshot.keys) or {}) do n=n+1 end
    return n
end
-- Transactional restore of the enumeration-known keys only. Do not call
-- LoadBindings(DEFAULT_BINDINGS); never reset non-target Blizzard defaults.
-- Save as CHARACTER bindings so changing a Mixolas profile on one character
-- cannot silently overwrite account-wide controls used by other characters.
local function restore(snapshot)
    if api.IsInCombat and api.IsInCombat() or (InCombatLockdown and InCombatLockdown()) then
        return false,'Cannot restore native keys during combat.'
    end
    if type(snapshot)~='table' or snapshot.version~=1 or type(snapshot.keys)~='table' then
        return false,'Invalid native binding snapshot.'
    end
    if type(SetBinding)~='function' or type(SaveBindings)~='function' then
        return false,'WoW does not expose native binding writes on this client.'
    end
    local commands,err=knownCommands()
    if not commands then return false,err end
    local current,why=capture()
    if not current then return false,why end
    local target,skipped={},0
    local seen=0
    for key,command in pairs(snapshot.keys) do
        if type(key)~='string' or #key<1 or #key>64 or key:find('%c')
            or type(command)~='string' or #command<1 or #command>256 or command:find('%c') then
            return false,'Invalid key or command stored in profile.'
        end
        seen=seen+1
        if seen>MAX_KEYS then return false,'Profile has too many native bindings.' end
        if commands[command] then target[key]=command else skipped=skipped+1 end
    end
    -- An unsupported command from another client must not clear its key.
    -- Preserve existing ownership on the destination for those commands.
    for key,command in pairs(snapshot.keys) do
        if not commands[command] and current.keys[key] then target[key]=current.keys[key] end
    end
    local changed={}
    for key,command in pairs(current.keys) do
        if target[key]~=command then changed[#changed+1]=key end
    end
    for key,command in pairs(target) do
        if current.keys[key]~=command and current.keys[key]==nil then changed[#changed+1]=key end
    end
    table.sort(changed)
    if #changed==0 then return true,{applied=0,skipped=skipped,unchanged=true} end
    local touched={}
    local function write(key,command)
        local ok,value=pcall(SetBinding,key,command)
        return ok and value~=false and value~=nil
    end
    local function rollBack()
        for i=#touched,1,-1 do
            local key=touched[i]
            pcall(SetBinding,key,current.keys[key])
        end
    end
    -- In the first pass, release changed keys. In the second, assign target
    -- commands. This also handles swaps like M <-> SHIFT-M safely.
    for _,key in ipairs(changed) do
        if current.keys[key] then
            if not write(key,nil) then rollBack();return false,'WoW refused to unbind '..key end
            touched[#touched+1]=key
        end
    end
    for _,key in ipairs(changed) do
        if target[key] then
            if not write(key,target[key]) then
                rollBack()
                return false,'WoW refused to assign '..key..' to '..target[key]
            end
            if not current.keys[key] then touched[#touched+1]=key end
        end
    end
    -- Test the actual native binding action, not a Mixolas secure override.
    for _,key in ipairs(changed) do
        local ok,command=pcall(GetBindingAction,key)
        if not ok or (command or '')~=(target[key] or '') then
            rollBack()
            return false,'WoW did not accept the expected command for '..key
        end
    end
    local ok,saved=pcall(SaveBindings,CHARACTER_BINDINGS or 2)
    if not ok or saved==false then
        rollBack()
        return false,'WoW could not save character-specific native bindings.'
    end
    return true,{applied=#changed,skipped=skipped}
end
api.CaptureNativeBindings=capture
api.GetNativeBindingCommands=knownCommands
api.RestoreNativeBindings=restore
api.CountNativeBindings=count
