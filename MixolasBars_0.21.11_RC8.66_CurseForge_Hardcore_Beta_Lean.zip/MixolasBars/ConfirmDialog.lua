-- Standalone, draggable addon confirmation dialog. We never modify or
-- permanently turn Blizzard's shared StaticPopup frames into movable widgets.
local api=_G.MixolasBarsAPI
if not api then return end
local dialog,callback,cancelCallback,twoStep
local function setup()
    if dialog then return end
    dialog=CreateFrame("Frame","MixolasBarsConfirmWindow",UIParent,
        BackdropTemplateMixin and "BackdropTemplate" or nil)
    dialog:SetSize(500,218)
    -- WoW does not guarantee any visible/default anchor for a newly created
    -- frame. Without a SetPoint, a confirmation can be logically shown but
    -- appear off-screen (missed by headless OnClick tests). Establish a real
    -- centered factory position BEFORE MakeMovableWindow saves/restores it.
    dialog:SetPoint("CENTER",UIParent,"CENTER",0,0)
    dialog:SetFrameStrata("FULLSCREEN_DIALOG")
    dialog:SetFrameLevel(420)
    dialog:SetClampedToScreen(true)
    if dialog.SetBackdrop then
        dialog:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=4,right=4,top=4,bottom=4}})
        dialog:SetBackdropColor(0.85,0.85,0.85,0.98)
        dialog:SetBackdropBorderColor(1,1,1,1)
    end
    if api.MakeMovableWindow then api.MakeMovableWindow(dialog,"confirm") end
    local title=dialog:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOP",dialog,"TOP",0,-17)
    title:SetWidth(455)
    dialog.title=title
    local detail=dialog:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    detail:SetPoint("TOP",dialog,"TOP",0,-67)
    detail:SetWidth(450)
    detail:SetJustifyH("CENTER")
    dialog.detail=detail
    local ok=CreateFrame("Button",nil,dialog,"UIPanelButtonTemplate")
    ok:SetSize(174,29);ok:SetPoint("BOTTOM",dialog,"BOTTOM",-95,17)
    ok:SetScript("OnClick",function()
        -- Two warnings use ONE persistent window. Reopening the same frame
        -- from a close callback lost stage 2 on some WoW clients.
        -- Stage 1 only updates the visible warning; no binding code runs.
        if twoStep then
            local staged=twoStep
            if staged.validate and not staged.validate() then
                dialog:Hide()
                return
            end
            if staged.stage==1 then
                staged.stage=2
                dialog.title:SetText(staged.title2)
                dialog.detail:SetText(staged.detail2)
                dialog.accept:SetText(staged.finalLabel)
                return
            end
            local accepted=staged.onAccept
            twoStep=nil
            callback=nil
            cancelCallback=nil
            dialog:Hide()
            if accepted then accepted() end
            return
        end
        local accepted=callback
        callback=nil
        cancelCallback=nil
        dialog:Hide()
        if accepted then accepted() end
    end)
    dialog.accept=ok
    local cancel=CreateFrame("Button",nil,dialog,"UIPanelButtonTemplate")
    cancel:SetSize(174,29);cancel:SetPoint("BOTTOM",dialog,"BOTTOM",95,17)
    cancel:SetText("KEEP EXISTING")
    dialog.cancel=cancel
    cancel:SetScript("OnClick",function()
        local discarded=cancelCallback
        callback=nil
        cancelCallback=nil
        twoStep=nil
        dialog:Hide()
        if discarded then discarded() end
    end)
    -- Escape and other Blizzard-managed window closures bypass the Cancel
    -- button. Always resume the editor's keyboard capture on any dismissal.
    dialog:SetScript("OnHide",function()
        local discarded=cancelCallback
        callback=nil
        cancelCallback=nil
        twoStep=nil
        if discarded then discarded() end
    end)
    dialog:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames,"MixolasBarsConfirmWindow") end
end
api.ShowConfirm=function(title,detail,onAccept,acceptLabel,onCancel,cancelLabel)
    setup()
    twoStep=nil
    callback=onAccept
    cancelCallback=onCancel
    dialog.title:SetText(tostring(title or "Confirm"))
    dialog.detail:SetText(tostring(detail or ""))
    dialog.accept:SetText(acceptLabel or "Continue")
    dialog.cancel:SetText(cancelLabel or "KEEP EXISTING")
    dialog:Show()
    if dialog.Raise then dialog:Raise() end
    return true
end

-- Single-window, two-step confirmation for destructive settings actions.
-- First click only advances the displayed warning; second click executes.
-- Cancel or Escape at either stage abandons the operation.
api.ShowTwoStepConfirm=function(config)
    if type(config)~="table" or type(config.onAccept)~="function" then return false end
    setup()
    callback=nil
    cancelCallback=config.onCancel
    twoStep={
        stage=1,
        title2=tostring(config.title2 or "FINAL WARNING - 2 OF 2"),
        detail2=tostring(config.detail2 or "This action cannot be undone without a saved backup."),
        finalLabel=tostring(config.finalLabel or "YES, CLEAR ALL"),
        validate=config.validate,
        onAccept=config.onAccept,
    }
    dialog.title:SetText(tostring(config.title1 or "WARNING 1 OF 2"))
    dialog.detail:SetText(tostring(config.detail1 or "Continue to the final warning?"))
    dialog.accept:SetText(tostring(config.firstLabel or "CONTINUE TO FINAL WARNING"))
    dialog.cancel:SetText("KEEP EXISTING")
    dialog:Show()
    if dialog.Raise then dialog:Raise() end
    return true
end

api.DismissConfirm=function()
    if dialog and dialog:IsShown() then dialog:Hide(); return true end
    return false
end
api.IsConfirmOpen=function() return dialog and dialog:IsShown() or false end
