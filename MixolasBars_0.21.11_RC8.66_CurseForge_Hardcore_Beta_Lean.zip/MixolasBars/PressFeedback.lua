-- Visual-only feedback for secure proxy and mouse activation.
-- No protected attributes or spell execution are changed here.
local feedback = {}
_G.MixolasBarsPressFeedback = feedback
local active = {}
local MIN_FLASH = 0.16   -- visible even when Steam Input sends a quick tap
local FADE = 0.085
local LOST_UP_TIMEOUT = 2.0 -- failsafe for beta clients without a key-up event

local function clock()
    return GetTime and GetTime() or 0
end
local function shade(button, alpha)
    local fx=button and button.pressedShade
    if not fx then return end
    if alpha <= 0 then fx:Hide() else
        fx:SetAlpha(alpha)
        fx:Show()
    end
end

function feedback.Reset(button)
    if not button then return end
    active[button]=nil
    shade(button,0)
end

function feedback.Press(button, isDown)
    if not button or not button.pressedShade then return end
    if button._mixolasSuppressClick then feedback.Reset(button); return end
    -- Do not animate a drop: an item/spell currently on the cursor isn't cast.
    if GetCursorInfo and GetCursorInfo() then feedback.Reset(button); return end
    local now=clock()
    local state=active[button]
    if isDown == true then
        state=state or {}
        state.held=true
        state.started=now
        state.untilTime=now+MIN_FLASH
        active[button]=state
        shade(button,1)
    elseif isDown == false then
        -- Some secure keyclick bindings deliver only Up, not a corresponding
        -- Down. Still show a short confirmation for a successful keyclick.
        state=state or {started=now}
        state.held=false
        state.untilTime=math.max(state.untilTime or now,now+MIN_FLASH)
        active[button]=state
        shade(button,1)
    else
        state={held=false,started=now,untilTime=now+MIN_FLASH}
        active[button]=state
        shade(button,1)
    end
end

local driver=CreateFrame("Frame")
driver:SetScript("OnUpdate",function()
    local now=clock()
    for button,s in pairs(active) do
        if button._mixolasSuppressClick or (GetCursorInfo and GetCursorInfo()) then
            feedback.Reset(button)
        else
        -- With matching Down/Up events the state tracks the held input.
        -- Missing release events in some betas must never leave a stuck shade.
        if s.held and now-s.started >= LOST_UP_TIMEOUT then
            s.held=false
            s.untilTime=now
        end
        if s.held or now<s.untilTime then
            shade(button,1)
        elseif now<s.untilTime+FADE then
            shade(button,1-(now-s.untilTime)/FADE)
        else
            feedback.Reset(button)
        end
        end
    end
end)
