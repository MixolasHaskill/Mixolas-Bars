-- Mixolas Bars RC8.28: three scoped keybinding clear operations with durable recovery.
-- Clear Bar: Mixolas custom bar keys + inherited native action-bar keys ONLY.
-- Clear Native: native WoW keys ONLY.  Clear All: both.
-- A snapshot is kept per character and per named profile in SavedVariables.
local api=_G.MixolasBarsAPI
if not api then return end
local function copy(src,depth)
    if type(src)~='table' then return src end
    if (depth or 0)>12 then return nil end
    local dst={}
    for key,v in pairs(src) do
        if type(key)=='string' or type(key)=='number' then
            if type(v)=='table' or type(v)=='string' or type(v)=='number' or type(v)=='boolean' then
                dst[key]=copy(v,(depth or 0)+1)
            end
        end
    end
    return dst
end
local function count(src)
    local n=0
    for _ in pairs(src or {}) do n=n+1 end
    return n
end
local function barCount(map)
    local n=0
    for _,keys in pairs(map or {}) do
        if type(keys)=='table' then n=n+#keys end
    end
    return n
end
local function isBarCommand(command)
    if type(command)~='string' then return false end
    return command:match('^ACTIONBUTTON%d+$')~=nil
        or command:match('^MULTIACTIONBAR[1-4]BUTTON%d+$')~=nil
end
local function eligible(needUndo)
    if not api.IsReady or not api.IsReady() then return nil,'Addon is not ready.' end
    if (api.IsInCombat and api.IsInCombat()) or (InCombatLockdown and InCombatLockdown()) then
        return nil,'Cannot modify keybindings in combat.'
    end
    if api.IsBindingMode and api.IsBindingMode() then return nil,'Exit keybinding edit mode first.' end
    local name=api.GetActiveProfileName and api.GetActiveProfileName()
    local db=api.GetDB and api.GetDB()
    local char=api.GetCharacterDB and api.GetCharacterDB()
    if not name or not db or not char or type((db.mixolasProfiles or {})[name])~='table' then
        return nil,'Select an existing named Mixolas profile first.'
    end
    if not (api.RestoreNativeBindings and api.CaptureNativeBindings and api.SaveActiveNativeBindings
        and api.SetCharacterBindings and api.ApplyBindings) then
        return nil,'Binding services are not ready.'
    end
    if needUndo and (not api.RunBatchEdit or not api.CanRecordUndo or not api.CanRecordUndo()) then
        return nil,'Undo history is not ready. Try again after loading.'
    end
    return name,db,char
end
local function snapshot(name,db,char)
    local native,reason=api.CaptureNativeBindings()
    if not native then return nil,reason end
    if type(native.keys)~='table' then return nil,'Unable to capture native binding keys.' end
    local profile=(db.mixolasProfiles or {})[name]
    return {
        version=1,
        profile=name,
        bar=copy(char.bindings or db.bindings or {}),
        native=copy(native),
        savedNative=copy(profile and profile.nativeBindings),
    }
end
local function targetNative(before,scope)
    local target={version=1,keys={},sourceSet=before.native.sourceSet}
    if scope=='bar' then
        for key,cmd in pairs(before.native.keys) do
            if not isBarCommand(cmd) then target.keys[key]=cmd end
        end
    end
    return target
end
local function restore(before,name,db)
    local problems={}
    local ok,why=api.RestoreNativeBindings(before.native)
    if not ok then problems[#problems+1]='native: '..tostring(why) end
    if api.SetCharacterBindings(copy(before.bar))==false then
        problems[#problems+1]='Mixolas bar keys'
    end
    local route,accepted=pcall(api.ApplyBindings)
    if not route or accepted==false then problems[#problems+1]='bar routing' end
    if ok then
        local saved,msg=api.SaveActiveNativeBindings()
        if not saved then problems[#problems+1]='native profile save: '..tostring(msg) end
    end
    if #problems==0 and before.savedNative then
        -- Preserve dormant, unsupported native commands in the original profile.
        local profile=db.mixolasProfiles and db.mixolasProfiles[name]
        if profile then profile.nativeBindings=copy(before.savedNative); profile.version=4 end
    end
    if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
    return #problems==0,table.concat(problems,'; ')
end
local function checkScope(scope)
    return scope=='bar' or scope=='native' or scope=='all'
end
api.GetBindingClearSummary=function()
    local name,db,char=eligible(false)
    if not name then return nil,db end
    local before,err=snapshot(name,db,char)
    if not before then return nil,err end
    local barKeys=barCount(before.bar)
    local nativeKeys=count(before.native.keys)
    local inherited=0
    for _,cmd in pairs(before.native.keys) do if isBarCommand(cmd) then inherited=inherited+1 end end
    return {profile=name,bar=barKeys,native=nativeKeys,inherited=inherited,
        hasRecovery=type(char.mixolasBindingClearRecovery)=='table' and
            type(char.mixolasBindingClearRecovery[name])=='table'}
end
local function execute(scope,expected)
    if not checkScope(scope) then return false,'Invalid clear scope.' end
    local name,db,char=eligible(true)
    if not name then return false,db end
    if expected~=name then return false,'The active profile changed. Clear canceled.' end
    local before,err=snapshot(name,db,char)
    if not before then return false,err end
    local target=targetNative(before,scope)
    local nativeCount=0
    for key,cmd in pairs(before.native.keys) do
        if target.keys[key]~=cmd then nativeCount=nativeCount+1 end
    end
    local bars=(scope~='native') and barCount(before.bar) or 0
    if scope=='native' then nativeCount=count(before.native.keys) end
    if scope=='all' then nativeCount=count(before.native.keys) end
    if bars==0 and nativeCount==0 then return false,'This profile has no keybindings in the selected category.' end
    -- Persist BEFORE attempting a destructive write, to protect against a crash.
    -- Only one latest clear recovery per named profile/character is retained.
    char.mixolasBindingClearRecovery=char.mixolasBindingClearRecovery or {}
    local prior=copy(char.mixolasBindingClearRecovery[name])
    local recovery=copy(before)
    recovery.scope=scope
    recovery.saved=(date and date('%Y-%m-%d %H:%M') or 'Latest clear')
    char.mixolasBindingClearRecovery[name]=recovery
    local completed=false
    local problem='Could not complete the keybinding clear.'
    local success,why=pcall(function()
        api.RunBatchEdit('Clear '..scope..' keybindings',function()
            if api.GetActiveProfileName()~=name or
                (api.IsInCombat and api.IsInCombat()) or (InCombatLockdown and InCombatLockdown()) then
                problem='Profile changed or combat started. Clear canceled.'
                return false
            end
            if nativeCount>0 then
                local ok,msg=api.RestoreNativeBindings(target)
                if not ok then problem='WoW rejected native clear: '..tostring(msg);return false end
            end
            if scope~='native' then
                if api.SetCharacterBindings({})==false then
                    problem='Failed to clear Mixolas-owned bar shortcuts.';return false
                end
                local routed,accepted=pcall(api.ApplyBindings)
                if not routed or accepted==false then
                    problem='Bar keybinding routing failed.';return false
                end
            end
            if nativeCount>0 then
                local saved,msg=api.SaveActiveNativeBindings()
                if not saved then problem='Failed to auto-save WoW native keys: '..tostring(msg);return false end
            end
            if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
            completed=true
            return true
        end)
    end)
    if not success or not completed then
        local rolled,rollReason=restore(before,name,db)
        -- If rollback itself failed, retain the pre-clear snapshot on disk so
        -- the user can recover after reloading or resolving the native error.
        char.mixolasBindingClearRecovery[name]=rolled and prior or recovery
        return false,(not success and tostring(why) or problem)..(rolled and ' Previous bindings restored.'
            or ' ROLLBACK INCOMPLETE: '..tostring(rollReason))
    end
    return true,'Cleared '..bars..' Mixolas keys and '..nativeCount..' native keys in '..name..
        '. Undo restores them during this session; export first for a backup.'
end
api.ClearScopedKeybinds=execute
api.RestoreLastClearedKeybinds=function(expected)
    -- Persistent recovery must be independent of the session Undo engine.
    -- A user may need recovery precisely because Undo is unavailable/failed.
    local name,db,char=eligible(false)
    if not name then return false,db end
    if expected~=name then return false,'The active profile changed. Restore canceled.' end
    local backup=(char.mixolasBindingClearRecovery or {})[name]
    if type(backup)~='table' or backup.version~=1 or backup.profile~=name
        or type(backup.bar)~='table' or type(backup.native)~='table' then
        return false,'No recovery snapshot exists for the selected profile on this character.'
    end
    local current,reason=snapshot(name,db,char)
    if not current then return false,reason end
    local success,done,why=pcall(restore,backup,name,db)
    if not success or not done then
        local rolled,rollback=restore(current,name,db)
        return false,'Recovery failed: '..tostring(success and why or done)..'. '..
            (rolled and 'Current keys preserved.' or 'ROLLBACK FAILED: '..tostring(rollback))
    end
    return true,'Restored bindings saved before the latest clear of '..name..'.'
end

-- Clear Bar Keybinds opens the first safety warning directly from the
-- Keybindings page. No intermediate management window is necessary.
local barWarning
local function notice(message)
    if api.Say then api.Say(message) end
end
local function makeButton(parent,text,x,y,width,onClick)
    local b=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    b:SetSize(width or 180,29)
    b:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    b:SetText(text)
    b:SetScript('OnClick',onClick)
    return b
end
local function currentName()
    return api.GetActiveProfileName and api.GetActiveProfileName() or nil
end
-- Dedicated warning for bar clearing.  This deliberately does NOT use the
-- shared ConfirmDialog: in live WoW tests that popup did not advance reliably
-- from the first warning to the second. Stage two has its own distinct button
-- and only that button can perform a destructive action.
local function closeBarWarning()
    if barWarning then barWarning:Hide() end
end
local function buildBarWarning()
    if barWarning then return end
    local w=CreateFrame('Frame','MixolasBarsBarClearWarning',UIParent,
        BackdropTemplateMixin and 'BackdropTemplate' or nil)
    w:SetSize(540,260)
    w:SetFrameStrata('FULLSCREEN_DIALOG')
    w:SetFrameLevel(460)
    w:SetClampedToScreen(true)
    w:SetPoint('CENTER',UIParent,'CENTER',0,0)
    w:EnableMouse(true)
    if w.SetBackdrop then
        w:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',
            edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',tile=true,tileSize=32,edgeSize=24,
            insets={left=4,right=4,top=4,bottom=4}})
    end
    w.heading=w:CreateFontString(nil,'OVERLAY','GameFontNormalLarge')
    w.heading:SetPoint('TOP',w,'TOP',0,-22)
    w.message=w:CreateFontString(nil,'OVERLAY','GameFontHighlight')
    w.message:SetPoint('TOP',w,'TOP',0,-75)
    w.message:SetWidth(485)
    w.message:SetJustifyH('CENTER')
    w.next=makeButton(w,'CONTINUE TO WARNING 2',30,-204,282,function()
        if w.stage~=1 then return end
        if w.profile~=currentName() or (api.IsInCombat and api.IsInCombat()) then
            closeBarWarning()
            notice('Profile changed or combat began. Nothing cleared.')
            return
        end
        w.stage=2
        w.heading:SetText('CLEAR BAR KEYBINDS - WARNING 2 OF 2')
        w.message:SetText('FINAL WARNING\nProfile: '..w.profile..'\n'
            ..'Remove all Mixolas and inherited action-bar keys for this profile?\n'
            ..'Other profiles, spell placements, movement and interface keys stay intact.\n'
            ..'Back up keybindings using Import / Export before clearing.')
        w.next:Hide()
        w.final:Show()
    end)
    w.final=makeButton(w,'YES, CLEAR BAR KEYS',30,-204,282,function()
        if w.stage~=2 then return end
        local name=w.profile
        w:Hide()
        if currentName()~=name or (api.IsInCombat and api.IsInCombat()) then
            notice('Active profile changed or combat began. Nothing cleared.')
            return
        end
        local ok,msg=api.ClearScopedKeybinds('bar',name)
        notice(msg or (ok and 'Bar keybindings cleared.' or 'Clear failed.'))
    end)
    makeButton(w,'CANCEL',330,-204,180,closeBarWarning)
    w:SetScript('OnHide',function(self)
        self.stage=nil
        self.profile=nil
    end)
    w:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames,'MixolasBarsBarClearWarning') end
    barWarning=w
end
local function openBarWarning()
    local summary,err=api.GetBindingClearSummary()
    if not summary then notice(err or 'Cannot inspect this profile.');return end
    buildBarWarning()
    barWarning.profile=summary.profile
    barWarning.stage=1
    barWarning.heading:SetText('CLEAR BAR KEYBINDS - WARNING 1 OF 2')
    barWarning.message:SetText('Profile: '..summary.profile..'\n'
        ..'This will remove '..summary.bar..' custom Mixolas shortcuts and '..summary.inherited..' inherited native action-bar shortcuts.\n'
        ..'No bindings are changed until the final warning is accepted.')
    barWarning.final:Hide()
    barWarning.next:Show()
    barWarning:Show()
end
-- Retain the public entry point used by SettingsUI for compatibility, but
-- go straight to warning 1. The next button advances the SAME dialog to
-- warning 2. Neither dismissal nor cancellation can modify bindings.
api.OpenBindingClearManager=function()
    openBarWarning()
end
