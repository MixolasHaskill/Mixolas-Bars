-- Mixolas Bars v0.21.11-rc.4 (Classic Era/Hardcore 11509 + Forever 16001)
-- Independent proof of concept. Does not include or modify Bartender4.
-- Diamonds have their own native Classic bar action slots, never Bar 1 or class-form pages.
-- ALL keybindings are optional, manually assigned to any visible spell button.
-- Change positions and secure button attributes ONLY outside combat.

local ADDON_NAME = ...
local PREFIX = "|cff65baffMixolas Bars|r: "
local clusters = {}
local initialized = false
local spellEditMode = false
local regularButtons = {}
local bindingOwner = CreateFrame("Frame", "MixolasBarsBindingOwner", UIParent)
local bindingReport = {attempted=0, errors={}, mismatches={}, routes={}}
local applyingBindings = false
local characterDB -- initialized on PLAYER_LOGIN, stores character-specific bindings/actions
local TOTAL_DIAMONDS = 8
local activeDragSource = nil
local activeActionDrag = nil  -- source button retained until physical mouse release
-- Forever's October 15 beta broke automatic Warrior/Rogue action paging.
-- Bartender4-style explicit secure stance conditions work independently of
-- the Blizzard action-bar page state. Never set pages from a normal event
-- callback or mutate the actual action slots in response to a stance swap.
local DEFAULT_PAGE_STATE = "[bonusbar:1] 7; [bonusbar:2] 8; [bonusbar:3] 9; [bonusbar:4] 10; [bonusbar:5] 11; [bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; 1"
local WARRIOR_PAGE_STATE = "[stance:1] 7; [stance:2] 8; [stance:3] 9; 7"
local ROGUE_PAGE_STATE = "[stealth] 7; [stance:1] 7; 1"
-- Bartender4's Classic/Forever forms: cat is bonusbar 1 => page 7,
-- prowl while in cat => page 8, bear is bonusbar 3 => page 9.
-- Aquatic/travel forms do not borrow cat/bear pages; preserve other native
-- bonus bars where supported. Avoid assuming GetShapeshiftForm() is static.
local DRUID_PAGE_STATE = "[bonusbar:1,stealth] 8; [bonusbar:1] 7; [bonusbar:3] 9; [bonusbar:2] 8; [bonusbar:4] 10; [bonusbar:5] 11; 1"
local function pageStateForClass(class)
    if class == "WARRIOR" then return WARRIOR_PAGE_STATE end
    if class == "ROGUE" then return ROGUE_PAGE_STATE end
    if class == "DRUID" then return DRUID_PAGE_STATE end
    return DEFAULT_PAGE_STATE
end
local function currentPageState()
    local _, class = UnitClass and UnitClass("player")
    return pageStateForClass(class)
end
local inLockdown = InCombatLockdown or function() return false end
local compat = _G.MixolasBarsCompat or {}
local feedback = _G.MixolasBarsPressFeedback or {}


-- Classic Era action-slot IDs are non-sequential. Diamond bars 3-5
-- never use Bar 1 (1-12), main page 2 (13-24), or bonus pages (73-120).
local DIAMOND_BAR = {3,3,3,4,4,4,5,5}
local function diamondSlot(index, position)
    -- Bar 1: stance/form main action bar. Bar 2: LEFT STICK / SPACE.
    -- Bar 3: Diamonds 1-3; Bar 4: Diamonds 4-6; Bar 5: Diamonds 7-8.
    if index <= 3 then return 48 + (index - 1) * 4 + position end -- 49..60
    if index <= 6 then return 24 + (index - 4) * 4 + position end -- 25..36
    return 36 + (index - 7) * 4 + position -- 37..44
end
local function positionToParentUnits(frame)
    local x,y = frame:GetCenter()
    local cx,cy = UIParent:GetCenter()
    if not (x and y and cx and cy) then return nil end
    local sf = (frame.GetEffectiveScale and frame:GetEffectiveScale()) or 1
    local sp = (UIParent.GetEffectiveScale and UIParent:GetEffectiveScale()) or 1
    if sp == 0 then sp = 1 end
    return x * sf/sp - cx, y * sf/sp - cy
end

local DEFAULTS = {
    locked = true,
    snapEnabled = true, -- 10 UIParent-unit XY grid + center/quarter guide/edge docking
    minimapAngle = 220,
    minimapSize = 31, -- 20..56px icon; actual map dimensions determine attachment radius
    editorScale = 1.0, -- resize the Mixolas options window only (not Blizzard UI or action bars)
    hideBlizzard = true, -- Hide native action buttons by default; user can restore in Options
    hideBlizzardArt = true, -- Hide native main-bar artwork by default
    visible = true,
    buttonSize = 38,
    gap = 3,
    diamondGapEW = 0, -- first-time default: east/west icons touch; legacy gap preserved by migration below
    diamondGapNS = 3, -- first-time default: independent north/south spacing
    glow = 0.23,
    -- Optional per-diamond overrides. Absent values inherit legacy global glow.
    diamondGlows = {},
    diamondIlluminationStyles = {},
    illuminationStyle = "refined", -- refined (default) or classic
    glowSpread = 2,
    glowSaturation = 0.86,
    borderAlpha = 1.0,
    borderWidth = 2,
    hotkeyFontSize = 8,
    itemCountFontSize = 8, -- quantity text in bottom-right of diamond and regular buttons
    showHotkeys = true,
    showMacroNames = true, -- compact lower-left macro name, never the spell name
    rangeDim = 0.55,
    combatDim = 0.39, -- dim actions the Classic client reports unusable while in combat
    combatUsability = true, -- mandatory (older saved false setting auto-migrated)
    buttonLock = false,
    gcdSweep = true,
    gcdDarkness = 0.48,
    bindings = {}, -- button slot string -> up to three optional Mixolas keys; independent of WoW native bindings
    nativeBindingInheritance = true, -- route WoW client-side action bar shortcuts to our secure proxies; custom Mixolas keys win
    counts = {4,4,4,4,4,4,4,4},
    -- Steam Controller presentation: six diamonds in a 2x3 grid by default.
    -- Purple/prismatic action slots and secure code are retained, merely hidden.
    diamondEnabled = {true,true,true,true,true,true,false,false},
    -- Per-diamond empty slot visibility; default ON preserves existing layouts.
    diamondShowEmpty = {true,true,true,true,true,true,true,true},
    alphas = {1,1,1,1,1,1,1,1}, -- legacy and out-of-combat diamond opacity
    combatAlphas = {}, -- nil per diamond inherits its original alpha
    brightness = {1,1,1,1,1,1,1,1},
    scales = {1,1,1,1,1,1,1,1},
    borderStyles = {"solid","solid","solid","solid","solid","solid","solid","solid"},
    glowMotions = {"static","static","static","static","static","static","static","static"},
    customActions = {}, -- index by absolute button ID; no standard WoW action slot is consumed
    colors = {
        {0.20, 0.85, 0.36}, -- green
        {1.00, 0.82, 0.20}, -- yellow
        {1.00, 0.57, 0.18}, -- orange
        {0.25, 0.62, 1.00}, -- blue
        {0.88, 0.89, 0.91}, -- white
        {1.00, 0.28, 0.32}, -- red
        {0.69, 0.35, 0.89}, -- purple (Shift+Ctrl)
        {1.00, 0.30, 0.30}, -- animated red/yellow/blue (all modifiers)
    },
    positions = {
        {-155, -10},
        {0, -10},
        {155, -10},
        {-155, -155},
        {0, -155},
        {155, -155},
        {-80, -300},
        {80, -300},
    },
}

local function say(message)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(PREFIX .. tostring(message))
    end
end

local function copyDefaults(target, defaults)
    for k, v in pairs(defaults) do
        if target[k] == nil then
            if type(v) == "table" then
                target[k] = {}
                copyDefaults(target[k], v)
            else
                target[k] = v
            end
        elseif type(v) == "table" and type(target[k]) == "table" then
            copyDefaults(target[k], v)
        end
    end
end

local function setBorderColor(button, color, glow, alpha, width, brightness, style, lightStyle)
    if not button.frameLines then return end
    brightness = brightness or 1
    style = style or "solid"
    -- Old named profiles may still carry the retired Etched style.
    -- Render it identically to Solid without altering saved profile data.
    if style == "etched" then style = "solid" end
    local r = math.min(1, color[1]*brightness)
    local g = math.min(1, color[2]*brightness)
    local b = math.min(1, color[3]*brightness)
    for _, line in ipairs(button.frameLines) do
        line:SetColorTexture(r,g,b,alpha)
        if line.horizontal then line:SetHeight(width) else line:SetWidth(width) end
        line:SetShown(style ~= "none")
    end
    for _, line in ipairs(button.innerLines) do
        line:SetColorTexture(r,g,b,alpha * (style == "etched" and 0.33 or 0.8))
        line:SetShown(style == "double" or style == "etched")
    end
    local db = MixolasBarsDB or DEFAULTS
    local refined = (lightStyle or db.illuminationStyle) ~= "classic"
    local sat = refined and (db.glowSaturation or 0.86) or 1
    local gray = r*0.2126 + g*0.7152 + b*0.0722
    local hr,hg,hb = gray+(r-gray)*sat, gray+(g-gray)*sat, gray+(b-gray)*sat
    local spread = refined and (db.glowSpread or 2) or 3
    for index, halo in ipairs(button.frameGlow) do
        halo:ClearAllPoints()
        if index == 1 then
            halo:SetPoint("TOPLEFT",button,"TOPLEFT",-spread,spread)
            halo:SetPoint("TOPRIGHT",button,"TOPRIGHT",spread,spread)
            halo:SetHeight(refined and (spread+2) or 5)
        elseif index == 2 then
            halo:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",-spread,-spread)
            halo:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",spread,-spread)
            halo:SetHeight(refined and (spread+2) or 5)
        elseif index == 3 then
            halo:SetPoint("TOPLEFT",button,"TOPLEFT",-spread,spread)
            halo:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",-spread,-spread)
            halo:SetWidth(refined and (spread+2) or 5)
        else
            halo:SetPoint("TOPRIGHT",button,"TOPRIGHT",spread,spread)
            halo:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",spread,-spread)
            halo:SetWidth(refined and (spread+2) or 5)
        end
        halo:SetColorTexture(hr,hg,hb,glow * alpha * (refined and 0.26 or 1))
        halo:SetShown(style ~= "none" and glow > 0)
    end
end

local function createBorder(button)
    button.frameLines = {}
    button.frameGlow = {}
    button.innerLines = {}
    for index = 1,4 do
        local line = button:CreateTexture(nil,"OVERLAY")
        local halo = button:CreateTexture(nil,"BACKGROUND")
        local inner = button:CreateTexture(nil,"OVERLAY")
        if index == 1 then
            line:SetPoint("TOPLEFT",button,"TOPLEFT",0,0)
            line:SetPoint("TOPRIGHT",button,"TOPRIGHT",0,0)
            line.horizontal = true
            line:SetHeight(2)
            halo:SetPoint("TOPLEFT",button,"TOPLEFT",-3,3)
            halo:SetPoint("TOPRIGHT",button,"TOPRIGHT",3,3)
            halo:SetHeight(5)
            inner:SetPoint("TOPLEFT",button,"TOPLEFT",4,-4)
            inner:SetPoint("TOPRIGHT",button,"TOPRIGHT",-4,-4)
            inner:SetHeight(1)
        elseif index == 2 then
            line:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",0,0)
            line:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
            line.horizontal = true
            line:SetHeight(2)
            halo:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",-3,-3)
            halo:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",3,-3)
            halo:SetHeight(5)
            inner:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",4,4)
            inner:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-4,4)
            inner:SetHeight(1)
        elseif index == 3 then
            line:SetPoint("TOPLEFT",button,"TOPLEFT",0,0)
            line:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",0,0)
            line.horizontal=false
            line:SetWidth(2)
            halo:SetPoint("TOPLEFT",button,"TOPLEFT",-3,3)
            halo:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",-3,-3)
            halo:SetWidth(5)
            inner:SetPoint("TOPLEFT",button,"TOPLEFT",4,-4)
            inner:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",4,4)
            inner:SetWidth(1)
        else
            line:SetPoint("TOPRIGHT",button,"TOPRIGHT",0,0)
            line:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",0,0)
            line.horizontal=false
            line:SetWidth(2)
            halo:SetPoint("TOPRIGHT",button,"TOPRIGHT",3,3)
            halo:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",3,-3)
            halo:SetWidth(5)
            inner:SetPoint("TOPRIGHT",button,"TOPRIGHT",-4,-4)
            inner:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-4,4)
            inner:SetWidth(1)
        end
        table.insert(button.frameLines,line)
        table.insert(button.frameGlow,halo)
        table.insert(button.innerLines,inner)
    end
end

-- The legacy low-resolution Trail animation has been retired. There are no
-- extra strip sprites allocated and old profile values are migrated to Static.

local function getActionIcon(slot)
    -- Modern WoW Forever has C_ActionBar; older API fallback remains useful.
    if C_ActionBar and C_ActionBar.GetActionTexture then
        local ok, texture = pcall(C_ActionBar.GetActionTexture, slot)
        if ok and texture then return texture end
    end
    if GetActionTexture then
        local ok, texture = pcall(GetActionTexture, slot)
        if ok then return texture end
    end
    return nil
end

local function getCustomIcon(data)
    if not data then return nil end
    if data.kind == "spell" then
        if C_Spell and C_Spell.GetSpellTexture then
            local ok, tex = pcall(C_Spell.GetSpellTexture, data.value)
            if ok and tex then return tex end
        end
        if GetSpellTexture then
            local ok, tex = pcall(GetSpellTexture, data.value)
            if ok then return tex end
        end
    elseif data.kind == "item" then
        if C_Item and C_Item.GetItemIconByID then
            local ok, tex = pcall(C_Item.GetItemIconByID, data.value)
            if ok and tex then return tex end
        end
        if GetItemIcon then
            local ok, tex = pcall(GetItemIcon, data.value)
            if ok then return tex end
        end
    elseif data.kind == "macro" and GetMacroInfo then
        local ok, _, tex = pcall(GetMacroInfo, data.value)
        if ok then return tex end
    end
    return nil
end

-- WoW reports a carried spell/item/macro/native action via GetCursorInfo().
-- The temporary reveal is *not* a saved setting and never enables disabled bars.
-- Protected button visibility is changed only outside combat lockdown.
local function hasPlaceableCursor()
    if not GetCursorInfo then return false end
    -- A targeted spell is a cast cursor, not an action being arranged.
    -- Never reveal the entire bar while a player is casting/targeting.
    if SpellIsTargeting and SpellIsTargeting() then return false end
    local kind=GetCursorInfo()
    return kind=="spell" or kind=="item" or kind=="macro" or kind=="action"
end
local cursorRevealActive=false
-- Only a temporary UI reveal; never mutate Show Empty in SavedVariables.
local bindingSlotRevealActive=false
local pendingHiddenSlotRelease=nil  -- keep revealed destinations alive through late cursor frames
-- Incremented by the NORMAL drop handlers. The mouse-release fallback must
-- never place a second action if WoW already delivered OnReceiveDrag/PreClick.
local cursorPlacementSerial=0
local lastNativeDropButton,lastNativeDropTime=nil,-100
local function noteCursorPlacement(button)
    cursorPlacementSerial=cursorPlacementSerial+1
    lastNativeDropButton=button
    lastNativeDropTime=GetTime and GetTime() or -100
end
local function updateDiamondSlotVisibility()
    if not MixolasBarsDB or inLockdown() then return false end
    local db=MixolasBarsDB
    for i,cluster in ipairs(clusters) do
        for j,button in ipairs(cluster.buttons) do
            local slot=button:GetAttribute("action") or button.actionSlot
            local filled=compat.ActionHas and compat.ActionHas(slot)
            if filled==nil and HasAction then filled=HasAction(slot) end
            if filled==nil and GetActionInfo then filled=GetActionInfo(slot)~=nil end
            local enabled=db.visible and db.diamondEnabled[i]~=false and j<=(db.counts[i] or 4)
            local showEmpty=not db.diamondShowEmpty or db.diamondShowEmpty[i]~=false
            button:SetShown(enabled and (showEmpty or not db.locked or cursorRevealActive or bindingSlotRevealActive or filled==true))
        end
    end
    return true
end

local function refreshIcons()
    if not MixolasBarsDB then return end
    for _, cluster in ipairs(clusters) do
        for _, button in ipairs(cluster.buttons) do
            local texture
            texture = getActionIcon(button:GetAttribute("action") or button.actionSlot)
            -- A different action can have the SAME icon. Fingerprint its kind/ID
            -- instead of waiting for the texture to change. Reset ALL presentation
            -- layers together; no stale item stacks, cooldowns or pressed masks.
            local action=button:GetAttribute("action") or button.actionSlot
            local kind,id=GetActionInfo and GetActionInfo(action)
            local signature=tostring(action)..":"..tostring(kind)..":"..tostring(id)..":"..tostring(texture)
            if button._mixolasLastActionSignature ~= signature then
                button._mixolasLastActionSignature = signature
                button._mxbNativeCooldown=false
                button._mxbNativeStart,button._mxbNativeDuration=nil,nil
                button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
                if button.countText then button.countText:SetText("") end
                if button.cooldownNumber then button.cooldownNumber:SetText("") end
                button._mxbLastCooldownNumber=nil -- invalidate label cache when action actually changes
                if button.cooldown then button.cooldown:Hide() end
                if button.mxbGCD then button.mxbGCD:Hide() end
                if button.pressedShade then button.pressedShade:Hide() end
            end
            if button.macroText then
                local name=MixolasBarsDB.showMacroNames and compat.ActionMacroName and compat.ActionMacroName(action)
                button.macroText:SetText(name or "")
            end
            if texture then
                button.icon:SetTexture(texture)
                button.icon:Show()
                if button.base then button.base:Show() end
            else
                button.icon:Hide()
                if button.base then button.base:Hide() end
            end
        end
    end
    -- An action may have been added/removed without any layout setting changing.
    -- In combat this defers automatically until PLAYER_REGEN_ENABLED.
    updateDiamondSlotVisibility()
end

-- Official Classic Era/Hardcore supplies native cooldown duration objects.
-- Unlike Forever, repeatedly assigning one every 0.15 seconds can restart
-- the swipe.  Refresh native widgets on actual action/cooldown events, not
-- from the background inventory/range polling loop.
local isOfficialClassicEra = WOW_PROJECT_CLASSIC ~= nil and WOW_PROJECT_ID == WOW_PROJECT_CLASSIC
local function readableCooldownNumber(v)
    if type(v) ~= "number" then return nil end
    if issecretvalue then
        local ok, secret = pcall(issecretvalue, v)
        if not ok or secret then return nil end
    end
    return v
end
local safeCooldown
local function setCustomAction(button, info)
    if inLockdown() or not button.isCustom then return false end
    local entry = info and {kind = info.kind, value = info.value} or nil
    local db = MixolasBarsDB
    db.customActions[tostring(button.slot)] = entry
    if entry then
        button:SetAttribute("type", entry.kind)
        button:SetAttribute(entry.kind, entry.value)
    else
        button:SetAttribute("type", nil)
        button:SetAttribute("spell", nil)
        button:SetAttribute("item", nil)
        button:SetAttribute("macro", nil)
    end
    refreshIcons()
    return true
end

-- Native Classic bindings are distinct from Mixolas override bindings.
-- Report both to the user: native keys will still activate their Blizzard
-- action slots if our overlay does not explicitly mask them.
local function nativeBindingCommand(button)
    local slot=button and button.actionSlot
    if not slot then return nil end
    if button.barNumber==1 then return "ACTIONBUTTON"..button.barIndex end
    if slot>=61 and slot<=72 then return "MULTIACTIONBAR1BUTTON"..(slot-60) end
    if slot>=49 and slot<=60 then return "MULTIACTIONBAR2BUTTON"..(slot-48) end
    if slot>=25 and slot<=36 then return "MULTIACTIONBAR3BUTTON"..(slot-24) end
    if slot>=37 and slot<=48 then return "MULTIACTIONBAR4BUTTON"..(slot-36) end
    return nil
end
local function nativeBindingKeys(button)
    if not GetBindingKey then return {} end
    local command=nativeBindingCommand(button)
    if not command then return {} end
    local keys={GetBindingKey(command)}
    return keys
end
local function abbreviatedKey(key)
    if not key or key == "" then return "" end
    -- Compact labels without hyphens, e.g. SHIFT-CTRL-1 -> SC1.
    return key:gsub("SHIFT%-", "S"):gsub("CTRL%-", "C"):gsub("ALT%-", "A")
        :gsub("MOUSEWHEELUP", "MWU"):gsub("MOUSEWHEELDOWN", "MWD")
        :gsub("BUTTON", "M"):gsub("%-", "")
end

-- Display the EFFECTIVE key, not every historical Blizzard binding.
-- If Mixolas overrides a native WoW key onto another slot, its original
-- action-bar button must NOT retain a ghost hotkey label.
local function reservedRegularBinding(id)
    local numeric=tonumber(id)
    if not numeric or numeric<33 or numeric>128 then return false end
    local bar=math.floor((numeric-33)/12)+1
    return bar==3 or bar==4 or bar==5
end
local function claimedMixolasKeys(map)
    local owners={}
    for id,keys in pairs(map or {}) do
        -- Hidden regular Bars 3/4/5 duplicate the diamond action slots.
        -- Legacy entries must not steal keys from the actual visible bars.
        if not reservedRegularBinding(id) and type(keys)=="table" then
            for _,key in ipairs(keys) do
                if type(key)=="string" and key~="" then owners[key]=tostring(id) end
            end
        end
    end
    return owners
end
local function buttonKey(button,map,blocked,owners)
    local id=tostring(button.bindId or button.slot)
    local own=map and map[id]
    if type(own)=="table" and type(own[1])=="string" then return own[1],"Mixolas" end
    for _,key in ipairs(nativeBindingKeys(button)) do
        if key and not (blocked and blocked[key])
            and (not owners[key] or owners[key]==id) then
            return key,"WoW"
        end
    end
    return nil,nil
end
local function refreshHotkeys(previewBindings, blockedNative)
    if not MixolasBarsDB then return end
    local map=previewBindings or MixolasBarsDB.bindings or {}
    local owners=claimedMixolasKeys(map)
    local function update(button)
        local key=buttonKey(button,map,blockedNative,owners)
        if button.hotkeyText then
            button.hotkeyText:SetText(MixolasBarsDB.showHotkeys and abbreviatedKey(key) or "")
            button.hotkeyText:SetWidth(math.max(8,button:GetWidth()-4))
            button.hotkeyText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",MixolasBarsDB.hotkeyFontSize or 8,"OUTLINE")
        end
        -- Same setting for both native diamond buttons and Mixolas regular bars.
        if button.countText then
            button.countText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",MixolasBarsDB.itemCountFontSize or 8,"OUTLINE")
        end
    end
    for _,cluster in ipairs(clusters) do for _,button in ipairs(cluster.buttons) do update(button) end end
    for _,button in ipairs(regularButtons) do update(button) end
end
local function cleanSavedBindingCollisions()
    -- Sanitize old save data without ever silently removing a valid second or
    -- third shortcut. Preserve a backup before resolving cross-button duplicates.
    local map=MixolasBarsDB and MixolasBarsDB.bindings or {}
    local seen,removed={},0
    local backupNeeded=false
    for id=1,128 do
        local keys=map[tostring(id)]
        if type(keys)=="table" then
            for _,key in ipairs(keys) do
                if type(key)~="string" or key=="" or seen[key] or _>3 then backupNeeded=true end
                if type(key)=="string" and key~="" then seen[key]=true end
            end
        end
    end
    if backupNeeded and characterDB and not characterDB.legacyMultiKeyBindingsBackup then
        characterDB.legacyMultiKeyBindingsBackup={}
        for id,keys in pairs(map) do
            if type(keys)=="table" then
                characterDB.legacyMultiKeyBindingsBackup[id]={unpack(keys)}
            end
        end
    end
    seen={}
    for id=1,128 do
        local keys=map[tostring(id)]
        if type(keys)=="table" then
            local clean={}
            for _,key in ipairs(keys) do
                if type(key)=="string" and key~="" and not seen[key] and #clean<3 then
                    clean[#clean+1]=key
                    seen[key]=true
                else
                    removed=removed+1
                end
            end
            map[tostring(id)]=#clean>0 and clean or nil
        end
    end
    return removed
end

-- Saved bindings are addon-owned overrides: no predefined keys and no changes
-- to the game's binding file. Restore them every login/reload, outside combat.
-- Keybind-only secure proxies separate keyboard activation from mouse drag.
-- The visible button remains click-on-release to prevent accidental casts
-- when picking up an icon. A shown, transparent secure proxy follows the
-- player's keyboard-down/up preference and owns no interactive screen area.
local function createKeyProxy(button)
    if button.keyProxy then return button.keyProxy end
    local name=button:GetName() .. "KeyProxy"
    local proxy=CreateFrame("Button",name,UIParent,"SecureActionButtonTemplate")
    proxy:SetSize(1,1)
    proxy:SetPoint("TOPLEFT",UIParent,"TOPLEFT",-20,-20)
    proxy:SetAlpha(0)
    proxy:RegisterForClicks("AnyDown","AnyUp")
    local useDown = GetCVarBool and GetCVarBool("ActionButtonUseKeyDown")
    if useDown == nil and GetCVar then useDown = GetCVar("ActionButtonUseKeyDown") ~= "0" end
    proxy:SetAttribute("useOnKeyDown", useDown ~= false)
    -- The controller binding executes on this invisible secure button.
    -- Forward its click phase to the visible button for visual feedback only.
    -- No casting, action attributes, or state drivers are touched here.
    proxy:SetScript("PreClick",function(_,mouseButton,isDown)
        if feedback.Press then feedback.Press(button,isDown) end
    end)
    if button.isCustom then
        local entry=MixolasBarsDB and MixolasBarsDB.customActions
          and MixolasBarsDB.customActions[tostring(button.slot)]
        proxy:SetAttribute("type",entry and entry.kind or nil)
        if entry then proxy:SetAttribute(entry.kind,entry.value) end
    else
        proxy:SetAttribute("type","action")
        proxy:SetAttribute("action",button:GetAttribute("action") or button.actionSlot)
    end
    button.keyProxy=proxy
    return proxy
end

-- Hidden Blizzard bars retain their normal bindings. That is harmless: a
-- priority override is the supported way to redirect a key to a Mixolas
-- secure button. Do not indiscriminately wipe WoW's binding file.
local function expectedClickCommand(name)
    return "CLICK "..name..":LeftButton"
end
local function sameRoute(effective,name)
    if type(effective)~="string" then return false end
    return effective:upper()==expectedClickCommand(name):upper()
end
-- Unlike IsShown, IsVisible respects hidden parent frames. That matters
-- for our reserved full-length bars, whose child buttons can be "shown" even
-- though the parent is never displayed.
local function visibleActionButton(button)
    if not button or reservedRegularBinding(button.bindId) then return false end
    if button.IsVisible then
        local ok,visible=pcall(button.IsVisible,button)
        if ok and visible~=nil then return not not visible end
    end
    if not button:IsShown() then return false end
    local parent=button:GetParent()
    while parent do
        if parent.IsShown and not parent:IsShown() then return false end
        parent=parent.GetParent and parent:GetParent() or nil
    end
    return true
end
local function applyBindings()
    if applyingBindings or inLockdown() or not MixolasBarsDB then return false end
    if not ClearOverrideBindings or not SetOverrideBindingClick then return false end
    local report={attempted=0,errors={},mismatches={},routes={}}
    applyingBindings=true
    local success,err=pcall(ClearOverrideBindings,bindingOwner)
    if not success then
        report.errors[#report.errors+1]="ClearOverrideBindings: "..tostring(err)
        bindingReport=report
        applyingBindings=false
        return false
    end
    if not MixolasBarsDB.visible then
        bindingReport=report
        applyingBindings=false
        refreshHotkeys()
        return true
    end
    -- Priority routing is explicit, unique and deterministic. Assign Mixolas
    -- custom keys first, then optionally bridge client-side Blizzard keybinds
    -- for Bar 2 and Diamonds 1-8, with Bar 1 always inherited as before.
    -- Never invoke SetBinding/SaveBindings: the player's real WoW keybinding
    -- configuration belongs entirely to the WoW client.
    local assignedOwners=claimedMixolasKeys(MixolasBarsDB.bindings)
    local claimed={}
    local function route(key,button,source)
        if type(key)~="string" or key=="" or not button or claimed[key] then return end
        local proxy=button.keyProxy or button
        local name=proxy.GetName and proxy:GetName()
        if not name then
            report.errors[#report.errors+1]=key.." (missing named secure button)"
            return
        end
        local ok,result=pcall(SetOverrideBindingClick,bindingOwner,true,key,name,"LeftButton")
        if not ok or result==false then
            report.errors[#report.errors+1]=key..": "..tostring(ok and "rejected" or result)
            return
        end
        claimed[key]=true
        report.attempted=report.attempted+1
        report.routes[key]={button=name,source=source,
            native=(GetBindingAction and GetBindingAction(key)) or ""}
    end
    for i=1,TOTAL_DIAMONDS do
        if MixolasBarsDB.diamondEnabled[i]~=false then
            for j=1,math.min(4,MixolasBarsDB.counts[i] or 4) do
                local button=clusters[i] and clusters[i].buttons[j]
                local keys=MixolasBarsDB.bindings[tostring((i-1)*4+j)]
                if button and type(keys)=="table" then
                    for _,key in ipairs(keys) do route(key,button,"custom") end
                end
            end
        end
    end
    for _,button in ipairs(regularButtons) do
        if visibleActionButton(button) then
            local keys=MixolasBarsDB.bindings[tostring(button.bindId)]
            if type(keys)=="table" then
                for _,key in ipairs(keys) do route(key,button,"custom") end
            end
        end
    end
    if MixolasBarsDB.hideBlizzard and GetBindingKey then
        local function routeNative(button, source)
            if not visibleActionButton(button) or not nativeBindingCommand(button) then return end
            for _,key in ipairs(nativeBindingKeys(button)) do
                -- Native inheritance is a FALLBACK; custom Mixolas keys win
                -- even if the Blizzard client gives the same key to a bar.
                if not assignedOwners[key] then route(key,button,source) end
            end
        end
        -- Preserve the existing Bar 1 behavior even when the optional bridge
        -- is disabled for troubleshooting or custom arrangements.
        for _,button in ipairs(regularButtons) do
            if button.barNumber == 1 then routeNative(button, "native-bar1") end
        end
        -- Client bindings for Action Bars 2-5 should work without requiring a
        -- second round of bindings inside Mixolas. Duplicate hidden regular
        -- Bars 3-5 are deliberately NEVER routed: those slots belong to the
        -- six visible diamond clusters, not the invisible mirror bars.
        if MixolasBarsDB.nativeBindingInheritance ~= false then
            for _,button in ipairs(regularButtons) do
                if button.barNumber == 2 then routeNative(button, "native-bar2") end
            end
            for i=1,TOTAL_DIAMONDS do
                if MixolasBarsDB.diamondEnabled[i]~=false then
                    for j=1,math.min(4,MixolasBarsDB.counts[i] or 4) do
                        local button=clusters[i] and clusters[i].buttons[j]
                        if button then routeNative(button,"native-diamond-"..i) end
                    end
                end
            end
        end
    end
    -- Verify the live route. The old code reported success whenever the API
    -- call returned, even if a different override was actually effective.
    if GetBindingAction then
        for key,routeInfo in pairs(report.routes) do
            local ok,effective=pcall(GetBindingAction,key,true)
            if ok then
                routeInfo.effective=effective
                if type(effective)=="string" and effective~=""
                    and not sameRoute(effective,routeInfo.button) then
                    report.mismatches[#report.mismatches+1]=key
                    routeInfo.conflict=effective
                end
            end
        end
    end
    bindingReport=report
    applyingBindings=false
    refreshHotkeys()
    return #report.errors==0 and #report.mismatches==0
end

-- /mxbnative on|off|status - toggle bridge without changing any WoW binding.
-- Run outside combat so secure override routing can be updated safely.
SLASH_MIXOLASBARSNATIVE1 = "/mxbnative"
SlashCmdList.MIXOLASBARSNATIVE = function(input)
    local choice = (type(input)=="string" and input:match("^%s*(%S+)") or "") or ""
    choice = choice:lower()
    if choice == "on" or choice == "off" then
        if not MixolasBarsDB or inLockdown() then
            say("Native binding bridge can only change outside combat.")
            return
        end
        MixolasBarsDB.nativeBindingInheritance = (choice == "on")
        applyBindings()
    elseif choice ~= "" and choice ~= "status" then
        say("Use /mxbnative on, off, or status.")
        return
    end
    if not MixolasBarsDB then
        say("Native binding bridge: addon not initialized.")
        return
    end
    local enabled = MixolasBarsDB.nativeBindingInheritance ~= false
    local n = 0
    for _,r in pairs(bindingReport.routes or {}) do
        if r.source and r.source:match("^native%-") then n=n+1 end
    end
    say("WoW-client keybind bridge "..(enabled and "ON" or "OFF")..
        "; "..n.." native keys currently routed while Blizzard bars are hidden."..
        " Custom Mixolas shortcuts always take priority.")
end

local positions = {
    {0, 1},  -- top
    {-1, 0}, -- left
    {1, 0},  -- right
    {0, -1}, -- bottom
}

-- Alpha-only combat transitions: do not show/hide buttons, redraw spell
-- slots, mutate secure attributes, or update binding routing during combat.
local function diamondOpacity(db,index,inCombat)
    local base=tonumber(db.alphas and db.alphas[index]) or 1
    if inCombat and db.combatAlphas then
        base=tonumber(db.combatAlphas[index]) or base
    end
    return math.max(0.1,math.min(1,base))
end
local function refreshDiamondCombatOpacity(forceInCombat)
    local db=MixolasBarsDB
    if not db then return false end
    local combat=forceInCombat
    if combat==nil then combat=inLockdown() end
    for i,cluster in ipairs(clusters) do
        for _,button in ipairs(cluster.buttons or {}) do
            pcall(button.SetAlpha,button,diamondOpacity(db,i,combat))
        end
    end
    return true
end
local function refreshLayout()
    if inLockdown() then
        say("Layout changes are disabled during combat.")
        return
    end
    local db = MixolasBarsDB
    local gapEW = math.max(0,math.min(24,tonumber(db.diamondGapEW) or tonumber(db.gap) or 3))
    local gapNS = math.max(0,math.min(24,tonumber(db.diamondGapNS) or tonumber(db.gap) or 3))
    local step = db.buttonSize + gapNS
    -- East and west buttons share a single row.  Their centers must be
    -- one button-width + gap apart in total, not on either side of a
    -- full button-width step.  At gap=0 their edges touch exactly.
    local horizontalHalfStep = (db.buttonSize + gapEW) / 2
    for i, cluster in ipairs(clusters) do
        cluster:SetSize(2 * db.buttonSize + gapEW, 3 * db.buttonSize + 2 * gapNS)
        cluster:SetScale(db.scales[i] or 1)
        cluster:ClearAllPoints()
        cluster:SetPoint("CENTER", UIParent, "CENTER", db.positions[i][1], db.positions[i][2])
        -- Unlocked clusters remain movable even if they have zero visible buttons.
        cluster:SetShown((db.visible and db.diamondEnabled[i] ~= false) or (db.visible and not db.locked))
        cluster.dragHandle:SetShown(false) -- interior edit mask handles dragging and labeling
        if cluster.editMask then
            cluster.editMask:SetShown(not db.locked and db.visible)
            local col=db.colors[i]
            cluster.editMask.tint:SetColorTexture(col[1],col[2],col[3],0.27)
        end
        for j, button in ipairs(cluster.buttons) do
            button:SetSize(db.buttonSize, db.buttonSize)
            button:ClearAllPoints()
            button:SetPoint("CENTER", cluster, "CENTER",
                positions[j][1] * horizontalHalfStep, positions[j][2] * step)
            button:SetAlpha(diamondOpacity(db,i,inLockdown()))
            -- Visibility is determined by count AND actual action occupancy.
            -- Keep the slot accessible when the layout is unlocked for editing.
            setBorderColor(button, db.colors[i], (db.diamondGlows and db.diamondGlows[i]) or db.glow, db.borderAlpha, db.borderWidth, db.brightness[i], db.borderStyles[i], db.diamondIlluminationStyles and db.diamondIlluminationStyles[i])
            if button.trailLines then
                for _,edge in ipairs(button.trailLines) do
                    edge:Hide() -- retired the blocky, per-button Trail animation
                end
            end
        end
    end
    updateDiamondSlotVisibility()
    applyBindings()
end

-- Reactive abilities must dim before their triggering event (dodge, parry,
-- enemy HP threshold, etc.), even if the player is not currently in combat.
-- The spell names come from the client's spell database, not from action-slot
-- numbers, so all learned ranks get the same conditional treatment.
local REACTIVE_NAMES={
    ["Overpower"]=true, ["Mongoose Bite"]=true, ["Revenge"]=true,
    ["Riposte"]=true, ["Counterattack"]=true, ["Execute"]=true,
    ["Victory Rush"]=true,
}
local function getActionSpellID(button,action)
    if button.isCustom then
        local info=MixolasBarsDB and MixolasBarsDB.customActions
            and MixolasBarsDB.customActions[tostring(button.slot)]
        if info and info.kind=="spell" then return info.value end
        if info and info.kind=="macro" and GetMacroSpell then
            local ok,name,id=pcall(GetMacroSpell,info.value)
            if ok then return id or name end
        end
    elseif GetActionInfo and action then
        local kind,id=GetActionInfo(action)
        if kind=="spell" then return id end
        if kind=="macro" and GetMacroSpell then
            local ok,name,spell=pcall(GetMacroSpell,id)
            if ok then return spell or name end
        end
    end
end
-- Reliable known melee probes are preferable to a fabricated distance:
-- Classic does not expose a general target distance API. Each entry is a
-- learned baseline melee spell whose 5yd range can be checked, if available.
local MELEE_RANGE_PROBES={
    ["Mongoose Bite"]="Wing Clip", ["Raptor Strike"]="Wing Clip",
    ["Overpower"]="Hamstring", ["Revenge"]="Hamstring",
    ["Execute"]="Hamstring", ["Victory Rush"]="Hamstring",
    ["Riposte"]="Sinister Strike", ["Counterattack"]="Wing Clip",
}
local function definitiveOutOfRange(v)
    if v == 0 or v == "0" or v == false then return true end
    if v == 1 or v == "1" or v == true then return false end
    return nil
end
local function spellNameForAction(button,action)
    local id=getActionSpellID(button,action)
    if not id then return nil end
    if type(id)=="string" then return id end
    return compat.SpellName and compat.SpellName(id) or nil
end
local function checkMeleeFallback(button,action)
    local probe=MELEE_RANGE_PROBES[spellNameForAction(button,action)]
    if not probe or not compat.SpellRange then return nil end
    return compat.SpellRange(probe)
end

local function isReactiveAction(button,action)
    local spellID=getActionSpellID(button,action)
    if not spellID then return false end
    local name=compat.SpellName and compat.SpellName(spellID)
    return name and REACTIVE_NAMES[name] or false
end

-- Availability has THREE separate causes: reactive trigger, range, and combat usability.
-- A nil range result means 'unknown' and must never be treated as out of range.
-- No target => do not range-dim; combat-unusable actions still dim in combat.
-- Keep frame borders, hotkeys, and cooldown text full strength.
local function updateButtonRange(button)
    if not button or not button.icon or not button.icon:IsShown() then return end
    local db=MixolasBarsDB
    if not db then return end
    local action=(not button.isCustom) and (button:GetAttribute("action") or button.actionSlot)
    local info=button.isCustom and db.customActions and db.customActions[tostring(button.slot)]
    local spellID=getActionSpellID(button,action)
    local name=spellID and compat.SpellName and compat.SpellName(spellID)
    local reactive=name and REACTIVE_NAMES[name]
    local usable, noMana, known=nil,false,false

    -- Bartender/LibActionButton pattern: obtain *current* native usability
    -- every time ACTIONBAR_UPDATE_USABLE (or the refresh ticker) fires.
    -- Forever uses C_ActionBar/C_Spell, not the old Classic globals.
    if button.isCustom then
        if info and info.kind=="spell" and compat.SpellUsable then
            usable,noMana,known=compat.SpellUsable(info.value)
        elseif info and info.kind=="item" and compat.ItemUsable then
            usable,noMana,known=compat.ItemUsable(info.value)
        end
    elseif action and compat.ActionUsable then
        usable,noMana,known=compat.ActionUsable(action)
    end

    -- Verify reactive spell usability directly as well. Some action APIs
    -- report macro usability differently from the underlying proc spell.
    -- A missing API result is UNKNOWN, not permission to invent a proc.
    if reactive and spellID and compat.SpellUsable then
        local spellUsable,spellLacks,spellKnown=compat.SpellUsable(spellID)
        if spellKnown and (not known or spellUsable == false) then
            usable,noMana,known=spellUsable,spellLacks,true
        end
    end

    local outOfRange=false
    if UnitExists and UnitExists("target")
        and UnitCanAttack and UnitCanAttack("player","target") then
        local range
        if action and compat.ActionRange then range=compat.ActionRange(action) end
        if range==nil and spellID and compat.SpellRange then range=compat.SpellRange(spellID) end
        -- Melee probe is only a fallback when the client can't range-check.
        if range==nil then range=checkMeleeFallback(button,action) end
        outOfRange=definitiveOutOfRange(range)==true
    end

    -- Keep usability independent from cooldown/pressed state. Never bleach
    -- reactive actions just because no enemy is targeted or we're out of combat.
    if outOfRange then
        local v=db.rangeDim or 0.55
        button.icon:SetVertexColor(v,v,v)
    elseif known and usable==false then
        local v=db.combatDim or 0.39
        if noMana==true then
            button.icon:SetVertexColor(math.max(v,0.45),math.max(v,0.55),0.90)
        else
            button.icon:SetVertexColor(v,v,v)
        end
    else
        -- Unknown results must not be described as confirmed usable. Do not
        -- force gray on every action when beta API data is unavailable.
        button.icon:SetVertexColor(1,1,1)
    end
end

-- The primary swipe uses the same native duration objects as Bartender4.
-- Unlike manually matching GCD spell 61304, the client's per-action duration
-- already accounts for the GCD, haste, macros, charge use, and longer personal
-- cooldowns. It remains renderable when start/duration numbers are secret.
local function macroSpellID(macroIndex)
    if not GetMacroSpell or not macroIndex then return nil end
    local ok,a,b=pcall(GetMacroSpell,macroIndex)
    if not ok then return nil end
    if type(a)=="number" then return a end
    if type(b)=="number" then return b end
    if type(a)=="string" then return a end
    return nil
end

local function applyNativeDuration(button, action, info, db)
    local cooldown=button.cooldown
    if not cooldown or not cooldown.SetCooldownFromDurationObject then return false end
    local duration
    local ignoreGCD=db.gcdSweep==false
    if button.isCustom then
        if info and info.kind=="spell" and compat.SpellCooldownDuration then
            duration=compat.SpellCooldownDuration(info.value,ignoreGCD)
        elseif info and info.kind=="macro" and compat.SpellCooldownDuration then
            duration=compat.SpellCooldownDuration(macroSpellID(info.value),ignoreGCD)
        end
    elseif action and compat.ActionCooldownDuration then
        duration=compat.ActionCooldownDuration(action,ignoreGCD)
    end
    if not duration then return false end
    -- The widget interprets the duration itself, including secret time fields.
    -- clearIfZero clears expired/idle swipes without reading the duration.
    local ok=pcall(cooldown.SetCooldownFromDurationObject,cooldown,duration,true)
    if not ok then return false end
    button._mxbNativeCooldown=true
    if cooldown.SetMinimumCountdownDuration then
        cooldown:SetMinimumCountdownDuration(2000) -- milliseconds: skip GCD-length numbers
    end
    if cooldown.SetHideCountdownNumbers then
        cooldown:SetHideCountdownNumbers(button._mxbShowNativeCountdown ~= true)
    end
    -- The button's own dark radial mask is intentionally stronger than the
    -- optional GCD shading: it starts dim and reveals icons clockwise.
    if cooldown.SetSwipeColor then cooldown:SetSwipeColor(0,0,0,0.82) end
    -- A numeric zero is handled before entering this helper. For opaque
    -- duration objects, preserve the client's own clearIfZero state.
    if button.mxbGCD then button.mxbGCD:Hide() end
    -- Numeric text is maintained independently below. Clearing it here
    -- would erase the label whenever the native duration object updates.
    return true
end

-- Native Cooldown widgets show their own countdown when Classic hides timing
-- values as secret. When readable timestamps are available, this explicit
-- foreground label is more reliable at small diamond icon sizes. It only
-- reads cooldown data; never touches a secure action attribute or the swipe.
local function clearCooldownLabel(button)
    if button.cooldownNumber then button.cooldownNumber:SetText("") end
    -- The next valid value must redraw, even if its rounded numeral is the
    -- same as the one cleared during a spell swap or transient cooldown reset.
    button._mxbLastCooldownNumber=nil
end
local function updateDiamondCooldownNumber(button, start, duration, enabled)
    if not button.cooldownNumber then return end
    local numeric = start ~= nil and duration ~= nil
    local showNative = not numeric
    if button._mxbShowNativeCountdown ~= showNative then
        if button.cooldown.SetHideCountdownNumbers then
            button.cooldown:SetHideCountdownNumbers(not showNative)
        end
        if button.cooldown.SetMinimumCountdownDuration then
            button.cooldown:SetMinimumCountdownDuration(2000) -- milliseconds: omit the short GCD
        end
        button._mxbShowNativeCountdown = showNative
    end
    local label = ""
    if numeric and (enabled == nil or enabled ~= 0 and enabled ~= false)
        and duration >= 2 and start > 0 then
        local remaining = start + duration - GetTime()
        if remaining > 0 then
            if remaining >= 3600 then
                label = tostring(math.ceil(remaining / 3600)) .. "h"
            elseif remaining >= 60 then
                label = tostring(math.ceil(remaining / 60)) .. "m"
            else
                label = tostring(math.ceil(remaining))
            end
        end
    end
    -- Avoid reallocating/repainting an unchanged FontString every 0.15 sec.
    if button._mxbLastCooldownNumber ~= label then
        button.cooldownNumber:SetText(label)
        button._mxbLastCooldownNumber = label
    end
end

safeCooldown = function(button, forceNativeUpdate)
    local db=MixolasBarsDB
    if not button or not button.cooldown or not db then return end
    local start,duration,enabled,count
    local info,action
    if button.isCustom then
        info=db.customActions and db.customActions[tostring(button.slot)]
        if info and info.kind=="spell" and compat.SpellCooldown then
            start,duration,enabled=compat.SpellCooldown(info.value)
        elseif info and info.kind=="item" and compat.ItemCooldown then
            start,duration,enabled=compat.ItemCooldown(info.value)
        elseif info and info.kind=="macro" and compat.SpellCooldown then
            start,duration,enabled=compat.SpellCooldown(macroSpellID(info.value))
        end
        if info and info.kind=="item" and compat.ItemCount then
            count=compat.ItemCount(info.value)
        end
    else
        action=button:GetAttribute("action") or button.actionSlot
        if compat.ActionCooldown then start,duration,enabled=compat.ActionCooldown(action) end
        if compat.ActionCount then count=compat.ActionCount(action) end
    end
    if button.countText then
        -- Counts always update, even when the client's cooldown times are secret.
        if type(count)=="number" and (not issecretvalue or not issecretvalue(count)) and count>1 then
            button.countText:SetText(tostring(count))
        else
            button.countText:SetText("")
        end
    end
    if button.isCustom and not info then
        button._mxbNativeCooldown=false
        button.cooldown:Hide()
        if button.mxbGCD then button.mxbGCD:Hide() end
        clearCooldownLabel(button)
        return
    end
    -- Detect native action cooldown transitions even when the client misses an
    -- event. This is independent of whether the action has a keybinding.
    -- The native widget animates on its own: only assign a duration object when
    -- the readable start/duration pair changes, or an event forces a refresh.
    -- Never inspect secret numbers during combat.
    local knownStart = readableCooldownNumber(start)
    local knownDuration = readableCooldownNumber(duration)
    -- Refresh the visible number even when the same native Cooldown widget
    -- remains active. The clockwise radial sweep must NOT be restarted.
    -- Unknown/secret 'enabled' is never compared in Lua.  Older client
    -- builds may supply a readable boolean rather than a numeric flag.
    local knownEnabled = readableCooldownNumber(enabled)
    if type(enabled) == "boolean" then
        local readable = true
        if issecretvalue then
            local ok, secret = pcall(issecretvalue, enabled)
            readable = ok and not secret
        end
        if readable then knownEnabled = enabled end
    end
    updateDiamondCooldownNumber(button, knownStart, knownDuration, knownEnabled)
    if isOfficialClassicEra and button._mxbNativeCooldown and not forceNativeUpdate then
        if knownStart == nil or knownDuration == nil then
            -- The event-driven handler updates opaque/secret duration objects.
            return
        end
        if button._mxbNativeStart == knownStart
                and button._mxbNativeDuration == knownDuration then
            return
        end
    end
    -- A previously active action may now have no cooldown. Clear a stale swipe
    -- only if the client has returned definitively readable zero times.
    if knownStart == 0 and knownDuration == 0 then
        button.cooldown:Hide()
        button._mxbNativeCooldown=false
        button._mxbNativeStart,button._mxbNativeDuration=nil,nil
        button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
        clearCooldownLabel(button)
        return
    end
    -- Avoid replaying identical native durations on redundant events.
    local sameNative = isOfficialClassicEra and button._mxbNativeCooldown
        and knownStart and knownDuration
        and button._mxbNativeStart == knownStart
        and button._mxbNativeDuration == knownDuration
    if sameNative then return end
    if applyNativeDuration(button,action,info,db) then
        if isOfficialClassicEra then
            button._mxbNativeStart = knownStart
            button._mxbNativeDuration = knownDuration
        end
        button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
        return
    end
    button._mxbNativeCooldown=false
    button._mxbNativeStart,button._mxbNativeDuration=nil,nil
    -- Classic / older beta fallback. Secret numeric fields must never reach
    -- SetCooldown or any Lua comparison; preserve counts and clear stale swipes.
    if issecretvalue then
        if issecretvalue(start) or issecretvalue(duration) or issecretvalue(enabled) then
            button.cooldown:Hide()
            clearCooldownLabel(button)
            return
        end
    end
    if type(start)=="number" and type(duration)=="number" and duration>1.5
            and start+duration>GetTime() and enabled~=0 and enabled~=false then
        -- The numeric fallback also runs on the periodic refresh. Applying
        -- the same start/duration repeatedly flickers on Classic clients.
        if button._mxbLegacyStart ~= start or button._mxbLegacyDuration ~= duration then
            button.cooldown:SetCooldown(start,duration)
            button._mxbLegacyStart,button._mxbLegacyDuration=start,duration
        end
        button.cooldown:Show()
        -- The independent foreground label already contains the countdown.
    else
        button.cooldown:Hide()
        button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
        clearCooldownLabel(button)
    end
end

-- Cursor handling: native action-slot buttons use Blizzard's own PickupAction /
-- PlaceAction swap behavior; independent buttons store secure spell/item/macro
-- attributes and can be dragged off the button. Both pathways are no-combat.
local function cursorToEntry()
    if not GetCursorInfo then return nil end
    local kind, a, b, c = GetCursorInfo()
    if kind == "spell" then
        -- Classic cursor returns (spellbookIndex, bookType, spellID).
        -- Classic 1.15.9 can use a different spellbook cursor signature.
        -- Use the shared version-aware resolver, never guess a spell rank.
        local spellID = compat.CursorSpellID and compat.CursorSpellID(a,b,c) or c
        if spellID then return {kind = "spell", value = spellID} end
    elseif kind == "item" and a then
        return {kind = "item", value = a}
    elseif kind == "macro" and a then
        return {kind = "macro", value = a}
    elseif kind == "action" and a and GetActionInfo then
        local actionKind, id = GetActionInfo(a)
        if (actionKind == "spell" or actionKind == "item" or actionKind == "macro") and id then
            return {kind = actionKind, value = id}
        end
    end
    return nil
end

local function pickupStoredAction(info)
    if not info then return false end
    if info.kind == "spell" and PickupSpell then
        return pcall(PickupSpell, info.value)
    elseif info.kind == "item" and PickupItem then
        return pcall(PickupItem, info.value)
    elseif info.kind == "macro" and PickupMacro then
        return pcall(PickupMacro, info.value)
    end
    return false
end

-- Mouse drag/drop is NOT a separate mode. The action button temporarily
-- suspends casting for the lifetime of a physical drag or item-on-cursor drop.
-- Do not restore on the next OnUpdate after the drag STARTS: that restores
-- casting while the mouse is still held and can cast on drag release.
local function suppressActionForDrag(button)
    if inLockdown() then return end
    button._mixolasSuppressClick=true
    if feedback.Reset then feedback.Reset(button) end
    button:SetAttribute("type",nil)
end
local function finishActionDrag(button)
    if inLockdown() or not button._mixolasSuppressClick or button._mixolasRestoreQueued then return end
    button._mixolasRestoreQueued=true
    -- Defer until AFTER secure mouse-up/drag delivery on this interaction.
    button:SetScript("OnUpdate",function(self)
        -- A drag/drop can finish on mouse-down. Never rearm the secure
        -- action while the left button is still held: mouse-up would cast.
        if IsMouseButtonDown and IsMouseButtonDown("LeftButton") then return end
        self:SetScript("OnUpdate",nil)
        self._mixolasRestoreQueued=nil
        if not inLockdown() then self:SetAttribute("type","action") end
        if self.pressedShade then self.pressedShade:Hide() end
        self._mixolasSuppressClick=false
        self._mixolasDropHandled=false
    end)
end

local function receiveCursor(button)
    if inLockdown() or not GetCursorInfo or not GetCursorInfo() then return false end
    if MixolasBarsDB and not MixolasBarsDB.locked then return false end
    suppressActionForDrag(button)
    if button._mixolasDropHandled then return true end
    button._mixolasDropHandled = true
    noteCursorPlacement(button)
    local dest = button:GetAttribute("action") or button.actionSlot
    local source = activeDragSource
    if PlaceAction and dest then
        PlaceAction(dest)
        -- Classic returns the displaced action to the cursor. Preserve it.
        -- The player can move it to a different slot with the next mouse click.
        -- Never auto-return it to its source slot.
    end
    activeDragSource = nil
    refreshIcons()
    for _,c in ipairs(clusters) do
        for _,b in ipairs(c.buttons) do if b.cooldown then safeCooldown(b) end end
    end
    if _G.MixolasBarsAPI.RefreshRegularActionIcons then _G.MixolasBarsAPI.RefreshRegularActionIcons() end
    if C_Timer and C_Timer.After then
        C_Timer.After(0,function()
            if not initialized then return end
            refreshIcons()
            for _,c in ipairs(clusters) do for _,b in ipairs(c.buttons) do safeCooldown(b) end end
            if _G.MixolasBarsAPI.RefreshRegularActionIcons then _G.MixolasBarsAPI.RefreshRegularActionIcons() end
        end)
    end
    finishActionDrag(button)
    return true
end

local function pickupButtonAction(button)
    if inLockdown() or not MixolasBarsDB or not MixolasBarsDB.locked then return end
    -- The mouse has actually moved far enough to start a drag. Never cast
    -- when it is subsequently released, even if button contents are locked.
    suppressActionForDrag(button)
    if MixolasBarsDB.buttonLock then return end
    if GetCursorInfo and GetCursorInfo() then return end
    -- Reveal destinations before PickupAction clears the source action slot.
    -- Otherwise an auto-hidden source can vanish before WoW routes its drop.
    if _G.MixolasBarsAPI.BeginActionDrag then _G.MixolasBarsAPI.BeginActionDrag(button) end
    local slot = button:GetAttribute("action") or button.actionSlot
    if HasAction and not HasAction(slot) then return end
    if PickupAction then
        activeDragSource = slot
        PickupAction(slot)
        refreshIcons()
        if button.countText then button.countText:SetText("") end
        if button.cooldownNumber then button.cooldownNumber:SetText("") end
        button._mxbLastCooldownNumber=nil
        if button.cooldown then button.cooldown:Hide() end
        if button.mxbGCD then button.mxbGCD:Hide() end
        if button.pressedShade then button.pressedShade:Hide() end
    end
end

local ticker = CreateFrame("Frame")
local tickerElapsed = 0
ticker:SetScript("OnUpdate", function(_, dt)
    if not initialized or not MixolasBarsDB or not MixolasBarsDB.visible then return end
    tickerElapsed = tickerElapsed + dt
    if tickerElapsed < 0.15 then return end
    tickerElapsed = 0
    -- Detect changes even if Classic misses an action-slot event for a cursor
    -- swap. All three layers (icon/count/cooldown) refresh coherently.
    refreshIcons()
    for _, cluster in ipairs(clusters) do
        for _, button in ipairs(cluster.buttons) do
            if button:IsShown() then
                safeCooldown(button);updateButtonRange(button)

            end
        end
    end
    -- Perimeter highlights run in a separate smooth animation update.
    for _, b in ipairs(regularButtons) do
        if b:IsShown() and b.cooldown then
            safeCooldown(b);updateButtonRange(b)

        end
    end
end)

-- Animation is visual-only and never changes secure button attributes.
-- Lightweight Pulse/Hum only; Trail sprites have been removed.
local animator=CreateFrame("Frame")
local motionElapsed=0
animator:SetScript("OnUpdate",function(_,dt)
    if not initialized or not MixolasBarsDB or not MixolasBarsDB.visible then return end
    motionElapsed=motionElapsed+dt
    if motionElapsed<0.08 then return end
    motionElapsed=0
    local t=GetTime()
    for i,cluster in ipairs(clusters) do
        local mode=(MixolasBarsDB.glowMotions and MixolasBarsDB.glowMotions[i]) or "static"
        if mode=="trail" then mode="static" end -- legacy saved profiles
        if mode~="static" then
            local shade=MixolasBarsDB.colors[i]
            if mode=="pulse" or mode=="hum" then
                local power=mode=="pulse" and (0.55+0.45*math.sin(t*3)^2) or (0.70+0.30*math.sin(t*1.4))
                for _,button in ipairs(cluster.buttons) do
                    local individual=(MixolasBarsDB.diamondGlows and MixolasBarsDB.diamondGlows[i]) or MixolasBarsDB.glow
                    setBorderColor(button,shade,individual*power,MixolasBarsDB.borderAlpha,
                        MixolasBarsDB.borderWidth,MixolasBarsDB.brightness[i],MixolasBarsDB.borderStyles[i],
                        MixolasBarsDB.diamondIlluminationStyles and MixolasBarsDB.diamondIlluminationStyles[i])
                end
            end
        end
    end
end)

local function createCluster(index)
    local cluster = CreateFrame("Frame", "MixolasBarsCluster" .. index, UIParent)
    cluster:SetFrameStrata("MEDIUM")
    cluster:SetMovable(true)
    -- Match regular bars: native frame clamping fights DragController's
    -- UIParent-scale-aware positioning and blocks bottom/screen-edge reach.
    -- The shared drag controller owns edge docking for BOTH bar types.
    cluster:SetClampedToScreen(false)
    cluster._mixolasEdgeFree = true
    cluster.buttons = {}

    -- Each button uses Blizzard's secure action dispatch.  In v0.1 these
    -- 12 slots mirror the existing first action bar, rather than replacing it.
    for j = 1, 4 do
        local slot = (index - 1) * 4 + j
        local button = CreateFrame("Button", "MixolasBarsAction" .. slot, cluster, "SecureActionButtonTemplate")
        button.slot = slot -- stable logical binding id 1..32
        button.actionSlot = diamondSlot(index, j) -- unique native WoW action slot
        button.isCustom = false
        button.isDiamond = true
        button.diamondIndex = index
        button.diamondButtonIndex = j
        button:SetAttribute("type", "action")
        button:SetAttribute("action", button.actionSlot)
        -- Register BOTH press/release so mouse and overrides follow the client's
        -- ActionButtonUseKeyDown preference rather than becoming inert.
        local keyDown = (GetCVarBool and GetCVarBool("ActionButtonUseKeyDown"))
        if keyDown == nil and GetCVar then keyDown = GetCVar("ActionButtonUseKeyDown") ~= "0" end
        -- Up-only mouse clicks prevent a drag's initial mouse-down from casting.
        -- Explicit key-up activation keeps Click overrides aligned with that
        -- registration until we can verify a secure keydown/mouse-up split.
        button:SetAttribute("useOnKeyDown",false)
        button:RegisterForClicks("AnyDown","AnyUp")
        button:RegisterForDrag("LeftButton")
        -- Native action-slot swaps: dragging or carrying a cursor spell cannot cast.
        button:SetScript("OnReceiveDrag", receiveCursor)
        button:SetScript("OnDragStart", pickupButtonAction)
        button:SetScript("OnDragStop", finishActionDrag)
        -- Ordinary click never picks a spell up. Drags use OnDragStart.
        button:SetScript("PreClick", function(self, which, isDown)
            if not inLockdown() and GetCursorInfo and GetCursorInfo() then
                receiveCursor(self)
            elseif self._mixolasSuppressClick and not inLockdown() then
                self:SetAttribute("type", nil)
            end
            if feedback.Press then feedback.Press(self,isDown) end
        end)
        button:SetScript("PostClick", function(self, which, isDown)
            if not inLockdown() and self._mixolasSuppressClick then
                self:SetAttribute("type", nil)
                finishActionDrag(self)
            end
            -- Release/fade is owned by PressFeedback, not an immediate hide.
        end)
        local base = button:CreateTexture(nil, "BACKGROUND")
        base:SetAllPoints()
        base:SetColorTexture(0.07, 0.10, 0.14, 0.80)
        button.base = base
        local press = button:CreateTexture(nil,"OVERLAY")
        press:SetAllPoints(button)
        press:SetColorTexture(0.02,0.03,0.05,0.50)
        press:Hide()
        button.pressedShade = press
        button:SetScript("OnMouseUp", function(self)
            if feedback.Press then feedback.Press(self,false) end
            finishActionDrag(self)
        end)
        button:SetScript("OnMouseDown", function(self)
            if feedback.Press then feedback.Press(self,true) end
        end)

        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetPoint("TOPLEFT", 3, -3)
        button.icon:SetPoint("BOTTOMRIGHT", -3, 3)
        button.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

        button.hotkeyText = button:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        button.hotkeyText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 8, "OUTLINE")
        button.hotkeyText:SetPoint("TOPRIGHT", button, "TOPRIGHT", -2, -2)
        button.hotkeyText:SetWidth(34)
        button.hotkeyText:SetJustifyH("RIGHT")
        button.hotkeyText:SetShadowOffset(1, -1)
        button.hotkeyText:SetShadowColor(0, 0, 0, 1)
        button.hotkeyText:SetText("")
        button.hotkeyText:SetTextColor(1, 1, 1, 0.95)

        createBorder(button)
        -- Legacy Trail sprites retired; no new per-button strip textures.
        button.cooldown = CreateFrame("Cooldown", nil, button, "CooldownFrameTemplate")
        button.cooldown:SetAllPoints(button.icon)
        -- Cooldown art stays INSIDE the existing spell icon; never enlarge or
        -- re-space the diamond. A dark clockwise sector retreats over the
        -- duration, gradually revealing the ability with a moving edge.
        if button.cooldown.SetDrawSwipe then button.cooldown:SetDrawSwipe(true) end
        if button.cooldown.SetReverse then button.cooldown:SetReverse(false) end
        if button.cooldown.SetSwipeColor then button.cooldown:SetSwipeColor(0, 0, 0, 0.82) end
        if button.cooldown.SetDrawEdge then button.cooldown:SetDrawEdge(true) end
        if button.cooldown.SetEdgeColor then button.cooldown:SetEdgeColor(1, 0.88, 0.65, 0.94) end
        if button.cooldown.SetEdgeScale then button.cooldown:SetEdgeScale(0.84) end
        if button.cooldown.SetDrawBling then button.cooldown:SetDrawBling(false) end
        if button.cooldown.SetHideCountdownNumbers then button.cooldown:SetHideCountdownNumbers(true) end
        button.cooldownNumber = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
        button.cooldownNumber:SetPoint("CENTER", button, "CENTER", 0, 0)
        button.cooldownNumber:SetText("")
        -- Blizzard's NumberFontNormal provides the native game numeral face.
        -- Do not override it with the standard body text font.
        button.cooldownNumber:SetTextColor(1, 1, 1, 1)
        button.cooldownNumber:SetShadowColor(0, 0, 0, 1)
        button.cooldownNumber:SetShadowOffset(1, -1)
        -- Put the numeral above Warlord textures and the cooldown overlay.
        local numberLayer=CreateFrame("Frame",nil,button)
        numberLayer:SetAllPoints(button)
        numberLayer:SetFrameLevel(button.cooldown:GetFrameLevel()+3)
        button.cooldownNumber:SetParent(numberLayer)
        button._mxbCooldownLabelLayer=numberLayer
        button.countText = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
        button.countText:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 2)
        button.countText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 8, "OUTLINE")
        button.countText:SetText("")
        button.macroText=button:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        button.macroText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",7,"OUTLINE")
        button.macroText:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",3,3)
        button.macroText:SetWidth(24)
        button.macroText:SetJustifyH("LEFT")
        if button.macroText.SetWordWrap then button.macroText:SetWordWrap(false) end
        if button.macroText.SetMaxLines then button.macroText:SetMaxLines(1) end
        button.macroText:SetShadowOffset(1,-1)
        button.macroText:SetShadowColor(0,0,0,1)
        button.macroText:SetText("")
        button:SetScript("OnEnter", function(self)
            if GameTooltip then
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                if GameTooltip.SetAction then
                    GameTooltip:SetAction(self.actionSlot)
                else
                    GameTooltip:AddLine("Action slot " .. self.actionSlot)
                end
                GameTooltip:Show()
            end
        end)
        button:SetScript("OnLeave", function()
            if GameTooltip then GameTooltip:Hide() end
        end)

        createKeyProxy(button)
        cluster.buttons[j] = button
    end

    local handle = CreateFrame("Button", nil, cluster)
    handle:SetSize(166, 20)
    handle:SetPoint("BOTTOM", cluster, "TOP", 0, 9)
    handle:SetMovable(false)
    handle:RegisterForDrag("LeftButton")
    local text = handle:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    text:SetAllPoints()
    text:SetText("DIAMOND " .. index .. "  (BAR " .. DIAMOND_BAR[index] .. ")")
    text:SetTextColor(1, 1, 1)
    local shade = handle:CreateTexture(nil, "BACKGROUND")
    shade:SetAllPoints()
    shade:SetColorTexture(0.15, 0.19, 0.23, 0.88)

    -- Legacy top-edge handle is deliberately retired; all editing takes place
    -- directly on the tinted mask, with a centered label inside the diamond.
    handle:Hide()
    cluster.dragHandle = handle
    local mask=CreateFrame("Button",nil,cluster)
    mask:SetAllPoints(cluster)
    mask:SetFrameLevel(cluster:GetFrameLevel()+30)
    mask:RegisterForDrag("LeftButton")
    mask:EnableMouse(true)
    local tint=mask:CreateTexture(nil,"BACKGROUND")
    tint:SetAllPoints(mask)
    tint:SetColorTexture(0.3,0.6,1,0.22)
    mask.tint=tint
    local caption=mask:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    caption:SetPoint("CENTER",mask,"CENTER",0,0)
    caption:SetWidth(118)
    caption:SetJustifyH("CENTER")
    caption:SetText("DIAMOND "..index.."\nBAR "..DIAMOND_BAR[index])
    caption:SetTextColor(1,1,1,1)
    caption:SetShadowColor(0,0,0,1)
    caption:SetShadowOffset(1,-1)
    mask.caption=caption
    mask:SetScript("OnDragStart",function()
        if _G.MixolasBarsAPI.BeginLayoutDrag then
            local p=MixolasBarsDB.positions[index]
            cluster._mixolasDragData={x=p[1],y=p[2]}
            _G.MixolasBarsAPI.BeginLayoutDrag(cluster,cluster._mixolasDragData)
        end
    end)
    mask:SetScript("OnDragStop",function()
        if _G.MixolasBarsAPI.EndDiamondDrag then _G.MixolasBarsAPI.EndDiamondDrag(cluster,index) end
    end)
    mask:Hide()
    cluster.editMask=mask
    return cluster
end

local function clamp(value, minValue, maxValue)
    return math.max(minValue, math.min(maxValue, value))
end

-- Stable, small API used by the graphical settings panel.
-- No addon logic here depends on the panel existing or being open.
_G.MixolasBarsAPI = {
    -- Fresh profiles must use FACTORY defaults, never the layout of the
    -- currently selected profile. Return an isolated copy, not DEFAULTS itself.
    GetDefaultVisualLayout = function()
        local fresh={}
        copyDefaults(fresh,DEFAULTS)
        return fresh
    end,
    GetDB = function() return MixolasBarsDB end,
    GetCharacterDB = function() return characterDB end,
    SetCharacterBindings = function(map)
        if not initialized or inLockdown() or type(map) ~= "table" then return false end
        -- The overlay layout is account-wide, but bindings are character-specific.
        -- Retain the active root alias for legacy code reading MixolasBarsDB.bindings.
        characterDB = characterDB or {}
        -- Each physical button can own up to three custom shortcuts.
        -- A key can have only one Mixolas owner across the entire UI.
        local normalized,used={},{}
        for slot=1,128 do
            local keys=map[tostring(slot)]
            if type(keys)=="table" then
                local chosen={}
                for _,key in ipairs(keys) do
                    if type(key)=="string" and key~="" and not used[key] and #chosen<3 then
                        chosen[#chosen+1]=key
                        used[key]=true
                    end
                end
                if #chosen>0 then normalized[tostring(slot)]=chosen end
            end
        end
        characterDB.bindings = normalized
        MixolasBarsCharacterDB = characterDB
        MixolasBarsDB.bindings = normalized
        return true
    end,
    EndDiamondDrag = function(cluster,index)
        if _G.MixolasBarsAPI.EndLayoutDrag then
            _G.MixolasBarsAPI.EndLayoutDrag(cluster)
            local d=cluster._mixolasDragData
            if d then
                MixolasBarsDB.positions[index]={d.x,d.y}
                -- DragController's working table is temporary for diamonds.
                -- Persist the *actual* position after committing it to the DB;
                -- otherwise the character profile captures the prior location.
                if _G.MixolasBarsAPI.MarkVisualLayoutDirty then
                    _G.MixolasBarsAPI.MarkVisualLayoutDirty()
                end
            end
            cluster._mixolasDragData=nil
        end
    end,
    GetClusters = function() return clusters end,
    GetDiamondBar = function(i) return DIAMOND_BAR[i] end,
    GetDiamondActionSlot = diamondSlot,
    -- Compatibility accessors retained for older plugins, but no special
    -- spell editing mode is required: mouse movement is always non-casting.
    IsSpellEditMode = function() return false end,
    SetSpellEditMode = function() return false end,
    GetRegularButtons = function() return regularButtons end,
    IsPlacementCursorActive = function() return cursorRevealActive end,
    IsBindingSlotRevealActive = function() return bindingSlotRevealActive end,
    SetBindingSlotRevealActive = function(active)
        -- Combat can start while the editor is open. Clear the in-memory
        -- reveal on forced close even in combat; defer protected Show/Hide
        -- calls until PLAYER_REGEN_ENABLED refreshes both bar families.
        if active and inLockdown() then return false end
        bindingSlotRevealActive=not not active
        if inLockdown() then return false end
        updateDiamondSlotVisibility()
        if _G.MixolasBarsAPI.RefreshRegularEmptyVisibility then
            _G.MixolasBarsAPI.RefreshRegularEmptyVisibility()
        end
        return true
    end,
    GetPageState = currentPageState,
    GetPageStateForClass = pageStateForClass,
    RecordDragSource = function(slot) activeDragSource=slot end,
    BeginActionDrag = function(button)
        -- Called by BOTH action-button families while the drag is still held.
        -- The reveal is temporary: never mutate the saved Show Empty preference.
        if inLockdown() or not initialized or not MixolasBarsDB or not MixolasBarsDB.locked then return end
        activeActionDrag=button
        if not cursorRevealActive then
            cursorRevealActive=true
            updateDiamondSlotVisibility()
            if _G.MixolasBarsAPI.RefreshRegularEmptyVisibility then
                _G.MixolasBarsAPI.RefreshRegularEmptyVisibility()
            end
        end
    end,
    ReadDragSource = function() return activeDragSource end,
    ClearDragSource = function() activeDragSource=nil end,
    NoteCursorPlacement = noteCursorPlacement,
    AddRegularButton = function(button) regularButtons[#regularButtons+1] = button end,
    RefreshIcons = refreshIcons,
    RefreshHotkeyLabels = refreshHotkeys,
    -- Explicit calls are tied to cooldown/action events or action edits.
    -- They may update the underlying duration object; the background ticker
    -- calls safeCooldown directly WITHOUT forcing a native restart.
    RefreshCooldown = function(button) safeCooldown(button,true) end,
    RefreshRange = updateButtonRange,
    UpdateNativeAction = function(button) if button and button.icon then button.icon:SetTexture(getActionIcon(button:GetAttribute("action") or button.actionSlot)); button.icon:SetShown(button.icon:GetTexture() ~= nil) end end,
    MakeBorder = createBorder,
    TintBorder = setBorderColor,
    AbbreviateKey = abbreviatedKey,
    MakeBindingProxy = createKeyProxy,
    GetNativeBindingCommand = nativeBindingCommand,
    GetNativeBindingKeys = nativeBindingKeys,
    GetEffectiveButtonKey = function(button)
        if not button then return nil,nil end
        return buttonKey(button, MixolasBarsDB and MixolasBarsDB.bindings or {}, nil,
            claimedMixolasKeys(MixolasBarsDB and MixolasBarsDB.bindings or {}))
    end,
    ValidateActionOwnership = function()
        local occupied, collisions={},{}
        local count=0
        local function inspect(button,label)
            if not button or not button.IsShown or not button:IsShown() then return end
            local slot=button.GetAttribute and button:GetAttribute("action") or button.actionSlot
            if not button.isCustom and slot then
                count=count+1
                if occupied[slot] then
                    collisions[#collisions+1]=tostring(slot).." ("..occupied[slot].." + "..label..")"
                else occupied[slot]=label end
            end
        end
        for i,cluster in ipairs(clusters) do
            for _,b in ipairs(cluster.buttons) do inspect(b,"Diamond "..i) end
        end
        for _,b in ipairs(regularButtons) do inspect(b,"Bar "..tostring(b.barNumber)) end
        local notes={
            "VISIBLE NATIVE BUTTONS: "..count,
            "DUPLICATE VISIBLE NATIVE SLOTS: "..#collisions,
        }
        for _,v in ipairs(collisions) do notes[#notes+1]="CONFLICT: "..v end
        -- Classic action-page 2 (13-24) may be selected by Bar 1's pager.
        -- The old Bar 6 uses 13-24; it is not independent from Bar 1 page 2.
        local db=MixolasBarsDB
        if db and db.regularBars and db.regularBars[6] and db.regularBars[6].enabled then
            notes[#notes+1]="WARNING: BAR 6 uses native slots 13-24, also Bar 1 page 2."
            notes[#notes+1]="Avoid using Bar 6 during paging until it is migrated to independent actions."
        end
        return table.concat(notes,"\n"),#collisions
    end,
    GetBindingRouteReport = function() return bindingReport end,
    AuditKeyRouting = function(key)
        if not key or not MixolasBarsDB then return "No key captured." end
        local owner, target, matches = nil,nil,0
        for id,keys in pairs(MixolasBarsDB.bindings or {}) do
            if not reservedRegularBinding(id) and type(keys)=="table" then
                for _,saved in ipairs(keys) do
                    if saved==key then
                        matches=matches+1
                        owner=tonumber(id)
                    end
                end
            end
        end
        if owner then
            for _,cluster in ipairs(clusters) do
                for _,button in ipairs(cluster.buttons) do
                    if button.bindId==owner or button.slot==owner then target=button end
                end
            end
            for _,button in ipairs(regularButtons) do
                if button.bindId==owner then target=button end
            end
        end
        local native=GetBindingAction and GetBindingAction(key) or ""
        local route=bindingReport.routes and bindingReport.routes[key]
        local effective=GetBindingAction and GetBindingAction(key,true) or ""
        local visible=target and visibleActionButton(target) or false
        local proxy=target and (target.keyProxy or target)
        local actionSlot=target and (target.GetAttribute and target:GetAttribute("action") or target.actionSlot)
        local lines={
            "CAPTURED: "..key,
            "SAVED MIXOLAS OWNER: "..(owner and tostring(owner) or "none"),
            "DUPLICATES: "..tostring(matches),
            "MIXOLAS BUTTON: "..(target and target:GetName() or "none"),
            "BUTTON VISIBLE: "..(visible and "yes" or "no"),
            "ACTION SLOT: "..tostring(actionSlot or "n/a"),
            "SECURE PROXY: "..(proxy and proxy:GetName() or "none"),
            "PROXY TYPE: "..tostring(proxy and proxy:GetAttribute("type") or "none"),
            "NATIVE WoW COMMAND: "..((native and native~="") and native or "none"),
            "CLIENT OVERRIDE: "..((effective and effective~="") and effective or "none reported"),
            "MIXOLAS ROUTE: "..(route and route.button or "not applied"),
            "ROUTE SOURCE: "..(route and route.source or "none"),
            "ROUTE VERIFIED: "..(route and (route.conflict and ("NO: "..route.conflict) or
                ((effective and effective~="") and (sameRoute(effective,route.button) and "YES" or "NO") or "client did not report")) or "NO"),
        }
        if owner and not target then lines[#lines+1]="WARNING: saved binding refers to no existing button." end
        if owner and target and not visible then lines[#lines+1]="WARNING: owner is not currently visible." end
        if matches>1 then lines[#lines+1]="WARNING: key is assigned more than once in saved Mixolas data." end
        if native~="" and route and sameRoute(effective,route.button) then
            lines[#lines+1]="Native Blizzard binding is correctly overridden; it is not blocking Mixolas."
        end
        return table.concat(lines,"\n")
    end,
    GetNativeBindingCommand = nativeBindingCommand,
    ApplyBindings = applyBindings,
    IsReady = function() return initialized end,
    IsInCombat = inLockdown,
    Refresh = refreshLayout,
    Say = say,
    Change = function(key, value)
        if not initialized or inLockdown() then return false end
        local db = MixolasBarsDB
        if key == "buttonSize" then
            db.buttonSize = clamp(math.floor(value + 0.5), 16, 72)
        elseif key == "gap" then
            db.gap = clamp(math.floor(value + 0.5), 0, 24)
        elseif key == "glow" then
            db.glow = clamp(value, 0, 1)
            db.diamondGlows = {} -- General glow intentionally applies to all diamonds
        elseif key == "illuminationStyle" then
            if value ~= "refined" and value ~= "classic" then return false end
            db.illuminationStyle = value
        elseif key == "glowSpread" then
            db.glowSpread = clamp(math.floor(value + 0.5), 1, 6)
        elseif key == "glowSaturation" then
            db.glowSaturation = clamp(value, 0, 1)
        elseif key == "borderAlpha" then
            db.borderAlpha = clamp(value, 0.15, 1)
        elseif key == "borderWidth" then
            db.borderWidth = clamp(math.floor(value + 0.5), 1, 6)
        elseif key == "gcdDarkness" then
            db.gcdDarkness = clamp(value, 0.1, 0.8)
            if _G.MixolasBarsAPI.UpdateGCD then _G.MixolasBarsAPI.UpdateGCD() end
        elseif key == "minimapSize" then
            db.minimapSize = clamp(math.floor(value + 0.5),20,56)
            if _G.MixolasBarsAPI.UpdateMinimapIcon then _G.MixolasBarsAPI.UpdateMinimapIcon() end
        elseif key == "hotkeyFontSize" then
            db.hotkeyFontSize = clamp(math.floor(value + 0.5), 6, 12)
        elseif key == "itemCountFontSize" then
            db.itemCountFontSize = clamp(math.floor(value + 0.5), 6, 18)
        elseif key == "rangeDim" then
            db.rangeDim = clamp(value, 0.2, 1)
        elseif key == "combatDim" then
            db.combatDim = clamp(value, 0.2, 1)
        elseif key == "locked" or key == "visible" or key == "showHotkeys" or key == "showMacroNames" or key == "buttonLock" or key == "snapEnabled" or key == "gcdSweep" then
            db[key] = not not value
        else
            return false
        end
        if key == "gcdSweep" or key == "gcdDarkness" then
            for _,cluster in ipairs(clusters) do
                for _,button in ipairs(cluster.buttons) do safeCooldown(button) end
            end
            for _,button in ipairs(regularButtons) do safeCooldown(button) end
            if _G.MixolasBarsAPI.UpdateGCD then _G.MixolasBarsAPI.UpdateGCD() end
        end
        if key == "snapEnabled" and _G.MixolasBarsAPI.RefreshLayoutGuides then
            _G.MixolasBarsAPI.RefreshLayoutGuides()
        end
        if key == "locked" then
            for _, cluster in ipairs(clusters) do
                cluster.dragHandle:SetShown(false) -- interior edit mask handles dragging and labeling
                if cluster.editMask then cluster.editMask:SetShown(not db.locked and db.visible) end
            end
            if _G.MixolasBarsAPI.RefreshRegularHandles then _G.MixolasBarsAPI.RefreshRegularHandles() end
            if _G.MixolasBarsAPI.RefreshUtilityHandles then _G.MixolasBarsAPI.RefreshUtilityHandles() end
            if _G.MixolasBarsAPI.RefreshDecorHandles then _G.MixolasBarsAPI.RefreshDecorHandles() end
            -- Empty slots are editable while unlocked, hidden again when locked.
            updateDiamondSlotVisibility()
            applyBindings()
        else
            refreshLayout()
            if key == "visible" then
                if _G.MixolasBarsAPI.RefreshRegularBars then _G.MixolasBarsAPI.RefreshRegularBars() end
                if _G.MixolasBarsAPI.RefreshUtilityBars then _G.MixolasBarsAPI.RefreshUtilityBars() end
            end
        end
        if key == "hotkeyFontSize" or key == "itemCountFontSize" or key == "showHotkeys" then refreshHotkeys() end
        if key == "showMacroNames" then
            refreshIcons()
            if _G.MixolasBarsAPI.RefreshRegularActionIcons then _G.MixolasBarsAPI.RefreshRegularActionIcons() end
        end
        if key == "rangeDim" or key == "combatDim" or key == "snapEnabled" then
            for _,c in ipairs(clusters) do for _,b in ipairs(c.buttons) do updateButtonRange(b) end end
            for _,b in ipairs(regularButtons) do updateButtonRange(b) end
        end
        return true
    end,
    SetDiamondEnabled = function(index, enabled)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        MixolasBarsDB.diamondEnabled[index]=not not enabled
        refreshLayout()
        return true
    end,
    ChangeColor = function(index, red, green, blue)
        if not initialized or inLockdown() or not MixolasBarsDB then return false end
        if index < 1 or index > TOTAL_DIAMONDS then return false end
        MixolasBarsDB.colors[index] = {clamp(red, 0, 1), clamp(green, 0, 1), clamp(blue, 0, 1)}
        refreshLayout()
        return true
    end,
    -- Fail-safe reset of the full visual state.  Never claim success after a
    -- subsystem returns false or throws; restore the saved configuration.
    ResetPositions = function()
        if not initialized or inLockdown() then return false end
        local a=_G.MixolasBarsAPI
        local db=MixolasBarsDB
        local function clone(v,depth)
            if type(v)~="table" then return v end
            if (depth or 0)>24 then return nil end
            local out={}
            for key,value in pairs(v) do out[key]=clone(value,(depth or 0)+1) end
            return out
        end
        local previous={}
        for _,key in ipairs({"positions","regularBars","utilityBars","decorFrames",
            "frameStudio","windowPositions","minimapAngle"}) do
            previous[key]=clone(db[key])
        end
        local function redraw()
            local actions={"Refresh","RefreshRegularBars","RefreshUtilityBars",
                "ReloadDecorFromConfig","RefreshFrameStudio","RefreshRegularHandles",
                "RefreshUtilityHandles","RefreshDecorHandles","UpdateMinimapIcon"}
            for _,name in ipairs(actions) do
                local fn=a[name]
                if type(fn)=="function" then
                    local ok, result=pcall(fn)
                    if not ok or result==false then
                        return false,name..": "..tostring(result)
                    end
                end
            end
            if a.UpdateSettingsUI then pcall(a.UpdateSettingsUI) end
            return true
        end
        if a.TakeLayoutSnapshot then a.TakeLayoutSnapshot("Before Reset Positions") end
        for i=1,TOTAL_DIAMONDS do
            db.positions[i]={DEFAULTS.positions[i][1],DEFAULTS.positions[i][2]}
        end
        local bars=a.GetDefaultRegularBarLayout and a.GetDefaultRegularBarLayout()
        if not bars then say("Cannot reset positions: regular bar defaults are unavailable.");return false end
        db.regularBars=db.regularBars or {}
        for i,c in pairs(db.regularBars) do
            local original=bars[i]
            if type(c)=="table" and type(original)=="table" then
                c.x,c.y=original.x,original.y
                c.positionInitialized=true
            end
        end
        local util=a.GetDefaultUtilityBarLayout and a.GetDefaultUtilityBarLayout()
        if not util then say("Cannot reset positions: pet bar defaults are unavailable.");return false end
        db.utilityBars=db.utilityBars or {}
        for id,c in pairs(db.utilityBars) do
            if type(c)=="table" and util[id] then c.x,c.y=util[id].x,util[id].y end
        end
        for i,c in ipairs(db.decorFrames or {}) do
            if type(c)=="table" and not c.deleted then
                c.x,c.y=((i-1)%4)*30,70
            end
        end
        for _,c in pairs(db.frameStudio or {}) do
            if type(c)=="table" then c.x,c.y=0,0 end
        end
        db.minimapAngle=DEFAULTS.minimapAngle
        -- Live window repositioning must accompany clearing their stored XY.
        local ok,why=redraw()
        if ok and a.ResetWindowPositions then
            local success,result=pcall(a.ResetWindowPositions)
            if not success or result==false then ok=false;why="ResetWindowPositions: "..tostring(result) end
        elseif ok then
            db.windowPositions={}
        end
        if not ok then
            for key,value in pairs(previous) do db[key]=value end
            for key in pairs(previous) do
                -- Handle absent original optional fields as well.
                if previous[key]==nil then db[key]=nil end
            end
            pcall(redraw)
            say("Reset Positions failed; original layout restored: "..tostring(why))
            return false
        end
        if a.MarkVisualLayoutDirty then a.MarkVisualLayoutDirty() end
        say("All Mixolas positions restored to their default anchors.")
        return true
    end,
    Reset = function()
        if not initialized or inLockdown() then return false end
        local a=_G.MixolasBarsAPI
        local db=MixolasBarsDB
        local function clone(v,depth)
            if type(v)~="table" then return v end
            if (depth or 0)>24 then return nil end
            local out={}
            for key,value in pairs(v) do out[key]=clone(value,(depth or 0)+1) end
            return out
        end
        local prior=clone(db)
        local function restore()
            for key in pairs(db) do db[key]=nil end
            for key,value in pairs(prior) do db[key]=clone(value) end
        end
        if a.TakeLayoutSnapshot then a.TakeLayoutSnapshot("Before Reset All") end
        -- A factory reset controls only Mixolas-owned display/configuration.
        -- Neither Blizzard action slots nor their keybinding tables are edited.
        -- Preserve custom actions and character-owned Mixolas shortcut maps
        -- to avoid silently deleting an important combat setup.
        local protected={}
        for _,key in ipairs({"mixolasProfiles","mixolasSnapshots","characterDataMigrated",
            "bindings","customActions","legacyBindingsBackup","schemaVersion"}) do
            protected[key]=db[key]
        end
        for key in pairs(db) do db[key]=nil end
        copyDefaults(db,DEFAULTS)
        if not a.GetDefaultRegularBarLayout or not a.GetDefaultUtilityBarLayout then
            restore();say("Reset All failed: factory bar defaults unavailable.");return false
        end
        db.regularBars=a.GetDefaultRegularBarLayout()
        db.utilityBars=a.GetDefaultUtilityBarLayout()
        db.decorFrames={}
        db.frameStudio={}
        db.windowPositions={}
        -- Every appearance value, including the original Warlord module and
        -- flash options, returns to factory baseline, not its last preset.
        db.obsidianPrototype={enabled=true,scope="all",diamond=1,theme="warlord",
            intensity=0.20,frameOpacity=1,hc8GlowDefaultMigrated=true,hc9GlowScaleMigrated=true}
        db.activationFlash={enabled=true,strength=0.90,duration=0.36,
            bar1Modifier=true,hc14FlashDefaultMigrated=true}
        for key,value in pairs(protected) do db[key]=value end
        local function redraw()
            local tasks={"Refresh","RefreshRegularBars","RefreshUtilityBars",
                "ReloadDecorFromConfig","RefreshFrameStudio","RefreshCustomActions",
                "RefreshIcons","RefreshRegularActionIcons","RefreshHotkeys","ReapplyBindings",
                "UpdateGCD","UpdateMinimapIcon","RefreshRegularHandles","RefreshUtilityHandles",
                "RefreshDecorHandles","RefreshLayoutGuides"}
            for _,name in ipairs(tasks) do
                local fn=a[name]
                if type(fn)=="function" then
                    local ok,value=pcall(fn)
                    if not ok or value==false then return false,name..": "..tostring(value) end
                end
            end
            local vis=_G.MixolasBarsBlizzardVisibility
            if vis then
                for _,entry in ipairs({{"SetHiddenButtons",db.hideBlizzard},
                    {"SetHiddenArt",db.hideBlizzardArt}}) do
                    if type(vis[entry[1]])=="function" then
                        local ok,value=pcall(vis[entry[1]],entry[2])
                        if not ok or value==false then return false,entry[1]..": "..tostring(value) end
                    end
                end
            end
            local look=_G.MixolasBarsObsidian
            if look and look.Apply then
                local ok,value=pcall(look.Apply)
                if not ok or value==false then return false,"Warlord appearance: "..tostring(value) end
            end
            return true
        end
        local ok,why=redraw()
        if ok and a.ResetWindowPositions then
            local success,value=pcall(a.ResetWindowPositions)
            if not success or value==false then ok=false;why="ResetWindowPositions: "..tostring(value) end
        end
        if not ok then
            restore()
            pcall(redraw)
            say("Reset All failed; previous settings restored: "..tostring(why))
            return false
        end
        -- Reset All must not silently replace a saved named profile with the
        -- factory layout. Detach the character from that profile, then persist
        -- the new working layout. The prior named profile stays available.
        local character=a.GetCharacterDB and a.GetCharacterDB()
        if character then character.activeLayoutProfile=nil end
        if a.MarkVisualLayoutDirty then a.MarkVisualLayoutDirty() end
        if a.UpdateSettingsUI then pcall(a.UpdateSettingsUI) end
        say("Factory layout and appearance restored. Saved named profiles are unchanged.")
        return true
    end,
    RefreshHotkeys = refreshHotkeys,
    ReapplyBindings = applyBindings,
    SetHideBlizzard = function(enabled)
        if not initialized or inLockdown() then return false end
        local old = MixolasBarsDB.hideBlizzard
        MixolasBarsDB.hideBlizzard = not not enabled
        local ok = true
        if _G.MixolasBarsBlizzardVisibility then
            ok = _G.MixolasBarsBlizzardVisibility.SetHiddenButtons(MixolasBarsDB.hideBlizzard)
        end
        if not ok then
            MixolasBarsDB.hideBlizzard = old
            return false
        end
        applyBindings()
        return true
    end,
    SetHideBlizzardArt = function(enabled)
        if not initialized or inLockdown() then return false end
        local previous = MixolasBarsDB.hideBlizzardArt
        MixolasBarsDB.hideBlizzardArt = not not enabled
        local ok = _G.MixolasBarsBlizzardVisibility and
            _G.MixolasBarsBlizzardVisibility.SetHiddenArt(MixolasBarsDB.hideBlizzardArt)
        if not ok then MixolasBarsDB.hideBlizzardArt=previous; return false end
        return true
    end,
    SetCount = function(index, count)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        MixolasBarsDB.counts[index] = clamp(math.floor(count), 0, 4)
        refreshLayout()
        return true
    end,
    SetDiamondShowEmpty = function(index, show)
        if not initialized or inLockdown() or type(index)~="number" or index<1 or index>TOTAL_DIAMONDS then return false end
        MixolasBarsDB.diamondShowEmpty=MixolasBarsDB.diamondShowEmpty or {}
        MixolasBarsDB.diamondShowEmpty[index]=not not show
        updateDiamondSlotVisibility()
        -- Native inherited bindings follow only buttons currently visible.
        applyBindings()
        return true
    end,
    SetOpacity = function(index, alpha)
        -- Backward-compatible single-opacity setter: both states change.
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        local db=MixolasBarsDB
        db.alphas[index]=clamp(alpha,0.1,1)
        db.combatAlphas=db.combatAlphas or {}
        db.combatAlphas[index]=db.alphas[index]
        refreshDiamondCombatOpacity(false)
        return true
    end,
    SetDiamondOutOpacity = function(index, alpha)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        local db=MixolasBarsDB
        db.combatAlphas=db.combatAlphas or {}
        -- On first edit, freeze the existing combat alpha so changing the
        -- out-of-combat slider doesn't silently change both states.
        if db.combatAlphas[index]==nil then
            db.combatAlphas[index]=clamp(tonumber(db.alphas[index]) or 1,0.1,1)
        end
        db.alphas[index]=clamp(alpha,0.1,1)
        refreshDiamondCombatOpacity(false)
        return true
    end,
    SetDiamondCombatOpacity = function(index, alpha)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        local db=MixolasBarsDB
        db.combatAlphas=db.combatAlphas or {}
        db.combatAlphas[index]=clamp(alpha,0.1,1)
        refreshDiamondCombatOpacity(false)
        return true
    end,
    SetBrightness = function(index, value)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        MixolasBarsDB.brightness[index] = clamp(value, 0.25, 1.5)
        refreshLayout()
        return true
    end,
    SetDiamondGlow = function(index, value)
        if not initialized or inLockdown() or type(index)~="number" or index<1 or index>TOTAL_DIAMONDS then return false end
        MixolasBarsDB.diamondGlows=MixolasBarsDB.diamondGlows or {}
        MixolasBarsDB.diamondGlows[index]=clamp(value,0,1)
        refreshLayout()
        return true
    end,
    SetDiamondLighting = function(index, value)
        if not initialized or inLockdown() or type(index)~="number" or index<1 or index>TOTAL_DIAMONDS then return false end
        if value~="classic" and value~="refined" then return false end
        MixolasBarsDB.diamondIlluminationStyles=MixolasBarsDB.diamondIlluminationStyles or {}
        MixolasBarsDB.diamondIlluminationStyles[index]=value
        refreshLayout()
        return true
    end,
    SetScale = function(index, value)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        MixolasBarsDB.scales[index] = clamp(value, 0.35, 1.5)
        refreshLayout()
        return true
    end,
    SetDiamondGlowMotion = function(index, mode)
        if not initialized or inLockdown() or type(index)~="number" or index<1 or index>TOTAL_DIAMONDS then return false end
        if mode~="static" and mode~="pulse" and mode~="hum" then return false end
        MixolasBarsDB.glowMotions[index]=mode
        refreshLayout()
        return true
    end,
    SetDiamondBorderStyle = function(index, style)
        if not initialized or inLockdown() or type(index)~="number" or index<1 or index>TOTAL_DIAMONDS then return false end
        if style~="solid" and style~="double" and style~="etched" and style~="none" then return false end
        -- Accept old callers supplying Etched, but never write it anew.
        MixolasBarsDB.borderStyles[index]=(style=="etched" and "solid" or style)
        refreshLayout()
        return true
    end,
    CycleGlowMotion = function(index)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        local modes={"static","pulse","hum"}
        local current=MixolasBarsDB.glowMotions[index]
        local nextIndex=1
        for k,v in ipairs(modes) do if v==current then nextIndex=k%#modes+1 end end
        MixolasBarsDB.glowMotions[index]=modes[nextIndex]
        refreshLayout()
        return true
    end,
    CycleBorderStyle = function(index)
        if not initialized or inLockdown() or index < 1 or index > TOTAL_DIAMONDS then return false end
        local styles = {"solid", "double", "none"}
        local current = MixolasBarsDB.borderStyles[index]
        if current=="etched" then current="solid" end
        local nextIndex=1
        for k,v in ipairs(styles) do if v == current then nextIndex = k % #styles + 1 end end
        MixolasBarsDB.borderStyles[index] = styles[nextIndex]
        refreshLayout()
        return true
    end,
    ImportLegacyActions = function()
        if not initialized or inLockdown() or not MixolasBarsDB then return 0,0 end
        if not (GetCursorInfo and PlaceAction and HasAction) or GetCursorInfo() then
            say("Clear the cursor and try again outside combat.")
            return 0,0
        end
        local copied, skipped = 0, 0
        for logical=13,32 do
            local entry = MixolasBarsDB.customActions and MixolasBarsDB.customActions[tostring(logical)]
            local i = math.ceil(logical/4)
            local j = ((logical-1)%4)+1
            local dest = diamondSlot(i,j)
            if entry and not HasAction(dest) then
                if entry.kind=="spell" and PickupSpell then pcall(PickupSpell, entry.value)
                elseif entry.kind=="item" and PickupItem then pcall(PickupItem, entry.value)
                elseif entry.kind=="macro" and PickupMacro then pcall(PickupMacro, entry.value) end
                if GetCursorInfo() then
                    PlaceAction(dest)
                    if ClearCursor and GetCursorInfo() then ClearCursor() end
                    if HasAction(dest) then copied=copied+1 else skipped=skipped+1 end
                else skipped=skipped+1 end
            elseif entry then skipped=skipped+1 end
        end
        refreshIcons()
        say("Legacy spells restored: "..copied.."; skipped/occupied: "..skipped..". Old data preserved.")
        return copied, skipped
    end,
    ClearCustomAction = function() return false end,

}

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
-- Do not register CURSOR_UPDATE: removed from modern Classic Era clients.
-- Poll GetCursorInfo every 0.10s instead, avoiding version-dependent events.
events:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
events:RegisterEvent("UPDATE_MACROS")
events:RegisterEvent("BAG_UPDATE_DELAYED")
events:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
events:RegisterEvent("SPELL_UPDATE_COOLDOWN")
events:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
events:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
events:RegisterEvent("UPDATE_BINDINGS")
events:RegisterEvent("PLAYER_TARGET_CHANGED")
events:RegisterEvent("ACTIONBAR_UPDATE_USABLE")
events:RegisterEvent("SPELL_UPDATE_USABLE")
events:RegisterEvent("SPELL_ACTIVATION_OVERLAY_SHOW")
events:RegisterEvent("SPELL_ACTIVATION_OVERLAY_HIDE")
events:RegisterEvent("ACTIONBAR_UPDATE_STATE")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_LOGOUT")
-- Detect carried spells without registering the removed Classic CURSOR_UPDATE
-- event. An empty slot that only appears AFTER a drag starts is not reliably
-- given the first drag's mouse-up by the WoW client. When that happens, finish
-- the SAME physical drag using the existing native drop handler: no second
-- click, no invented action-copying code, no change to keybinding capture.
local function refreshCursorPlacement()
    if not initialized or inLockdown() then return end
    -- While dragging an existing icon, PickupAction can briefly empty its
    -- source before GetCursorInfo reports a cursor payload. Keep grid visible
    -- until the physical release so the mouse-up can reach the target.
    local dragging=activeActionDrag and IsMouseButtonDown and IsMouseButtonDown("LeftButton")
    local carrying=hasPlaceableCursor() or (dragging and true or false) or pendingHiddenSlotRelease~=nil
    if carrying==cursorRevealActive then return end
    cursorRevealActive=carrying
    updateDiamondSlotVisibility()
    local regular=_G.MixolasBarsAPI
    if regular and regular.RefreshRegularEmptyVisibility then regular.RefreshRegularEmptyVisibility() end
end

-- Frame positions are in UI coordinates, whereas GetCursorPosition() returns
-- physical pixels. Convert once via UIParent's effective scale.
local function isMouseWithin(button,x,y)
    if not button or not button.GetLeft or not button.GetRight
        or not button.GetTop or not button.GetBottom then return false end
    local l,r,t,b=button:GetLeft(),button:GetRight(),button:GetTop(),button:GetBottom()
    return l and r and t and b and x>=l and x<=r and y>=b and y<=t
end
local function slotHasAction(button)
    if button.isCustom then
        local db=MixolasBarsDB
        return db and db.customActions and db.customActions[tostring(button.slot)]~=nil
    end
    local slot=button:GetAttribute("action") or button.actionSlot
    local filled=compat.ActionHas and compat.ActionHas(slot)
    if filled==nil and HasAction then filled=HasAction(slot) end
    if filled==nil and GetActionInfo then filled=GetActionInfo(slot)~=nil end
    return filled==true
end
-- No confirmation or special placement mode: a dragged spell may go onto
-- ANY enabled action button. RC8.4 only recovered hidden EMPTY destinations,
-- leaving visible diamond/regular transfers asymmetric if OnReceiveDrag missed.
local function isEligibleDropDestination(button)
    local db=MixolasBarsDB
    if not db or not db.visible or not db.locked or inLockdown() then return false end
    if not button or (button.IsShown and not button:IsShown()) then return false end
    if button.isDiamond then
        local i,j=button.diamondIndex,button.diamondButtonIndex
        return db.diamondEnabled[i]~=false and j<=(db.counts[i] or 4)
            and clusters[i] and clusters[i]:IsShown()
    end
    local config=db.regularBars and db.regularBars[button.barNumber]
    return config and config.enabled and button.barIndex<=config.count
        and button.GetParent and button:GetParent():IsShown()
end
local function finishMissedSlotDrop(target)
    if not initialized or inLockdown() or not hasPlaceableCursor() or not target then return false end
    if not isEligibleDropDestination(target) then return false end
    if target.isDiamond then
        return receiveCursor(target) == true
    elseif target._mixolasReceiveCursor then
        local before=cursorPlacementSerial
        target:_mixolasReceiveCursor()
        return cursorPlacementSerial~=before
    end
    return false
end

-- RC8.5: An actual release event plus unified destination recovery beats sampling
-- IsMouseButtonDown during OnUpdate. With a fast drag the press and release
-- can both occur between update ticks, which is why RC8.2/8.3 missed drops.
-- Where supported, use GLOBAL_MOUSE_UP. Guard registration:
-- unsupported events throw and must never break PLAYER_LOGIN initialization.
-- If the event is unavailable, use a conservative edge-poll fallback instead.
local cursorPollElapsed=0
local previousLeftDown=false
-- A GLOBAL_MOUSE_UP on a normal spell click must not stage a drag-drop
-- recovery. Capture the press position to distinguish a real physical drag.
local leftPressX,leftPressY=nil,nil
local globalMouseDownAvailable=false
local globalMouseUpAvailable=false
local lastHiddenDropDiagnostic="No hidden-slot release observed yet"
local hiddenDropStats={mouseUps=0,eligible=0,completed=0,missed=0}

local function findDropDestinationUnderCursor(screenX,screenY)
    if not screenX or not screenY or not UIParent or not UIParent.GetEffectiveScale then return nil end
    local scale=UIParent:GetEffectiveScale()
    if not scale or scale<=0 then return nil end
    local x,y=screenX/scale,screenY/scale
    for _,cluster in ipairs(clusters) do
        if cluster:IsShown() then
            for _,button in ipairs(cluster.buttons) do
                if isEligibleDropDestination(button) and isMouseWithin(button,x,y) then
                    return button,"diamond "..tostring(button.diamondIndex).."/"..tostring(button.diamondButtonIndex)
                end
            end
        end
    end
    for _,button in ipairs(regularButtons) do
        if isEligibleDropDestination(button) and isMouseWithin(button,x,y) then
            return button,"bar "..tostring(button.barNumber).."/"..tostring(button.barIndex)
        end
    end
    return nil
end

local function trackHiddenSlotMouseUp(origin)
    -- Consume the press origin on EVERY release, even if the cursor is not
    -- over one of our buttons, to avoid stale coordinates on the next click.
    local pressX,pressY=leftPressX,leftPressY
    leftPressX,leftPressY=nil,nil
    if not initialized or inLockdown() or not GetCursorPosition then return end
    hiddenDropStats.mouseUps=hiddenDropStats.mouseUps+1
    local x,y=GetCursorPosition()
    -- WoW emits GLOBAL_MOUSE_UP for ALL ordinary clicks. Previously we queued
    -- a 9-frame fallback on every click over a Mixolas spell slot, which
    -- briefly made the entire hidden-slot grid appear. Only stage recovery
    -- when there is actual drag intent: an action carried on the cursor,
    -- our explicit OnDragStart, or a physical pointer move since mouse-down
    -- (needed for very fast spellbook drags whose cursor payload arrives late).
    local dx,dy=pressX and (x-pressX) or 0,pressY and (y-pressY) or 0
    local moved=pressX~=nil and pressY~=nil and (dx*dx+dy*dy)>=144
    if not (hasPlaceableCursor() or activeActionDrag or moved) then
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic=origin..": ordinary click (no drag); ignored"
        return
    end
    local target,label=findDropDestinationUnderCursor(x,y)
    if not target then
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic=origin..": mouse released outside an eligible action button"
        return
    end
    hiddenDropStats.eligible=hiddenDropStats.eligible+1
    -- Native OnReceiveDrag/PreClick can execute BEFORE GLOBAL_MOUSE_UP. If
    -- the cursor now holds the displaced action from a swap, never place it
    -- back onto the same target. RC8.4's hidden-empty-only check avoided
    -- this case, but recovery for VISIBLE occupied slots requires it.
    if target==lastNativeDropButton and GetTime
        and GetTime()-lastNativeDropTime < 0.75 then
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic=label..": native drop already handled before release"
        return
    end
    -- Keep the coordinates captured on release; the cursor can move before
    -- WoW's next OnUpdate. The native drop handler takes priority and
    -- invalidates our placement serial so a swap is NEVER performed twice.
    pendingHiddenSlotRelease={x=x,y=y,serial=cursorPlacementSerial,frames=0,label=label,origin=origin}
    lastHiddenDropDiagnostic=origin..": detected "..label.."; waiting for native drop/cursor"
end

local function resolvePendingHiddenDrop()
    local pending=pendingHiddenSlotRelease
    if not pending then return end
    if inLockdown() or not initialized then
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic="Cancelled: combat or addon not initialized"
        return
    end
    if pending.serial~=cursorPlacementSerial then
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic="Native WoW drop already handled (no duplicate)"
        return
    end
    pending.frames=pending.frames+1
    -- The next frame is AFTER normal OnReceiveDrag; one later frame also
    -- accommodates cursor state updates delayed by the spellbook UI.
    if hasPlaceableCursor() then
        local target=findDropDestinationUnderCursor(pending.x,pending.y)
        if not target then
            pendingHiddenSlotRelease=nil
            lastHiddenDropDiagnostic=pending.label..": no longer visible/eligible; skipped"
            return
        end
        if finishMissedSlotDrop(target) then
            hiddenDropStats.completed=hiddenDropStats.completed+1
            lastHiddenDropDiagnostic=pending.label..": assigned on release ("..pending.origin..")"
        else
            hiddenDropStats.missed=hiddenDropStats.missed+1
            lastHiddenDropDiagnostic=pending.label..": placement handler rejected cursor"
        end
        pendingHiddenSlotRelease=nil
    elseif pending.frames>=9 then
        hiddenDropStats.missed=hiddenDropStats.missed+1
        pendingHiddenSlotRelease=nil
        lastHiddenDropDiagnostic=pending.label..": no placeable cursor after release (9 frames)"
    end
end

-- Initialize without allowing unsupported events to kill all diamonds.
-- GLOBAL_MOUSE_DOWN supplies real pointer movement for fast spellbook drags.
-- On clients without it, we fall back to sampling while the button is held.
local okMouseDown,registeredMouseDown=pcall(events.RegisterEvent,events,"GLOBAL_MOUSE_DOWN")
globalMouseDownAvailable=okMouseDown and registeredMouseDown~=false
local okMouseUp,registeredMouseUp=pcall(events.RegisterEvent,events,"GLOBAL_MOUSE_UP")
globalMouseUpAvailable=okMouseUp and registeredMouseUp~=false

SLASH_MIXOLASDRAGDIAG1="/mxbdrag"
SlashCmdList["MIXOLASDRAGDIAG"]=function()
    say("Action-slot drag: "..lastHiddenDropDiagnostic)
    say("Mouse release: "..(globalMouseUpAvailable and "GLOBAL_MOUSE_UP" or "poll fallback")
      .." | eligible "..hiddenDropStats.eligible.." / releases "..hiddenDropStats.mouseUps
      .." | fallback placed "..hiddenDropStats.completed.." | unresolved "..hiddenDropStats.missed)
    say("Cursor "..tostring(GetCursorInfo and GetCursorInfo() or "none")
      .." | source "..tostring(activeActionDrag and activeActionDrag.GetName and activeActionDrag:GetName() or "none")
      .." | reveal "..tostring(cursorRevealActive)
      .." | locked "..tostring(MixolasBarsDB and MixolasBarsDB.locked))
end

events:SetScript("OnUpdate",function(_,elapsed)
    -- Poll the cursor every frame, but ONLY change secure visibility on an
    -- actual state transition. That makes reveal and re-hide responsive even
    -- during fast drag-and-release interactions.
    if initialized and not inLockdown() then
        local down=IsMouseButtonDown and IsMouseButtonDown("LeftButton")
        if activeActionDrag and not down then activeActionDrag=nil end
        local carrying=hasPlaceableCursor() or (activeActionDrag and down and true or false) or pendingHiddenSlotRelease~=nil
        if carrying~=cursorRevealActive then
            -- Do not briefly re-hide during a held drag's cursor transition.
            if carrying or not (IsMouseButtonDown and IsMouseButtonDown("LeftButton")) then
                refreshCursorPlacement()
            end
        end
    end
    if initialized and IsMouseButtonDown then
        local down=IsMouseButtonDown("LeftButton")
        if down and not previousLeftDown and not globalMouseDownAvailable and GetCursorPosition then
            leftPressX,leftPressY=GetCursorPosition()
        end
        if not globalMouseUpAvailable and previousLeftDown and not down then
            trackHiddenSlotMouseUp("poll")
        end
        previousLeftDown=down
    end
    resolvePendingHiddenDrop()
end)
events:SetScript("OnEvent", function(_, event, mouseButton)
    if event == "GLOBAL_MOUSE_DOWN" then
        if mouseButton == "LeftButton" and GetCursorPosition then
            leftPressX,leftPressY=GetCursorPosition()
        end
        return
    end
    if event == "GLOBAL_MOUSE_UP" then
        if mouseButton == "LeftButton" then trackHiddenSlotMouseUp("global") end
        return
    end
    if event == "PLAYER_LOGOUT" then
        -- Flush character references even after a settings import or reset.
        if characterDB and MixolasBarsDB then
            characterDB.bindings = MixolasBarsDB.bindings or {}
            characterDB.customActions = MixolasBarsDB.customActions or {}
        end
        return
    end
    if event == "PLAYER_LOGIN" then
        MixolasBarsDB = MixolasBarsDB or {}
        -- Prior versions coupled Blizzard artwork and action-button hiding.
        -- Respect the user's previous choice on first upgrade, then save the
        -- two settings independently.
        if MixolasBarsDB.hideBlizzardArt == nil then
            MixolasBarsDB.hideBlizzardArt = MixolasBarsDB.hideBlizzard == true
        end
        -- Preserve spacing for existing hc16 installations; only NEW installs
        -- receive the compact 0px E/W default. No silent layout jumps.
        local hadPreviousLayout = MixolasBarsDB.buttonSize ~= nil
        local previousGap = tonumber(MixolasBarsDB.gap) or 3
        local previousEW = MixolasBarsDB.diamondGapEW
        local previousNS = MixolasBarsDB.diamondGapNS
        copyDefaults(MixolasBarsDB, DEFAULTS)
        -- Retire the visibly choppy per-button Trail effect without changing
        -- any other saved illumination choice or controller layout.
        for i=1,TOTAL_DIAMONDS do
            if MixolasBarsDB.glowMotions[i]=="trail" then MixolasBarsDB.glowMotions[i]="static" end
        end
        if hadPreviousLayout then
            if previousEW == nil then MixolasBarsDB.diamondGapEW = previousGap end
            if previousNS == nil then MixolasBarsDB.diamondGapNS = previousGap end
        end
        -- Requested in 0.19.4: retire all duplicate Blizzard action bars and
        -- main-bar artwork on this installation. Do this ONCE, even for users
        -- whose older profile saved both toggles as false. Future deliberate
        -- changes made in Options are respected on subsequent logins.
        if not MixolasBarsDB.nativeActionBarsHiddenV194 then
            MixolasBarsDB.hideBlizzard = true
            MixolasBarsDB.hideBlizzardArt = true
            MixolasBarsDB.nativeActionBarsHiddenV194 = true
        end
        -- One-time migration: previous builds shipped Snap OFF and only had a
        -- handful of guide lines (not a genuine grid). The v0.19.2 grid is
        -- enabled once on upgrade; thereafter the user's ON/OFF choice sticks.
        if not MixolasBarsDB.gridSnapV2Initialized then
            MixolasBarsDB.snapEnabled = true
            MixolasBarsDB.gridSnapV2Initialized = true
        end
        -- Account-wide preferences and graphics remain in MixolasBarsDB.
        -- Bindings and independently stored extra-bar actions belong to this
        -- CHARACTER. Older installations are copied once, never deleted.
        MixolasBarsCharacterDB = MixolasBarsCharacterDB or {}
        characterDB = MixolasBarsCharacterDB
        local function copyCharacterTable(source)
            local result = {}
            for k,v in pairs(source or {}) do
                if type(v) == "table" then
                    result[k]={}
                    for key,value in pairs(v) do result[k][key]=value end
                else result[k]=v end
            end
            return result
        end
        -- Only the first upgraded character inherits the old account-wide
        -- shortcuts. New characters start unbound, so one character's inputs
        -- cannot silently activate another character's abilities.
        local legacyAccountData = not MixolasBarsDB.characterDataMigrated
        if type(characterDB.bindings) ~= "table" then
            characterDB.bindings = legacyAccountData and copyCharacterTable(MixolasBarsDB.bindings) or {}
        end
        if type(characterDB.customActions) ~= "table" then
            characterDB.customActions = legacyAccountData and copyCharacterTable(MixolasBarsDB.customActions) or {}
        end
        MixolasBarsDB.characterDataMigrated = true
        MixolasBarsDB.bindings = characterDB.bindings
        MixolasBarsDB.customActions = characterDB.customActions
        MixolasBarsDB.combatUsability = true -- always enabled, including migrated saves
        local duplicateCount=cleanSavedBindingCollisions()
        if duplicateCount>0 then
            say("Cleaned "..duplicateCount.." invalid, duplicate, or excess Mixolas shortcuts (up to three per button). Original bindings backed up where needed.")
        end
        -- v0.10 used overlapping regular/diamond binding IDs.  Preserve a
        -- recoverable copy, but never route ambiguous old bindings to new buttons.
        if (MixolasBarsDB.schemaVersion or 0) < 11 then
            if type(MixolasBarsDB.bindings) == "table" and next(MixolasBarsDB.bindings) then
                MixolasBarsDB.legacyBindingsBackup = MixolasBarsDB.legacyBindingsBackup or MixolasBarsDB.bindings
                MixolasBarsDB.bindings = {}
                characterDB.bindings = MixolasBarsDB.bindings
                say("Old overlapping keybindings backed up; please rebind in the editor.")
            end
            MixolasBarsDB.schemaVersion = 11
        end
        -- v0.12 reassigns diamond action slots to Bars 3, 4, and 5.
        -- Do not auto-move old native actions: slots may already contain spells.
        if (MixolasBarsDB.schemaVersion or 0) < 12 then
            MixolasBarsDB.schemaVersion = 12
            say("Action ownership updated: Bar 2 is separate; diamonds use Bars 3-5. Existing native slots were not overwritten.")
        end
        -- An old v0.3 bindExtra flag is intentionally ignored (no auto chords).
        MixolasBarsDB.bindExtra = nil
        for i = 1, TOTAL_DIAMONDS do clusters[i] = createCluster(i) end
        -- Diamonds are fixed to their own traditional bars, independent of all
        -- class/form paging.  Only the standalone regular Bar 1 is stance-paged.
        initialized = true
        if _G.MixolasBarsBlizzardVisibility then
            _G.MixolasBarsBlizzardVisibility.SetHiddenButtons(MixolasBarsDB.hideBlizzard)
            _G.MixolasBarsBlizzardVisibility.SetHiddenArt(MixolasBarsDB.hideBlizzardArt)
        end
        refreshLayout()
        refreshIcons()
        refreshCursorPlacement()
        say("0.21.11 RC8.8 loaded. Cooldown display and binding-mode empty slots updated.")
    elseif initialized then
        if event=="PLAYER_REGEN_DISABLED" then
            refreshDiamondCombatOpacity(true)
        elseif event=="PLAYER_REGEN_ENABLED" then
            refreshDiamondCombatOpacity(false)
        end
        if event == "ACTIONBAR_SLOT_CHANGED" or event == "ACTIONBAR_PAGE_CHANGED" or event == "UPDATE_SHAPESHIFT_FORM" or event == "BAG_UPDATE_DELAYED" or event == "UPDATE_MACROS" then
            refreshIcons()
            if event == "ACTIONBAR_SLOT_CHANGED" or event == "BAG_UPDATE_DELAYED" then
                for _,cluster in ipairs(clusters) do
                    for _,b in ipairs(cluster.buttons) do safeCooldown(b) end
                end
            end
            if _G.MixolasBarsAPI.RefreshRegularActionIcons then
                _G.MixolasBarsAPI.RefreshRegularActionIcons()
            end
        end
        if event == "UPDATE_BINDINGS" then
            if _G.MixolasBarsAPI and _G.MixolasBarsAPI.IsProfileApplying
                    and _G.MixolasBarsAPI.IsProfileApplying() then
                -- Avoid re-routing secure overrides against a half-restored
                -- native binding set. Profile loading applies once at the end.
            elseif _G.MixolasBarsAPI and _G.MixolasBarsAPI.IsBindingMode
                    and _G.MixolasBarsAPI.IsBindingMode() then
                -- Do not overwrite the unsaved keybinding preview with live labels.
            else applyBindings() end
        end
        if event=="PLAYER_REGEN_ENABLED" or event=="PLAYER_ENTERING_WORLD" then
            -- Apply any visibility changes deferred during combat.
            -- Recheck the real cursor after combat before touching secure frames.
            cursorRevealActive=hasPlaceableCursor()
            refreshIcons()
            if _G.MixolasBarsAPI.RefreshRegularEmptyVisibility then
                _G.MixolasBarsAPI.RefreshRegularEmptyVisibility()
            end
            applyBindings()
        elseif event=="ACTIONBAR_SLOT_CHANGED" and not inLockdown() then
            -- An empty slot gaining a spell must regain its native key bridge.
            applyBindings()
        end
        for _, cluster in ipairs(clusters) do
            for _, button in ipairs(cluster.buttons) do updateButtonRange(button) end
        end
        for _, button in ipairs(regularButtons) do updateButtonRange(button) end
    end
end)

-- In-game verification (out of combat): /mxbkey SHIFT-A
-- Inspect both Blizzard's stored binding and the currently effective secure click.
SLASH_MIXOLASKEYCHECK1="/mxbkey"
SlashCmdList["MIXOLASKEYCHECK"]=function(raw)
    local key=type(raw)=="string" and raw:upper():gsub("^%s+",""):gsub("%s+$","") or ""
    if key=="" then
        say("Usage: /mxbkey SHIFT-A (or any key/chord). Checks Blizzard native and Mixolas routing.")
        return
    end
    if not inLockdown() then applyBindings() end
    local report=_G.MixolasBarsAPI and _G.MixolasBarsAPI.AuditKeyRouting
        and _G.MixolasBarsAPI.AuditKeyRouting(key)
    for line in tostring(report or "Unavailable"):gmatch("[^\n]+") do say(line) end
end
