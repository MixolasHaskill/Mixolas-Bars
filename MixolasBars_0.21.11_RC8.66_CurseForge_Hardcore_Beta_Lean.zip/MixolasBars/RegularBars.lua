-- Mixolas Bars: independently written traditional action-bar module.
-- Classic Era native slots: Bar 1 main/stance; Bars 2-4 are owned by diamonds;
-- regular Bar 2 is separate, while Bars 3-5 belong to diamonds.
-- Normal bars are independently movable and editable, alongside diamonds.
local compat = _G.MixolasBarsCompat or {}
local feedback = _G.MixolasBarsPressFeedback or {}
local api = _G.MixolasBarsAPI
if not api then return end
local bars = {}
-- Shared spell cursor source lives in the core module so bar-to-diamond swaps work.
local regularButtons = {}
local RESERVED = {[3]=true,[4]=true,[5]=true}
local BAR_COUNT=8
local barDefaults = {enabled=false, count=12, rows=1, scale=0.85, alpha=1,
    padding=2, x=0, y=0, showGrid=true}
local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
local function copyDefaults(db)
    db.regularBars=db.regularBars or {}
    for n=1,BAR_COUNT do
        if type(db.regularBars[n])~="table" then
            db.regularBars[n]={}
            -- New installs only: left Bar 2, center diamonds, right Bar 1.
            -- Existing character/profile layouts are never migrated silently.
            if n == 1 or n == 2 then
                db.regularBars[n].enabled=true
                db.regularBars[n].count=12
                db.regularBars[n].rows=4  -- 3 columns x 4 rows
                db.regularBars[n].x=(n == 1) and 365 or -365
                db.regularBars[n].y=-83
                db.regularBars[n].positionInitialized=true
            end
        end
        local c=db.regularBars[n]
        for key,value in pairs(barDefaults) do
            if c[key]==nil then c[key]=value end
        end
        -- Upgrade pre-combat-opacity profiles without changing how any bar
        -- currently looks: both combat states inherit the saved opacity.
        -- The legacy alpha field remains for old profile/import compatibility.
        if c.alphaOut==nil then c.alphaOut=clamp(tonumber(c.alpha) or 1,0.1,1) end
        if c.alphaCombat==nil then c.alphaCombat=clamp(tonumber(c.alpha) or 1,0.1,1) end
        -- Position defaults are applied exactly once.  A deliberately centered
        -- bar (0, 0) must never be relocated during a subsequent slider update.
        if c.positionInitialized ~= true then
            if c.x == 0 and c.y == 0 then
                c.x=(n-3.5)*165; c.y=-355
            end
            c.positionInitialized = true
        end
    end
end
-- Read-only factory template for NEW profiles. Uses the same defaults as
-- an untouched installation, including 3x4 Bar 1/2 and disabled mirror bars.
api.GetDefaultRegularBarLayout=function()
    local fresh={}
    copyDefaults(fresh)
    return fresh.regularBars
end
local function updateButtonIcon(button)
    if not button then return end
    local slot=button.actionSlot
    local effective=button:GetAttribute("action") or slot
    local stored=button.isCustom and api.GetDB().customActions[tostring(button.slot)]
    local texture
    if button.isCustom then
        if stored then
            if stored.kind=="spell" and compat.SpellTexture then texture=compat.SpellTexture(stored.value)
            elseif stored.kind=="item" then
                if C_Item and C_Item.GetItemIconByID then
                    local ok,t=pcall(C_Item.GetItemIconByID,stored.value)
                    if ok and t then texture=t end
                end
                if not texture and GetItemIcon then
                    local ok,t=pcall(GetItemIcon,stored.value)
                    if ok then texture=t end
                end
            elseif stored.kind=="macro" and GetMacroInfo then local _,icon=GetMacroInfo(stored.value); texture=icon end
        end
        local signature=stored and (stored.kind..":"..tostring(stored.value)) or "empty"
        if button._mixolasLastActionSignature ~= signature then
            button._mixolasLastActionSignature=signature
            button._mxbNativeCooldown=false
            button._mxbNativeStart,button._mxbNativeDuration=nil,nil
            button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
            if button.cooldown then button.cooldown:Hide() end
            if button.mxbGCD then button.mxbGCD:Hide() end
            if button.countText then button.countText:SetText("") end
            if button.cooldownNumber then button.cooldownNumber:SetText("") end
            button._mxbLastCooldownNumber=nil
        end
    else
        texture=compat.ActionTexture and compat.ActionTexture(effective)
        -- This native slot can change spells independently of the bar layout.
        -- Invalidate any cached duration-object draw when its action changes.
        local kind,id
        if GetActionInfo then
            local ok,k,v=pcall(GetActionInfo,effective)
            if ok then kind,id=k,v end
        end
        local signature=tostring(effective)..":"..tostring(kind)..":"..tostring(id)..":"..tostring(texture)
        if button._mixolasLastActionSignature ~= signature then
            button._mixolasLastActionSignature=signature
            button._mxbNativeCooldown=false
            button._mxbNativeStart,button._mxbNativeDuration=nil,nil
            button._mxbLegacyStart,button._mxbLegacyDuration=nil,nil
            if button.cooldown then button.cooldown:Hide() end
            if button.mxbGCD then button.mxbGCD:Hide() end
            if button.cooldownNumber then button.cooldownNumber:SetText("") end
            button._mxbLastCooldownNumber=nil
        end
    end
    if texture then button.icon:SetTexture(texture); button.icon:Show(); if button.base then button.base:Show() end
    elseif button.icon then button.icon:Hide(); if button.base then button.base:Hide() end end
    -- Clear the entire old action presentation on every refresh, even when
    -- a new potion/spell shares the same icon or the event arrives late.
    if button.countText then button.countText:SetText("") end
    if button.pressedShade and GetCursorInfo and GetCursorInfo() then button.pressedShade:Hide() end
    -- Avoid flashing the countdown off when unrelated actionbar/inventory
    -- events refresh the icon without changing the button's actual action.
    if button.isCustom then
        if stored and stored.kind=="item" and compat.ItemCount and button.countText then
            local count=compat.ItemCount(stored.value)
            if type(count)=="number" and count>1 then button.countText:SetText(tostring(count)) end
        end
    elseif button.countText and compat.ActionCount then
        local count=compat.ActionCount(effective)
        if type(count)=="number" and count>1 then button.countText:SetText(tostring(count)) end
    end
    if button.macroText then
        local label
        if api.GetDB().showMacroNames then
            if button.isCustom then
                if stored and stored.kind=="macro" and compat.MacroName then label=compat.MacroName(stored.value) end
            elseif compat.ActionMacroName then
                label=compat.ActionMacroName(effective)
            end
        end
        button.macroText:SetText(label or "")
    end
    if api.RefreshRange then api.RefreshRange(button) end
end
local function showRegularSlot(button,config,db)
    if button.barIndex > config.count then return false end
    -- Keep enabled normal slots visible if populated, even after a drop,
    -- and use the temporary reveal only for enabled bars with hidden blanks.
    if config.showGrid or (api.IsPlacementCursorActive and api.IsPlacementCursorActive())
        or (api.IsBindingSlotRevealActive and api.IsBindingSlotRevealActive()) then
        return true
    end
    if button.isCustom then
        return db.customActions and db.customActions[tostring(button.slot)]~=nil or false
    end
    local slot=button:GetAttribute("action") or button.actionSlot
    local occupied=compat.ActionHas and compat.ActionHas(slot)
    if occupied==nil and HasAction then occupied=HasAction(slot) end
    if occupied==nil and GetActionInfo then occupied=GetActionInfo(slot)~=nil end
    return occupied==true
end
local function refreshRegularEmptyVisibility()
    if api.IsInCombat() then return false end
    local db=api.GetDB()
    if not db or not db.regularBars then return false end
    for n,bar in ipairs(bars) do
        local c=db.regularBars[n]
        if bar and c then
            for _,button in ipairs(bar.buttons) do
                button:SetShown(showRegularSlot(button,c,db))
            end
        end
    end
    return true
end
local function barOpacity(config,inCombat)
    if not config then return 1 end
    local base=tonumber(config.alpha) or 1
    return clamp(tonumber(inCombat and config.alphaCombat or config.alphaOut) or base,0.1,1)
end
-- Purely visual updates; never redraw, show/hide or change secure action
-- attributes when entering combat. Alpha does not change button hit targets.
local function refreshCombatOpacity(forceInCombat)
    local db=api.GetDB()
    if not db or type(db.regularBars)~="table" then return false end
    local inCombat=forceInCombat
    if inCombat==nil then inCombat=api.IsInCombat() end
    for n,frame in ipairs(bars) do
        local config=db.regularBars[n]
        if frame and config then
            -- On versions restricting visual operations in combat, fail safely
            -- instead of interrupting action execution. Full redraw still
            -- occurs outside combat on subsequent edits/reload.
            pcall(frame.SetAlpha,frame,barOpacity(config,inCombat))
        end
    end
    return true
end
local function redraw(onlyBar)
    if api.IsInCombat() then return false end
    local db=api.GetDB()
    if not db then return false end
    copyDefaults(db)
    for n=1,BAR_COUNT do
        local frame=bars[n]
        local c=db.regularBars[n]
        if frame and c and (not onlyBar or n == onlyBar) then
            local size=38
            local cols=math.max(1, math.ceil(c.count/c.rows))
            local width=math.max(1,cols)*size+math.max(0,cols-1)*c.padding
            local height=math.max(1,c.rows)*size+math.max(0,c.rows-1)*c.padding
            frame:SetSize(width,height)
            frame:SetScale(c.scale)
            frame:SetAlpha(barOpacity(c,api.IsInCombat()))
            frame:ClearAllPoints()
            frame:SetPoint("CENTER",UIParent,"CENTER",c.x,c.y)
            frame:SetShown(c.enabled and db.visible and not RESERVED[n])
            -- Editing handles are NEVER displayed in locked mode.
            frame.handle:SetShown(false)
            if frame.editMask then frame.editMask:SetShown(not db.locked and c.enabled and db.visible and not RESERVED[n]) end
            for j,button in ipairs(frame.buttons) do
                local col=math.floor((j-1)/c.rows)
                local row=(j-1)%c.rows
                button:SetSize(size,size)
                button:ClearAllPoints()
                button:SetPoint("TOPLEFT",frame,"TOPLEFT",col*(size+c.padding),-row*(size+c.padding))
                button:SetShown(showRegularSlot(button,c,db))
                updateButtonIcon(button)
            end
        end
    end
    if api.ReapplyBindings then api.ReapplyBindings() end
    return true
end
-- Extra Bars 7/8 use independently saved spell, item and macro actions.
-- They do NOT borrow class/stance bonus action slots.
local function cursorEntry()
    if not GetCursorInfo then return nil end
    local kind,a,b,c=GetCursorInfo()
    if kind=="spell" then
        local id=compat.CursorSpellID and compat.CursorSpellID(a,b,c) or c
        if id then return {kind="spell",value=id} end
    elseif kind=="item" or kind=="macro" then
        return a and {kind=kind,value=a}
    elseif kind=="action" and GetActionInfo then
        local k,id=GetActionInfo(a)
        if (k=="spell" or k=="item" or k=="macro") and id then return {kind=k,value=id} end
    end
    return nil
end
local function setExtra(button,entry)
    if api.IsInCombat() then return end
    local db=api.GetDB()
    db.customActions=db.customActions or {}
    db.customActions[tostring(button.slot)]=entry and {kind=entry.kind,value=entry.value} or nil
    for _,k in ipairs({"spell","item","macro"}) do button:SetAttribute(k,nil) end
    button:SetAttribute("type",entry and entry.kind or nil)
    if entry then button:SetAttribute(entry.kind,entry.value) end
    if button.keyProxy then
        for _,k in ipairs({"type","spell","item","macro"}) do button.keyProxy:SetAttribute(k,nil) end
        button.keyProxy:SetAttribute("type",entry and entry.kind or nil)
        if entry then button.keyProxy:SetAttribute(entry.kind,entry.value) end
    end
    updateButtonIcon(button)
    if api.RefreshCooldown then api.RefreshCooldown(button) end
end
local function cursorPickup(entry)
    if not entry then return end
    if entry.kind=="spell" and PickupSpell then PickupSpell(entry.value)
    elseif entry.kind=="item" and PickupItem then PickupItem(entry.value)
    elseif entry.kind=="macro" and PickupMacro then PickupMacro(entry.value) end
end
-- Physical action drags suppress casting until after the actual mouse up,
-- not merely until the next animation frame.
local function suppressActionForDrag(b)
    if api.IsInCombat() then return end
    b._mixolasSuppressClick=true
    if feedback.Reset then feedback.Reset(b) end
    b:SetAttribute("type",nil)
end
local function finishActionDrag(b)
    if api.IsInCombat() or not b._mixolasSuppressClick or b._mixolasRestoreQueued then return end
    b._mixolasRestoreQueued=true
    b:SetScript("OnUpdate",function(self)
        -- A drag/drop can finish on mouse-down. Never rearm the secure
        -- action while the left button is still held: mouse-up would cast.
        if IsMouseButtonDown and IsMouseButtonDown("LeftButton") then return end
        self:SetScript("OnUpdate",nil)
        self._mixolasRestoreQueued=nil
        if not api.IsInCombat() then
            if self.isCustom then
                local entry=api.GetDB().customActions[tostring(self.slot)]
                self:SetAttribute("type",entry and entry.kind or nil)
            else self:SetAttribute("type","action") end
        end
        if self.pressedShade then self.pressedShade:Hide() end
        self._mixolasSuppressClick=false
        self._mixolasDropHandled=false
    end)
end
local function makeButton(parent,barNo,j)
    local isExtra = barNo >= 7
    local origin=({[1]=0,[2]=60,[3]=48,[4]=24,[5]=36,[6]=12})[barNo]
    local slot = isExtra and (200 + (barNo-7)*12+j) or origin+j
    local b=CreateFrame("Button","MixolasBarsRegularBar"..barNo.."Button"..j,parent,"SecureActionButtonTemplate")
    b.actionSlot=isExtra and nil or slot
    b.slot=slot
    b.isCustom=isExtra
    b.barNumber=barNo
    b.barIndex=j
    b.bindId=32+(barNo-1)*12+j
    if not isExtra then
        b:SetAttribute("type","action")
        b:SetAttribute("action",slot)
    end
    local keyDown = GetCVarBool and GetCVarBool("ActionButtonUseKeyDown")
    if keyDown == nil and GetCVar then keyDown = GetCVar("ActionButtonUseKeyDown") ~= "0" end
    -- Up-only secure clicks are intentional: beginning an icon drag cannot cast.
    b:SetAttribute("useOnKeyDown",false)
    b:RegisterForClicks("AnyDown","AnyUp")
    b:RegisterForDrag("LeftButton")
    b:SetScript("OnDragStart",function(self)
        if api.IsInCombat() or not api.GetDB().locked then return end
        suppressActionForDrag(self)
        if api.GetDB().buttonLock then return end
        -- Keep all empty targets visible even while PickupAction momentarily
        -- removes the original icon. Shared with diamonds.
        if api.BeginActionDrag then api.BeginActionDrag(self) end
        if self.isCustom then
            local entry=api.GetDB().customActions[tostring(self.slot)]
            if entry then
                setExtra(self,nil)
                cursorPickup(entry)
            end
            return
        end
        if not PickupAction then return end
        if not HasAction or HasAction(self:GetAttribute("action") or self.actionSlot) then
            local fromSlot=self:GetAttribute("action") or self.actionSlot
            api.RecordDragSource(fromSlot)
            PickupAction(fromSlot)
            updateButtonIcon(self)
            if api.RefreshCooldown then api.RefreshCooldown(self) end
        end
    end)
    b:SetScript("OnDragStop",finishActionDrag)
    local function dropAction(self)
        if api.IsInCombat() or not GetCursorInfo or not GetCursorInfo() then return end
        suppressActionForDrag(self)
        if self._mixolasDropHandled then return end
        self._mixolasDropHandled=true
        if api.NoteCursorPlacement then api.NoteCursorPlacement(self) end
        if self.isCustom then
            local incoming=cursorEntry()
            if incoming then
                local previous=api.GetDB().customActions[tostring(self.slot)]
                if ClearCursor then ClearCursor() end
                setExtra(self,incoming)
                if previous then cursorPickup(previous) end
            end
        elseif PlaceAction then
            local dst=self:GetAttribute("action") or self.actionSlot
            PlaceAction(dst)
            -- Blizzard leaves the displaced spell on the cursor.
        end
        api.ClearDragSource()
        updateButtonIcon(self)
        if api.RefreshCooldown then api.RefreshCooldown(self) end
        if api.RefreshIcons then api.RefreshIcons() end
        if C_Timer and C_Timer.After then
            C_Timer.After(0,function()
                if api.RefreshIcons then api.RefreshIcons() end
                if api.RefreshRegularActionIcons then api.RefreshRegularActionIcons() end
            end)
        end
        finishActionDrag(self)
    end
    b._mixolasReceiveCursor=dropAction
    b:SetScript("OnReceiveDrag",dropAction)
    b:SetScript("OnMouseDown",function(self)
        if feedback.Press then feedback.Press(self,true) end
    end)
    b:SetScript("OnMouseUp",function(self)
        if feedback.Press then feedback.Press(self,false) end
        finishActionDrag(self)
    end)
    b:SetScript("PreClick",function(self,which,isDown)
        if feedback.Press then feedback.Press(self,isDown) end
        if not api.IsInCombat() and GetCursorInfo and GetCursorInfo() then
            dropAction(self)
        elseif self._mixolasSuppressClick and not api.IsInCombat() then
            self:SetAttribute("type",nil)
        end
    end)
    b:SetScript("PostClick",function(self,which,isDown)
        -- The shared feedback driver fades after release.
        if not api.IsInCombat() and self._mixolasSuppressClick then
            self:SetAttribute("type",nil)
            finishActionDrag(self)
        end
    end)
    local bg=b:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.06,0.10,0.14,0.9)
    b.base=bg
    local press=b:CreateTexture(nil,"OVERLAY")
    press:SetAllPoints(b)
    press:SetColorTexture(0.02,0.03,0.05,0.50)
    press:Hide()
    b.pressedShade=press
    b.icon=b:CreateTexture(nil,"ARTWORK")
    b.icon:SetPoint("TOPLEFT",2,-2)
    b.icon:SetPoint("BOTTOMRIGHT",-2,2)
    b.icon:SetTexCoord(0.08,0.92,0.08,0.92)
    local border=b:CreateTexture(nil,"OVERLAY")
    border:SetPoint("TOPLEFT",0,0)
    border:SetPoint("BOTTOMRIGHT",0,0)
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetTexCoord(0.18,0.82,0.18,0.82)
    b.hotkeyText=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    b.hotkeyText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 8, "OUTLINE")
    b.hotkeyText:SetPoint("TOPRIGHT",b,"TOPRIGHT",-2,-2)
    b.hotkeyText:SetWidth(38)
    b.hotkeyText:SetJustifyH("RIGHT")
    b.hotkeyText:SetShadowOffset(1,-1)
    b.hotkeyText:SetShadowColor(0,0,0,1)
    b.countText=b:CreateFontString(nil,"OVERLAY","NumberFontNormalSmall")
    b.countText:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-2,2)
    b.countText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",8,"OUTLINE")
    b.macroText=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    b.macroText:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",7,"OUTLINE")
    b.macroText:SetPoint("BOTTOMLEFT",b,"BOTTOMLEFT",3,3)
    b.macroText:SetWidth(25)
    b.macroText:SetJustifyH("LEFT")
    if b.macroText.SetWordWrap then b.macroText:SetWordWrap(false) end
    if b.macroText.SetMaxLines then b.macroText:SetMaxLines(1) end
    b.macroText:SetShadowOffset(1,-1)
    b.macroText:SetShadowColor(0,0,0,1)
    b.macroText:SetText("")
    b.cooldown=CreateFrame("Cooldown",nil,b,"CooldownFrameTemplate")
    b.cooldown:SetAllPoints(b.icon)
    if b.cooldown.SetHideCountdownNumbers then b.cooldown:SetHideCountdownNumbers(true) end
    -- Match the face-button diamond cooldown typography exactly.
    -- This is presentation-only; safeCooldown owns the numeric content.
    b.cooldownNumber=b:CreateFontString(nil,"OVERLAY","NumberFontNormal")
    b.cooldownNumber:SetPoint("CENTER",b,"CENTER",0,0)
    b.cooldownNumber:SetText("")
    -- Blizzard's number font, not the body text font.
    b.cooldownNumber:SetTextColor(1,1,1,1)
    b.cooldownNumber:SetShadowColor(0,0,0,1)
    b.cooldownNumber:SetShadowOffset(1,-1)
    -- Keep the digits above the radial wheel and Warlord textures.
    local numberLayer=CreateFrame("Frame",nil,b)
    numberLayer:SetAllPoints(b)
    numberLayer:SetFrameLevel(b.cooldown:GetFrameLevel()+3)
    b.cooldownNumber:SetParent(numberLayer)
    b._mxbCooldownLabelLayer=numberLayer
    b:SetScript("OnEnter",function(self)
        if GameTooltip and GameTooltip.SetAction then
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            GameTooltip:SetAction(self:GetAttribute("action") or self.actionSlot)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
    updateButtonIcon(b)
    if api.MakeBindingProxy then api.MakeBindingProxy(b) end
    api.AddRegularButton(b)
    regularButtons[#regularButtons+1]=b
    return b
end
local function createBar(n)
    local frame=CreateFrame("Frame","MixolasBarsRegularBar"..n,UIParent)
    frame:SetMovable(true)
    -- Screen-edge clamping is handled by DragController using the scaled
    -- visual dimensions. Native frame clamping can double-limit bottom reach.
    frame:SetClampedToScreen(false)
    frame._mixolasEdgeFree = true -- allow precise positioning against UI edges
    frame:SetFrameStrata("MEDIUM")
    frame.buttons={}
    for j=1,12 do
        frame.buttons[j]=makeButton(frame,n,j)
        if n>=7 then
            local stored=api.GetDB().customActions[tostring(frame.buttons[j].slot)]
            if stored then setExtra(frame.buttons[j],stored) end
        end
    end
    if n==1 and RegisterStateDriver and SecureCmdOptionParse then
        local state=api.GetPageState()
        local initial=tonumber(SecureCmdOptionParse(state)) or 1
        local pager=CreateFrame("Frame","MixolasBarsRegularMainPager",UIParent,"SecureHandlerStateTemplate")
        for j=1,12 do
            local btn=frame.buttons[j]
            btn:SetAttribute("action",(initial-1)*12+j)
            pager:SetFrameRef("action"..j,btn)
            if btn.keyProxy then pager:SetFrameRef("key"..j,btn.keyProxy) end
        end
        pager:SetAttribute("_onstate-page", [[
            -- Runs in the secure environment even while the player is in combat.
            local p=tonumber(newstate) or 1
            if p < 1 or p > 11 then p=1 end
            for j=1,12 do
                local action=(p-1)*12+j
                local b=self:GetFrameRef("action"..j)
                if b then b:SetAttribute("action",action) end
                local proxy=self:GetFrameRef("key"..j)
                if proxy then proxy:SetAttribute("action",action) end
            end
        ]])
        -- The secure driver is authoritative for the action IDs.  Native
        -- ACTIONBAR_PAGE_CHANGED is not reliable on the October 2026 beta.
        -- Refresh visuals after the driver has updated BOTH buttons and proxies.
        -- Hook, NEVER replace: SecureHandlerStateTemplate owns the original
        -- OnAttributeChanged handler that executes _onstate-page.
        pager:HookScript("OnAttributeChanged",function(self,attribute)
            if attribute == "state-page" then
                if api.RefreshRegularActionIcons then api.RefreshRegularActionIcons() end
            end
        end)
        RegisterStateDriver(pager,"page",state)
        frame.pager=pager
    end
    local handle=CreateFrame("Button",nil,frame)
    handle:SetPoint("BOTTOM",frame,"TOP",0,6)
    handle:SetSize(170,21)
    handle:RegisterForDrag("LeftButton")
    local tex=handle:CreateTexture(nil,"BACKGROUND")
    tex:SetAllPoints()
    tex:SetColorTexture(0.08,0.15,0.22,0.94)
    local text=handle:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    text:SetAllPoints()
    text:SetText(n==1 and "BAR 1 / STANCE" or (n==2 and "BAR 2" or ("BAR "..n)))
    -- All movement now comes from the whole-bar mask, not a top-edge label.
    handle:Hide()
    frame.handle=handle
    local mask=CreateFrame("Button",nil,frame)
    mask:SetAllPoints(frame)
    mask:SetFrameLevel(frame:GetFrameLevel()+30)
    mask:EnableMouse(true)
    mask:RegisterForDrag("LeftButton")
    local wash=mask:CreateTexture(nil,"BACKGROUND")
    wash:SetAllPoints(mask)
    wash:SetColorTexture(0.22,0.55,1,0.30)
    local caption=mask:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    caption:SetPoint("CENTER",mask,"CENTER",0,0)
    caption:SetJustifyH("CENTER")
    caption:SetText(n==1 and "BAR 1 / STANCE" or "BAR "..n)
    caption:SetTextColor(1,1,1,1)
    caption:SetShadowOffset(1,-1)
    caption:SetShadowColor(0,0,0,1)
    mask.caption=caption
    mask:SetScript("OnDragStart",function()
        if api.BeginLayoutDrag then api.BeginLayoutDrag(frame,api.GetDB().regularBars[n]) end
    end)
    mask:SetScript("OnDragStop",function()
        if api.EndLayoutDrag then api.EndLayoutDrag(frame) end
    end)
    mask:Hide()
    frame.editMask=mask
    return frame
end
api.GetRegularBars=function() return bars end
api.DockRegularBar=function(n,side)
    if api.IsInCombat() or not bars[n] then return false end
    local data=api.GetDB().regularBars[n]
    if not data or RESERVED[n] or not data.enabled then return false end
    local frame=bars[n]
    local factor=math.max(frame:GetEffectiveScale()/math.max(UIParent:GetEffectiveScale(),0.001),0.001)
    local hw=math.min(UIParent:GetWidth()/2,frame:GetWidth()*factor/2)
    local hh=math.min(UIParent:GetHeight()/2,frame:GetHeight()*factor/2)
    -- SetPoint offsets are in frame-local units.  The desired edge location
    -- is in UIParent units, so divide by relative scale before saving.
    if side=="BOTTOM" then data.y=(-UIParent:GetHeight()/2+hh)/factor
    elseif side=="TOP" then data.y=(UIParent:GetHeight()/2-hh)/factor
    elseif side=="LEFT" then data.x=(-UIParent:GetWidth()/2+hw)/factor
    elseif side=="RIGHT" then data.x=(UIParent:GetWidth()/2-hw)/factor
    else return false end
    redraw(n)
    return true
end
api.SetRegularBar=function(n,key,value)
    if api.IsInCombat() or n<1 or n>BAR_COUNT
        or (barDefaults[key]==nil and key~="alphaOut" and key~="alphaCombat") then return false end
    -- Never expose an extra traditional copy of slots owned by diamonds.
    if RESERVED[n] then return false end
    local c=api.GetDB().regularBars[n]
    if key=="enabled" or key=="showGrid" then c[key]=not not value
    elseif key=="count" then c.count=clamp(math.floor(value),0,12)
    elseif key=="rows" then c.rows=clamp(math.floor(value),1,12)
    elseif key=="scale" then c.scale=clamp(value,0.35,2)
    elseif key=="alpha" then
        -- Legacy single-opacity setter updates both states.
        c.alpha=clamp(value,0.1,1)
        c.alphaOut=c.alpha
        c.alphaCombat=c.alpha
    elseif key=="alphaOut" then
        c.alphaOut=clamp(value,0.1,1)
        c.alpha=c.alphaOut
    elseif key=="alphaCombat" then c.alphaCombat=clamp(value,0.1,1)
    elseif key=="padding" then c.padding=clamp(value,0,25)
    else c[key]=value end
    redraw(n)
    return true
end
api.RefreshRegularBars=redraw
api.RefreshRegularCombatOpacity=refreshCombatOpacity
api.RefreshRegularEmptyVisibility=refreshRegularEmptyVisibility
api.GetBar1PagingDiagnostics=function()
    local frame=bars[1]
    local pager=frame and frame.pager
    local _,class=UnitClass and UnitClass("player")
    local form=GetShapeshiftForm and GetShapeshiftForm() or "?"
    local expected=SecureCmdOptionParse and SecureCmdOptionParse(api.GetPageState()) or "?"
    local applied=pager and pager:GetAttribute("state-page") or "?"
    local button=frame and frame.buttons and frame.buttons[1]
    local proxy=button and button.keyProxy
    local action=button and button:GetAttribute("action") or "?"
    local proxyAction=proxy and proxy:GetAttribute("action") or "?"
    return class or "?",form,expected,applied,action,proxyAction
end
api.RefreshRegularActionIcons=function()
    for _,b in ipairs(regularButtons) do
        updateButtonIcon(b)
        if api.RefreshCooldown then api.RefreshCooldown(b) end
    end
    refreshRegularEmptyVisibility()
end
-- Saved restore points can change per-character extra action assignments.
-- Refresh secure attributes outside combat rather than just icon textures.
api.RefreshCustomActions=function()
    if api.IsInCombat() then return false end
    local custom=api.GetDB() and api.GetDB().customActions or {}
    for _,b in ipairs(regularButtons) do
        if b.isCustom then setExtra(b,custom[tostring(b.slot)]) end
    end
    return true
end
api.RefreshRegularHandles=function()
    local db=api.GetDB()
    if not db then return end
    for n,frame in ipairs(bars) do
        local c=db.regularBars and db.regularBars[n]
        if frame and frame.handle and c then
            frame.handle:SetShown(false)
            if frame.editMask then frame.editMask:SetShown(not db.locked and db.visible and c.enabled and not RESERVED[n]) end
        end
    end
end
api.IsRegularReserved=function(n) return not not RESERVED[n] end
local e=CreateFrame("Frame")
e:RegisterEvent("PLAYER_LOGIN")
e:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
e:RegisterEvent("UPDATE_MACROS")
e:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
e:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
e:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
e:RegisterEvent("UPDATE_BINDINGS")
e:RegisterEvent("PLAYER_REGEN_DISABLED")
e:RegisterEvent("PLAYER_REGEN_ENABLED")
e:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        copyDefaults(api.GetDB())
        for n=1,BAR_COUNT do bars[n]=createBar(n) end
        redraw()
    elseif event=="PLAYER_REGEN_DISABLED" then
        refreshCombatOpacity(true)
    elseif event=="PLAYER_REGEN_ENABLED" then
        refreshCombatOpacity(false)
    else
        for _,b in ipairs(regularButtons) do updateButtonIcon(b) end
        if event=="ACTIONBAR_SLOT_CHANGED" or event=="UPDATE_MACROS" or event=="ACTIONBAR_PAGE_CHANGED"
            or event=="UPDATE_SHAPESHIFT_FORM" or event=="UPDATE_BONUS_ACTIONBAR" then
            refreshRegularEmptyVisibility()
        end
        if event=="UPDATE_BINDINGS" then api.RefreshHotkeys() end
    end
end)
