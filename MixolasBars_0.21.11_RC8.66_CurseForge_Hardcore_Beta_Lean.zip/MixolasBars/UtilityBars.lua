-- Mixolas Bars: independent, opt-in native UI group positioning for Classic Era.
-- Does not duplicate protected Blizzard spells or buttons; moves the existing objects
-- only outside combat and can restore their original parent/anchors.
local api = _G.MixolasBarsAPI
if not api then return end
local items = {
    {id="pet", title="Pet Bar", names={"PetActionButton1","PetActionButton2","PetActionButton3","PetActionButton4","PetActionButton5","PetActionButton6","PetActionButton7","PetActionButton8","PetActionButton9","PetActionButton10"}, width=10},
}
local anchors, saved = {}, {}
-- Keep the managed holder visible whenever enabled. Blizzard's native pet
-- buttons handle their own availability. Hiding the parent based on
-- PetHasActionBar() hid buttons, decorations and the layout drag handle on
-- clients where that API temporarily returns false during pet transitions.
-- Do not install a secure state driver on this ordinary (nonsecure) holder.
local function hasActivePetBar()
    if type(PetHasActionBar)=="function" then
        local ok,active=pcall(PetHasActionBar)
        if ok and active then return true end
    end
    if type(UnitExists)=="function" then
        local ok,present=pcall(UnitExists,"pet")
        if ok and present then return true end
    end
    return false
end
local function key(c) return c.id end
local function defaults(db)
    db.utilityBars = db.utilityBars or {}
    for index,c in ipairs(items) do
        local s=db.utilityBars[c.id]
        if type(s) ~= "table" then s={} db.utilityBars[c.id]=s end
        if s.enabled==nil then s.enabled=false end
        if s.visible==nil then s.visible=true end
        if s.scale==nil then s.scale=1 end
        if s.alpha==nil then s.alpha=1 end
        -- Existing pet bars inherit their current opacity in BOTH states.
        if s.alphaOut==nil then s.alphaOut=math.max(0.1,math.min(1,tonumber(s.alpha) or 1)) end
        if s.alphaCombat==nil then s.alphaCombat=math.max(0.1,math.min(1,tonumber(s.alpha) or 1)) end
        if s.x==nil then s.x=(index-3.5)*55 end
        if s.y==nil then s.y=230 end
        if s.padding==nil then s.padding=2 end
        if s.rows==nil then s.rows=1 end
    end
end
-- Pure helper: produce a clean per-profile utility bar configuration.
api.GetDefaultUtilityBarLayout=function()
    local fresh={}
    defaults(fresh)
    return fresh.utilityBars
end
local function remember(frame)
    if saved[frame] then return end
    local c={parent=frame:GetParent(), scale=frame:GetScale(), alpha=frame:GetAlpha(),points={}}
    for k=1,frame:GetNumPoints() do
        local point,relative,relativePoint,x,y=frame:GetPoint(k)
        c.points[k]={point,relative,relativePoint,x,y}
    end
    saved[frame]=c
end
local function restore(frame)
    local s=saved[frame]
    if not s then return end
    frame:SetParent(s.parent)
    frame:ClearAllPoints()
    for _,a in ipairs(s.points) do frame:SetPoint(unpack(a)) end
    frame:SetScale(s.scale)
    frame:SetAlpha(s.alpha)
    saved[frame]=nil
end
local function ensureAnchor(c)
    if anchors[c.id] then return anchors[c.id] end
    local holder=CreateFrame("Frame","MixolasBarsUtility"..c.id,UIParent)
    holder:SetSize(c.wide and 440 or math.min(c.width,11)*39,38)
    holder:SetMovable(true)
    holder:SetClampedToScreen(false)
    holder._mixolasEdgeFree = true -- same docking/grid as diamonds and action bars
    holder:SetFrameStrata("MEDIUM")
    local drag=CreateFrame("Button",nil,holder)
    drag:SetPoint("BOTTOM",holder,"TOP",0,5)
    drag:SetSize(135,20)
    drag:RegisterForDrag("LeftButton")
    local back=drag:CreateTexture(nil,"BACKGROUND")
    back:SetAllPoints(); back:SetColorTexture(0.12,0.21,0.31,0.9)
    local label=drag:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    label:SetAllPoints();label:SetText("MOVE "..c.title:upper())
    -- The utility (pet) bar uses the same drag controller as every other
    -- action bar. Native StartMoving bypassed the user's Snap to Grid choice.
    drag:SetScript("OnDragStart",function()
        if api.BeginLayoutDrag then
            api.BeginLayoutDrag(holder,api.GetDB().utilityBars[c.id])
        end
    end)
    drag:SetScript("OnDragStop",function()
        if api.EndLayoutDrag then api.EndLayoutDrag(holder) end
    end)
    holder.handle=drag
    holder:Hide()
    anchors[c.id]=holder
    return holder
end
local function utilityOpacity(config,inCombat)
    local value=tonumber(inCombat and config.alphaCombat or config.alphaOut)
        or tonumber(config.alpha) or 1
    return math.max(0.1,math.min(1,value))
end
-- Update only the unprotected parent holder alpha on combat transitions;
-- native pet buttons remain attached, clickable, and secure.
local function refreshUtilityCombatOpacity(forceInCombat)
    local db=api.GetDB()
    if not db then return false end
    local combat=forceInCombat
    if combat==nil then combat=api.IsInCombat() end
    for _,c in ipairs(items) do
        local config=db.utilityBars and db.utilityBars[c.id]
        local holder=anchors[c.id]
        if holder and config and config.enabled then
            pcall(holder.SetAlpha,holder,utilityOpacity(config,combat))
        end
    end
    return true
end
local function refresh(onlyId)
    if api.IsInCombat() or not api.GetDB() then return false end
    local db=api.GetDB()
    defaults(db)
    for _,c in ipairs(items) do
      if not onlyId or c.id == onlyId then
        local s=db.utilityBars[c.id]
        local holder=ensureAnchor(c)
        local available={}
        for _,name in ipairs(c.names) do
            local frame=_G[name]
            if frame then available[#available+1]=frame end
        end
        if s.enabled and #available>0 then
            local pad=s.padding
            if c.wide then holder:SetSize(460,34)
            else
                local rows=math.max(1,math.min(10,s.rows or 1))
                local cols=math.ceil(#available/rows)
                holder:SetSize(cols*36+math.max(0,cols-1)*pad,rows*36+math.max(0,rows-1)*pad)
            end
            holder:ClearAllPoints()
            holder:SetPoint("CENTER",UIParent,"CENTER",s.x,s.y)
            holder:SetScale(s.scale)
            holder:SetAlpha(utilityOpacity(s,api.IsInCombat()))
            -- Only draw the pet holder, native buttons and attached decoration
            -- while the client reports an active pet bar.  Keep management
            -- ENABLED when no pet is out so it automatically returns on summon.
            -- Check both APIs to tolerate a transient PetHasActionBar() false.
            local present=hasActivePetBar()
            holder:SetShown(s.visible and present)
            holder.handle:SetShown(not db.locked and db.visible and s.visible and present)
            for i,frame in ipairs(available) do
                remember(frame)
                frame:SetParent(holder)
                frame:ClearAllPoints()
                if c.wide then
                    frame:SetPoint("CENTER",holder,"CENTER",0,0)
                else
                    local rows=math.max(1,math.min(10,s.rows or 1))
                    local col=math.floor((i-1)/rows)
                    local row=(i-1)%rows
                    frame:SetPoint("TOPLEFT",holder,"TOPLEFT",col*(36+pad),-row*(36+pad))
                end
                frame:SetScale(1)
                frame:SetAlpha(1)
            end
        else
            for _,frame in ipairs(available) do restore(frame) end
            holder:Hide()
        end
      end
    end
    return true
end
-- Frame Studio attaches cosmetics to this existing holder only while Mixolas
-- manages the native pet buttons. No new secure buttons are created.
api.GetManagedPetBarHost=function()
    local db=api.GetDB and api.GetDB()
    local config=db and db.utilityBars and db.utilityBars.pet
    return config and config.enabled and anchors.pet or nil
end
api.UtilityCatalog=items
api.RefreshUtilityBars=refresh
api.RefreshUtilityCombatOpacity=refreshUtilityCombatOpacity
api.RefreshUtilityHandles=function()
    local db=api.GetDB()
    if not db then return end
    for _,c in ipairs(items) do
        local h=anchors[c.id]
        local opts=db.utilityBars and db.utilityBars[c.id]
        if h and h.handle and opts then
            h.handle:SetShown(not db.locked and db.visible and opts.enabled and opts.visible
                and (c.id~="pet" or hasActivePetBar()))
        end
    end
end
-- Pet events must not reparent protected native buttons. The presence
-- update only shows/hides the ordinary managed holder OUTSIDE combat.  Frame
-- Studio artwork and native buttons are its children, so they disappear as
-- one group on dismiss and reappear without rebuilding on summon.
local function refreshPetPresence()
    local db=api.GetDB()
    local opts=db and db.utilityBars and db.utilityBars.pet
    local holder=anchors.pet
    if not opts or not holder or not opts.enabled or api.IsInCombat()
        or (InCombatLockdown and InCombatLockdown()) then return end
    local shown=opts.visible and hasActivePetBar()
    holder:SetShown(shown)
    if holder.handle then
        holder.handle:SetShown(not db.locked and db.visible and shown)
    end
end
local function schedulePresenceRefresh()
    refreshPetPresence()
    -- The pet unit and PetHasActionBar may update in different client frames.
    -- Recheck after the event rather than leaving a briefly empty holder up.
    if C_Timer and C_Timer.After then
        C_Timer.After(0.12,refreshPetPresence)
        C_Timer.After(0.40,refreshPetPresence)
    end
end
api.SetUtilityBar=function(id,field,value)
    if api.IsInCombat() or not api.IsReady() then return false end
    if not ({enabled=true,visible=true,scale=true,alpha=true,alphaOut=true,alphaCombat=true,padding=true,rows=true})[field] then return false end
    local db=api.GetDB(); defaults(db)
    local s=db.utilityBars[id]
    if not s then return false end
    if field=="enabled" or field=="visible" then s[field]=not not value
    elseif field=="scale" then s.scale=math.max(0.4,math.min(2,value))
    elseif field=="alpha" then
        s.alpha=math.max(0.1,math.min(1,value))
        s.alphaOut=s.alpha
        s.alphaCombat=s.alpha
    elseif field=="alphaOut" then
        s.alphaOut=math.max(0.1,math.min(1,value))
        s.alpha=s.alphaOut -- retain legacy profile/import readability
    elseif field=="alphaCombat" then
        s.alphaCombat=math.max(0.1,math.min(1,value))
    elseif field=="rows" then s.rows=math.max(1,math.min(10,math.floor(value)))
    else s.padding=math.max(0,math.min(16,math.floor(value))) end
    local changed=refresh(id)
    if id=="pet" and api.RefreshFrameStudio then api.RefreshFrameStudio(false) end
    return changed
end
local event=CreateFrame("Frame")
event:RegisterEvent("PLAYER_LOGIN")
event:RegisterEvent("PLAYER_ENTERING_WORLD")
event:RegisterEvent("PLAYER_REGEN_ENABLED")
event:RegisterEvent("PLAYER_REGEN_DISABLED")
event:RegisterEvent("UNIT_PET")
event:RegisterEvent("PET_BAR_UPDATE")
event:RegisterEvent("PET_UI_UPDATE")
event:SetScript("OnEvent",function(_,e,unit)
    if e=="PLAYER_LOGIN" then
        defaults(api.GetDB())
        refresh()
        schedulePresenceRefresh()
    elseif e=="PLAYER_ENTERING_WORLD" then
        schedulePresenceRefresh()
    elseif e=="PLAYER_REGEN_DISABLED" then
        refreshUtilityCombatOpacity(true)
    elseif e=="PLAYER_REGEN_ENABLED" then
        refresh() -- safe outside combat; reapplies the out-of-combat alpha
        refreshUtilityCombatOpacity(false)
        schedulePresenceRefresh()
    elseif e=="PET_BAR_UPDATE" or e=="PET_UI_UPDATE" or (e=="UNIT_PET" and unit=="player") then
        schedulePresenceRefresh()
    end
end)
