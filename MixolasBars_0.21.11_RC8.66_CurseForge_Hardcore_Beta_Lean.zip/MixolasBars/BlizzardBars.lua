-- Mixolas Bars: default-on Blizzard action-button and artwork suppression.
-- These toggles are independent. Never reparent MainMenuBar or its ArtFrame:
-- they may also contain UI that the user manages with Blizzard's editor.
local hiddenParent=CreateFrame("Frame","MixolasBarsHiddenNativeButtons",UIParent)
hiddenParent:Hide()
-- In Classic Era 1.15.9 (including Hardcore), Blizzard Edit Mode owns the
-- native protected action frames. Avoid reparenting them: moving them to a
-- hidden parent can poison native Edit Mode/action paging on this client.
-- Reversible hiding and mouse disabling are applied out of combat, with
-- alpha suppression as an additional fallback if native visibility is forced.
local classicEra = WOW_PROJECT_ID and WOW_PROJECT_CLASSIC
    and WOW_PROJECT_ID == WOW_PROJECT_CLASSIC
local buttonHidden,artHidden=false,false
local buttonRecords,artRecords,barRecords={},{},{}
local actionNames={
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarRightButton", "MultiBarLeftButton", "MultiBar5Button",
    "MultiBar6Button", "MultiBar7Button", "MultiBar8Button",
    "MultiBar9Button", "MultiBar10Button", "MultiBar11Button",
    "MultiBar12Button", "MultiBar13Button", "MultiBar14Button", "MultiBar15Button",
}
-- Individual native buttons are hidden as well as alpha suppressed. Classic
-- Edit Mode may recreate their mouse targets, so disable mouse interaction and
-- suppress the dedicated native bar frames where safe. Do NOT hide
-- MainMenuBar: it owns bags, micro menu, XP widgets and other UI elements.
local nativeBarContainers={
    "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft",
    "MultiBar5", "MultiBar6", "MultiBar7", "MultiBar8", "MultiBar9",
    "MultiBar10", "MultiBar11", "MultiBar12", "MultiBar13", "MultiBar14", "MultiBar15",
}
local artNames={
    "MainMenuBarPageNumber", "MainMenuBarLeftEndCap", "MainMenuBarRightEndCap",
    "MainMenuBarArtFrameBackground", "MainMenuBarArtFrameBorder",
    "MainMenuBarTexture0", "MainMenuBarTexture1", "MainMenuBarTexture2", "MainMenuBarTexture3",
    "MainMenuBarArtFrameTexture0", "MainMenuBarArtFrameTexture1",
    "MainMenuBarArtFrameTexture2", "MainMenuBarArtFrameTexture3",
    "MainMenuBarBackground", "MainMenuBarBorder",
    "ActionBarUpButton", "ActionBarDownButton",
}
local artFields={"LeftEndCap","RightEndCap","Background","BorderArt","LeftArt","RightArt","Art","NineSlice"}
local function safeCall(obj,name,...)
    if not obj or type(obj[name])~="function" then return false end
    return pcall(obj[name],obj,...)
end
local function hideObject(obj,records,allowReparent,disableInteraction)
    if not obj or (type(obj)~="table" and type(obj)~="userdata") or not obj.GetParent then return end
    local old=records[obj]
    if not old then
        local ok,parent=pcall(obj.GetParent,obj)
        local alpha=1
        if obj.GetAlpha then local r,v=pcall(obj.GetAlpha,obj); if r and type(v)=="number" then alpha=v end end
        local shown,mouse
        if obj.IsShown then local s,v=pcall(obj.IsShown,obj); if s then shown=v end end
        if obj.IsMouseEnabled then local s,v=pcall(obj.IsMouseEnabled,obj); if s then mouse=v end end
        old={parent=ok and parent or nil,alpha=alpha,shown=shown,mouse=mouse}
        records[obj]=old
    end
    -- Native action buttons are protected; their normal mouse/key handling is
    -- preserved by relocating them to a hidden parent only when WoW permits it.
    if allowReparent and not classicEra then
        local ok,currentParent=pcall(obj.GetParent,obj)
        if not ok or currentParent~=hiddenParent then
            local success=safeCall(obj,"SetParent",hiddenParent)
            if success then old.parentMoved=true end
        end
    end
    -- Artwork: suppress the texture itself rather than its entire ancestor;
    -- hiding an ancestor can also hide Blizzard bags/micro/XP widgets.
    -- Also alpha-hide a reparented button: Forever's Edit Mode can restore
    -- native button parents during layout updates. Reapply alpha when needed.
    local currentAlpha
    if obj.GetAlpha then
        local ok,a=pcall(obj.GetAlpha,obj)
        if ok then currentAlpha=a end
    end
    if currentAlpha~=0 then
        if safeCall(obj,"SetAlpha",0) then old.alphaChanged=true
        elseif not old.parentMoved and safeCall(obj,"Hide") then old.hidden=true end
    end
    if disableInteraction then
        -- Invisible native buttons must not still accept mouseover, drag or
        -- clicks. Native key routing remains available through Mixolas.
        if old.mouse~=false and safeCall(obj,"EnableMouse",false) then
            old.mouseChanged=true
        end
        if old.shown~=false and safeCall(obj,"Hide") then
            old.hidden=true
        end
    end
end
local function restore(records)
    for obj,old in pairs(records) do
        if old.parentMoved and old.parent then safeCall(obj,"SetParent",old.parent) end
        if old.alphaChanged then safeCall(obj,"SetAlpha",old.alpha or 1) end
        if old.mouseChanged and old.mouse~=nil then safeCall(obj,"EnableMouse",old.mouse) end
        if old.hidden and old.shown~=false then safeCall(obj,"Show") end
        records[obj]=nil
    end
end
local function applyButtons()
    if not buttonHidden then
        -- Restoring native bars also restores original click handling and
        -- initially hidden bar state. Nothing is permanently unregistered.
        restore(barRecords)
        restore(buttonRecords)
        return
    end
    for _,prefix in ipairs(actionNames) do
        for i=1,12 do
            hideObject(_G[prefix..i],buttonRecords,false,true)
        end
    end
    -- These frames are dedicated native action bars (not MainMenuBar).
    -- Suppressing them removes the selectable Edit Mode ghost outline. If
    -- Classic rejects a protected Hide, alpha/mouse suppression still applies.
    for _,name in ipairs(nativeBarContainers) do
        hideObject(_G[name],barRecords,false,true)
    end
end
local function addRegions(frame)
    if not frame or (type(frame)~="table" and type(frame)~="userdata") or not frame.GetRegions then return end
    local ok,regions=pcall(function()return {frame:GetRegions()} end)
    if not ok then return end
    for _,region in ipairs(regions) do
        local kind
        if region.GetObjectType then
            local success,k=pcall(region.GetObjectType,region)
            if success then kind=k end
        end
        if kind=="Texture" then hideObject(region,artRecords,false) end
    end
end
local function applyArt()
    if not artHidden then restore(artRecords);return end
    for _,name in ipairs(artNames) do hideObject(_G[name],artRecords,false) end
    -- Selectively suppress decorative textures. Do NOT suppress the parent.
    local frame=_G.MainMenuBarArtFrame
    if frame and (type(frame)=="table" or type(frame)=="userdata") then
        addRegions(frame)
        for _,field in ipairs(artFields) do
            local item=frame[field]
            if item then
                hideObject(item,artRecords,false)
                if field=="NineSlice" then addRegions(item) end
            end
        end
    end
    -- Some Classic versions draw the base art directly as texture regions of
    -- MainMenuBar, separate from the ArtFrame. Do not touch child frames.
    addRegions(_G.MainMenuBar)
    for _,name in ipairs({"MultiBarBottomLeft", "MultiBarBottomRight",
        "MultiBarLeft", "MultiBarRight", "MultiBar5", "MultiBar6",
        "MultiBar7", "MultiBar8", "MultiBar9", "MultiBar10"}) do
        addRegions(_G[name])
    end
end
local function setButtons(value)
    if InCombatLockdown and InCombatLockdown() then return false end
    buttonHidden=not not value
    applyButtons()
    return true
end
local function setArt(value)
    -- Blizzard owns decorative art through its Edit Mode. Retain the legacy
    -- API for older profiles/callers, but do not apply their saved art toggle.
    -- Always restore any previously altered art when safely out of combat.
    if InCombatLockdown and InCombatLockdown() then return false end
    artHidden=false
    applyArt()
    return true
end
local watcher=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED","EDIT_MODE_ENTER",
                       "EDIT_MODE_EXIT","EDIT_MODE_LAYOUTS_UPDATED"}) do
    pcall(watcher.RegisterEvent,watcher,e)
end
local function reapply()
    if InCombatLockdown and InCombatLockdown() then return end
    if buttonHidden then applyButtons() end
    if artHidden then applyArt() end
end
watcher:SetScript("OnEvent",function()
    reapply()
    if C_Timer and C_Timer.After then
        C_Timer.After(0.15,reapply)
        C_Timer.After(1.0,reapply)
    end
end)
local elapsed=0
watcher:SetScript("OnUpdate",function(_,dt)
    if not buttonHidden and not artHidden then return end
    elapsed=elapsed+(dt or 0)
    -- Classic Edit Mode can force native bars back into a visible state.
    -- Keep them hidden without tight per-frame polling.
    local editModeShown=(_G.EditModeManagerFrame and _G.EditModeManagerFrame.IsShown
        and _G.EditModeManagerFrame:IsShown()) or false
    if elapsed<(editModeShown and 0.4 or 2) then return end
    elapsed=0
    reapply()
end)
_G.MixolasBarsBlizzardVisibility={SetHiddenButtons=setButtons,SetHiddenArt=setArt,
    -- Legacy callers can still toggle both together, but the settings UI uses
    -- the independent functions above.
    SetHidden=function(value)
        if not setButtons(value) then return false end
        return setArt(value)
    end,
}
