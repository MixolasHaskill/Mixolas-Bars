-- Mixolas Bars v0.6: mouseover bindings + SavedVariables import/export.
-- All keys are user-selected; no hardcoded modifier families or defaults.
local api = _G.MixolasBarsAPI
if not api then return end

local MAX_BUTTONS, MAX_KEYS = 128, 3
local editing, hovered, pending, returnPanel = false, nil, nil, nil
local toolbar, status, keyboard, keyboardGuard, captureStatus, overlays, transfer, removeKeyButtons
-- Match Bartender4 / LibKeyBound: assigning an occupied key transfers it
-- immediately, with no modal or keyboard-focus transition during the press.
-- All edits remain staged until Save & Exit; Cancel discards the entire session.
local actionById={}
local nativeClearPending={} -- keyboard bindings staged for explicit removal on Save
local petBefore, petPending = nil, nil -- native BONUS ACTION bindings, session-only
-- Native pet hotkey labels are only visually suppressed while the binding
-- editor is open. Restore each exact previous alpha on every exit path.
local petNativeHotkeyAlpha={}
local PET_SLOTS=10
local function isPetSlot(id) return type(id)=="number" and id<=-1 and id>=-PET_SLOTS end
local function petCommand(slot) return "BONUSACTIONBUTTON"..tostring(-slot) end
local function capturePetKeys()
    local data={}
    for i=1,PET_SLOTS do
        data[i]={}
        if GetBindingKey then
            local keys={GetBindingKey("BONUSACTIONBUTTON"..i)}
            for _,key in ipairs(keys) do
                if type(key)=="string" and key~="" then
                    data[i][#data[i]+1]=key
                end
            end
        end
    end
    return data
end
local function copyPetKeys(src)
    local data={}
    for i=1,PET_SLOTS do
        data[i]={}
        for _,key in ipairs(src and src[i] or {}) do
            data[i][#data[i]+1]=key
        end
    end
    return data
end
local function removePetKey(key)
    for i=1,PET_SLOTS do
        local keys=petPending and petPending[i]
        if keys then
            for j=#keys,1,-1 do
                if keys[j]==key then table.remove(keys,j) end
            end
        end
    end
end
-- While editing, Blizzard still owns the actual pet bindings and their
-- HotKey font strings. Draw a temporary preview on top of each pet binding
-- overlay instead of writing native keybindings (or replacing native text)
-- before Save & Exit. The overlay disappears on Save, Cancel, or combat.
local function petPreviewLabel(key)
    if type(key)~="string" or key=="" then return "-" end
    -- Match the compact hotkey abbreviations on Mixolas action buttons.
    local compact=key:gsub("SHIFT%-", "S"):gsub("CTRL%-", "C"):gsub("ALT%-", "A")
        :gsub("MOUSEWHEELUP", "MWU"):gsub("MOUSEWHEELDOWN", "MWD")
        :gsub("BUTTON", "M"):gsub("%-", "")
    return compact
end
local function restorePetNativeHotkeys()
    for font,alpha in pairs(petNativeHotkeyAlpha) do
        if font and font.SetAlpha then font:SetAlpha(alpha) end
    end
    petNativeHotkeyAlpha={}
end
local function suppressPetNativeHotkeys()
    for _,entry in ipairs(overlays or {}) do
        local font=entry.petHotkey
        if font and entry.overlay and entry.overlay:IsShown()
            and font.GetAlpha and font.SetAlpha then
            if petNativeHotkeyAlpha[font]==nil then
                petNativeHotkeyAlpha[font]=font:GetAlpha()
            end
            font:SetAlpha(0)
        end
    end
end
local function refreshPetPreviews()
    if not editing or not petPending then return end
    for _,entry in ipairs(overlays or {}) do
        if entry.petIndex and entry.petPreview then
            local keys=petPending[entry.petIndex] or {}
            entry.petPreview:SetText(petPreviewLabel(keys[1]))
        end
    end
end
local function copyBindings(src)
    local out = {}
    if type(src) ~= "table" then return out end
    for slot, keys in pairs(src) do
        if type(keys) == "table" then
            out[tostring(slot)] = {}
            for i = 1, math.min(MAX_KEYS, #keys) do
                out[tostring(slot)][i] = keys[i]
            end
        end
    end
    return out
end
local function countBindings()
    local n = 0
    local map = api.GetDB() and api.GetDB().bindings or {}
    for _, keys in pairs(map) do
        if type(keys) == "table" and #keys > 0 then n = n + 1 end
    end
    return n
end
api.CountBoundButtons = countBindings

local function findPendingOwner(key,map)
    for id,keys in pairs(map or {}) do
        -- Bars 3/4/5 are diamond-owned action slots, not standalone
        -- binding targets. Ignore any obsolete regular-bar shortcuts saved
        -- by older releases; leave the SavedVariables intact for rollback.
        local number=tonumber(id)
        local regularBar=number and number>=33 and number<=128
            and (math.floor((number-33)/12)+1) or nil
        if regularBar~=3 and regularBar~=4 and regularBar~=5 and type(keys)=="table" then
            for _,k in ipairs(keys) do if k==key then return tonumber(id) end end
        end
    end
end
local function getKeyLabel(slot,map)
    if isPetSlot(slot) then
        local keys=petPending and petPending[-slot] or {}
        return #keys>0 and ("WoW: "..table.concat(keys," / ")) or "None"
    end
    local keys=map and map[tostring(slot)]
    local custom=(keys and #keys>0) and table.concat(keys," / ") or nil
    local b=actionById[slot]
    local native=b and api.GetNativeBindingKeys and api.GetNativeBindingKeys(b) or {}
    local effective={}
    for _,key in ipairs(native) do
        local owner=findPendingOwner(key,map)
        if not nativeClearPending[key] and (not owner or owner==slot) then
            effective[#effective+1]=key
        end
    end
    if custom and #effective>0 then
        return "Custom: "..custom.." | WoW: "..table.concat(effective," / ")
    end
    if custom then return "Custom: "..custom end
    if #effective>0 then return "WoW: "..table.concat(effective," / ") end
    return "None"
end
local function buttonLabel(id)
    id=tonumber(id)
    if isPetSlot(id) then return "Pet Bar / Button "..tostring(-id) end
    local action=id and actionById[id]
    if action and action.barNumber then
        return "Bar "..action.barNumber.." / Button "..action.barIndex
    end
    if id and id>=1 and id<=32 then
        return "Diamond "..math.ceil(id/4).." / Button "..(((id-1)%4)+1)
    end
    return "Button "..tostring(id or "?")
end
local function setStatus(message)
    if status then status:SetText(message) end
end
local function refreshSelectedText()
    if removeKeyButtons then
        local keys=isPetSlot(hovered) and petPending and petPending[-hovered]
            or (hovered and pending and pending[tostring(hovered)]) or {}
        for i,b in ipairs(removeKeyButtons) do
            local key=keys and keys[i]
            b:SetShown(editing and key~=nil)
            if key then b:SetText("Remove "..key.."  x") end
        end
    end
    if hovered then
        local button=actionById[hovered]
        local cmd=isPetSlot(hovered) and petCommand(hovered)
            or (button and api.GetNativeBindingCommand and api.GetNativeBindingCommand(button))
        local source=cmd and (" [Native source: "..cmd.."]") or " [Independent Mixolas action]"
        setStatus(buttonLabel(hovered) .. "  |  " .. getKeyLabel(hovered, pending)
          .. source .. "\nPress to add a key  |  Remove key below (no confirmation)  |  Esc clears all")
    else
        setStatus("Hover any action or pet button to edit its shortcuts.\nEsc clears the hovered slot (staged). Save commits; Cancel restores.")
    end
end
local function modifierPrefix()
    local p = ""
    if IsAltKeyDown and IsAltKeyDown() then p = p .. "ALT-" end
    if IsControlKeyDown and IsControlKeyDown() then p = p .. "CTRL-" end
    if IsShiftKeyDown and IsShiftKeyDown() then p = p .. "SHIFT-" end
    return p
end
local KEY_NAMES = {
    [" "]="SPACE", ["-"]="MINUS", ["="]="EQUALS", [","]="COMMA",
    ["."]="PERIOD", ["/"]="SLASH", ["\\"]="BACKSLASH", [";"]="SEMICOLON",
    ["'"]="APOSTROPHE", ["["]="LBRACKET", ["]"]="RBRACKET", ["`"]="GRAVE",
    ["+"]="PLUS", ["\t"]="TAB",
}
local MODIFIERS = {
    LSHIFT=true,RSHIFT=true,LSHIFTKEY=true,RSHIFTKEY=true,SHIFT=true,
    LCTRL=true,RCTRL=true,LALT=true,RALT=true,CTRL=true,ALT=true,
    LCONTROL=true,RCONTROL=true,LMETA=true,RMETA=true,
}
local function normalizeKey(key)
    if type(key) ~= "string" or key == "" then return nil end
    key = KEY_NAMES[key] or string.upper(key)
    if MODIFIERS[key] or key=="UNKNOWN" then return nil end
    -- KeyBound blocks unmodified primary mouse buttons to avoid making
    -- ordinary UI clicks cast abilities. Those can only be bound as chords.
    if (key=="BUTTON1" or key=="BUTTON2") and modifierPrefix()=="" then return nil end
    -- Reject raw/unrecognized characters instead of saving invalid overrides.
    if not key:match("^[A-Z0-9_%-]+$") then return nil end
    return modifierPrefix() .. key
end
-- An accepted transfer is one atomic *staged* edit: remove the key from
-- EVERY old Mixolas slot (including legacy hidden-bar records) and assign it
-- to the destination. Nothing touches live WoW bindings until Save & Exit.
local function bindNow(key,slot,replaceWoW,replaceOldest)
    if not pending then return false end
    local id=tostring(slot)
    local keys=pending[id] or {}
    local alreadyHere=false
    for _,existing in ipairs(keys) do
        if existing==key then alreadyHere=true; break end
    end
    if not alreadyHere and #keys>=MAX_KEYS and not replaceOldest then
        setStatus("This button already has 3 keys; the oldest is replaced on a new assignment.")
        return false
    end
    -- Remove previous pet-slot ownership in this session as well. A key
    -- cannot simultaneously activate a Mixolas button and a native pet slot.
    removePetKey(key)
    -- Remove all previous owners; keep other shortcuts on their slots intact.
    for oldId,oldKeys in pairs(pending) do
        if type(oldKeys)=="table" then
            for k=#oldKeys,1,-1 do
                if oldKeys[k]==key then table.remove(oldKeys,k) end
            end
            if #oldKeys==0 then pending[oldId]=nil end
        end
    end
    keys=pending[id] or {}
    if replaceOldest and #keys>=MAX_KEYS then table.remove(keys,1) end
    if #keys>=MAX_KEYS then return false end
    keys[#keys+1]=key
    pending[id]=keys
    if replaceWoW then
        -- Only this specific native key is released. Escape on the old bar
        -- must NOT be required and its other shortcuts remain untouched.
        nativeClearPending[key]=true
    end
    if api.RefreshHotkeys then api.RefreshHotkeys(pending,nativeClearPending) end
    refreshPetPreviews() -- transfers from a pet slot must update its preview
    refreshSelectedText()
    setStatus(key.." assigned to "..buttonLabel(slot)..". Other Mixolas owners removed."..
        (nativeClearPending[key] and " Previous WoW shortcut will be released." or "")..
        "\nSAVE & EXIT to apply, or CANCEL to discard all edits.")
    return true
end
local function assignPetKey(key,slot)
    if not petPending or not pending then return end
    local index=-slot
    local command=petCommand(slot)
    local old=petPending[index]
    -- Transferring an occupied key takes it from all other Mixolas or pet
    -- slots; Save & Exit writes the Blizzard command atomically.
    for id,keys in pairs(pending) do
        if type(keys)=="table" then
            for j=#keys,1,-1 do
                if keys[j]==key then table.remove(keys,j) end
            end
            if #keys==0 then pending[id]=nil end
        end
    end
    removePetKey(key)
    if #old>=2 then table.remove(old,1) end -- WoW pet slots have two binding keys
    old[#old+1]=key
    nativeClearPending[key]=nil -- the new native assignment replaces the old
    if api.RefreshHotkeys then api.RefreshHotkeys(pending,nativeClearPending) end
    refreshPetPreviews() -- immediate in-editor visual update, no native writes
    refreshSelectedText()
    setStatus(key.." assigned to Pet Bar / Button "..index.." (staged native WoW key).\nSAVE & EXIT to apply; CANCEL to discard.")
end
local function assignKey(key)
    if not editing or not hovered or not pending or not key then return end
    if isPetSlot(hovered) then assignPetKey(key,hovered);return end
    -- LibKeyBound behavior: always move a newly assigned shortcut to the
    -- currently hovered slot. In particular, do not open a modal, hide the
    -- capture frame, or allow the still-held key's OnKeyUp into gameplay.
    local intendedSlot=hovered
    local existingMixolas=findPendingOwner(key,pending)
    local wow=GetBindingAction and GetBindingAction(key) or nil
    local wowOverride=GetBindingAction and GetBindingAction(key,true) or nil
    local currentButton=actionById[intendedSlot]
    local nativeCommand=currentButton and api.GetNativeBindingCommand and api.GetNativeBindingCommand(currentButton)
    -- If an edited key is moved BACK to the button its native WoW command
    -- already targets, undo the staged native clear. No unnecessary changes
    -- to interface/action-bar bindings should survive Save & Exit.
    if nativeClearPending[key] and wow and wow~="" and wow==nativeCommand then
        nativeClearPending[key]=nil
    end
    local existingNative=(wow and wow~="" and not nativeClearPending[key]) and wow or nil
    local nativeIsSameButton=existingNative and existingNative==nativeCommand
    local foreignOverride=wowOverride and wowOverride~="" and wowOverride~=wow
        and not string.find(wowOverride,"MixolasBars",1,true)
    local destinationKeys=pending[tostring(intendedSlot)] or {}
    local keyAlreadyHere=false
    for _,assigned in ipairs(destinationKeys) do
        if assigned==key then keyAlreadyHere=true; break end
    end
    -- A key already explicitly on this slot is a no-op, except when its
    -- native WoW command still belongs to a different action.
    if (existingMixolas==intendedSlot or (nativeIsSameButton and not existingMixolas))
        and not foreignOverride and not (existingNative and not nativeIsSameButton) then
        refreshSelectedText()
        return
    end
    local replaceOldest=#destinationKeys>=MAX_KEYS and not keyAlreadyHere
    local releaseNative=existingNative and not nativeIsSameButton or false
    if bindNow(key,intendedSlot,releaseNative,replaceOldest) and foreignOverride then
        -- Other addons can install priority overrides we cannot remove.
        -- Inform the user; routing verification on Save & Exit checks this.
        setStatus(key.." moved to "..buttonLabel(intendedSlot)..
          ". Another addon has an active override; its shortcut may still win.\n"..
          "SAVE & EXIT to apply and verify, or CANCEL to discard.")
    end
end
local function clearHovered()
    if not hovered or not pending then
        setStatus("Hover the button you want to clear, then press Escape.")
        return
    end
    if isPetSlot(hovered) then
        petPending[-hovered]={}
        refreshPetPreviews()
        refreshSelectedText()
        return
    end
    local id=tostring(hovered)
    local b=actionById[hovered]
    -- Escape is an explicit removal request. Stage both Mixolas and native
    -- WoW bindings for this button; Cancel still discards everything.
    pending[id]=nil
    if b and api.GetNativeBindingKeys then
        for _,key in ipairs(api.GetNativeBindingKeys(b)) do
            local owner=findPendingOwner(key,pending)
            -- Only release native keys currently belonging to this button;
            -- do not destroy another Mixolas button's transferred shortcut.
            if not owner or owner==hovered then nativeClearPending[key]=true end
        end
    end
    if api.RefreshHotkeys then api.RefreshHotkeys(pending,nativeClearPending) end
    refreshSelectedText()
end
local function makeButton(parent, label, x, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(156, 29)
    b:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", x, 12)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end
local function finish(save)
    if not editing then return false end
    if api.IsInCombat() then
        -- Combat can start while editing: discard without touching protected bindings.
        save = false
    end
    editing = false
    hovered = nil
    if keyboard then keyboard:Hide() end
    if keyboardGuard then keyboardGuard:Hide() end
    for _, target in ipairs(overlays or {}) do target.overlay:Hide() end
    restorePetNativeHotkeys()
    if toolbar then toolbar:Hide() end
    -- Restore normal hidden-slot visibility on both Save and Cancel.
    if api.SetBindingSlotRevealActive then api.SetBindingSlotRevealActive(false) end
    if save then
        -- Complete cleanup before attempting any WoW binding write. Even if
        -- the client rejects a native binding or raises an API error, the
        -- editor must never trap the player's keyboard.
        local rollback
        local function commitChanges()
        -- LibKeyBound commits to WoW's binding system; Mixolas additionally
        -- stores per-character mappings for its independent secure proxies.
        -- Treat both stores as one transaction: do not report a successful save
        -- or leave half-applied native shortcuts on failure.
        local previous=copyBindings(api.GetDB() and api.GetDB().bindings or {})
        local updated=copyBindings(pending)
        local oldNative,changed,failed={}, {}, {}
        -- Resolve the requested native key owner from the staged editor.
        -- Existing pet bindings removed by Escape/transfer are unbound;
        -- newly assigned pet keys use Blizzard's BONUSACTIONBUTTON command.
        local writes={}
        for key in pairs(nativeClearPending) do writes[key]=false end
        local newPetOwner={}
        for i=1,PET_SLOTS do
            for _,key in ipairs(petPending and petPending[i] or {}) do
                newPetOwner[key]="BONUSACTIONBUTTON"..i
            end
        end
        for i=1,PET_SLOTS do
            for _,key in ipairs(petBefore and petBefore[i] or {}) do
                if not newPetOwner[key] then
                    -- Only remove keys that still belong to this pet slot.
                    -- Don't destroy unrelated bindings edited elsewhere.
                    if GetBindingAction and GetBindingAction(key)=="BONUSACTIONBUTTON"..i then
                        writes[key]=false
                    end
                end
            end
        end
        for key,command in pairs(newPetOwner) do writes[key]=command end
        local ordered={}
        for key,command in pairs(writes) do
            local native=GetBindingAction and GetBindingAction(key) or ""
            if native~=(command or "") then ordered[#ordered+1]=key end
        end
        table.sort(ordered,function(a,b)
            -- Free removed pet bindings before assigning replacements. Some
            -- clients allow only two native keys per command.
            if (writes[a]==false)~=(writes[b]==false) then return writes[a]==false end
            return a<b
        end)
        local function restoreNative()
            if SetBinding then
                for i=#changed,1,-1 do
                    local key=changed[i]
                    pcall(SetBinding,key,(oldNative[key] and oldNative[key]~="") and oldNative[key] or nil)
                end
            end
        end
        rollback=function()
            if api.SetCharacterBindings then pcall(api.SetCharacterBindings,previous) end
            restoreNative()
        end
        for _,key in ipairs(ordered) do
            if not SetBinding then
                failed[#failed+1]=key
            else
                oldNative[key]=GetBindingAction and GetBindingAction(key) or ""
                local ok,result=pcall(SetBinding,key,writes[key] or nil)
                if ok and result~=false and result~=nil then
                    changed[#changed+1]=key
                else
                    failed[#failed+1]=key
                    break
                end
            end
        end
        if #failed>0 then
            restoreNative()
            api.Say("Binding save failed: WoW refused to update "..table.concat(failed,", ")..". No changes saved.")
        elseif not api.SetCharacterBindings or not api.SetCharacterBindings(updated) then
            restoreNative()
            api.Say("Binding save failed: character bindings could not be stored. Existing keys retained.")
        else
            local saved=true
            if #changed>0 then
                if not SaveBindings then
                    saved=false
                else
                    -- Some client builds return nil on success; only an
                    -- explicit false is regarded as a failed save.
                    local result=SaveBindings((GetCurrentBindingSet and GetCurrentBindingSet()) or 1)
                    if result==false then saved=false end
                end
            end
            if not saved then
                api.SetCharacterBindings(previous)
                restoreNative()
                api.Say("Binding save failed: WoW could not persist the native shortcut changes. Rolled back.")
            else
                if api.KeyBindProfilesSaveCurrent then
                    pcall(api.KeyBindProfilesSaveCurrent)
                end
                if api.ApplyBindings() then
                    api.Say("Bindings saved and Mixolas override routing verified where supported.")
                else
                    local report=api.GetBindingRouteReport and api.GetBindingRouteReport() or {}
                    local problems={}
                    for _,key in ipairs(report.mismatches or {}) do problems[#problems+1]=key end
                    for _,key in ipairs(report.errors or {}) do problems[#problems+1]=key end
                    api.Say("Bindings stored, but some live routes could not be verified: "..
                        (#problems>0 and table.concat(problems,", ") or "unknown")..". Test with /mxbkey KEY.")
                end
            end
        end
        end -- commitChanges
        local ok,err=pcall(commitChanges)
        if not ok then
            if rollback then pcall(rollback) end
            api.Say("Binding save failed; previous assignments restored where supported. Editor closed. Error: "..tostring(err))
        end
        if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
    else
        if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
        api.Say("Binding edits discarded; existing assignments kept.")
    end
    pending = nil
    petBefore,petPending=nil,nil
    nativeClearPending={}
    if returnPanel then pcall(returnPanel.Show,returnPanel) end
    returnPanel = nil
    return true
end
local function initEditor()
    if toolbar then return end
    overlays = {}
    toolbar = CreateFrame("Frame", "MixolasBarsBindingToolbar", UIParent,
        BackdropTemplateMixin and "BackdropTemplate" or nil)
    toolbar:SetSize(550, 178)
    toolbar:SetPoint("TOP", UIParent, "TOP", 0, -80)
    -- Dialogs must appear above the toolbar. Previously TOOLTIP sat above
    -- FULLSCREEN_DIALOG, allowing a hidden modal to block Save & Exit.
    toolbar:SetFrameStrata("DIALOG")
    toolbar:SetFrameLevel(300)
    toolbar:EnableMouse(true)
    if api.MakeMovableWindow then api.MakeMovableWindow(toolbar,"bindingToolbar") end
    if toolbar.SetBackdrop then
        toolbar:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=4,right=4,top=4,bottom=4}})
        toolbar:SetBackdropColor(0.85,0.85,0.85,0.95)
        toolbar:SetBackdropBorderColor(1,1,1,1)
    end
    local title=toolbar:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOP",toolbar,"TOP",0,-11)
    title:SetText("MIXOLAS BARS  |  BINDING MODE")
    status=toolbar:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    status:SetWidth(520)
    status:SetJustifyH("CENTER")
    status:SetPoint("TOP",toolbar,"TOP",0,-40)
    captureStatus=toolbar:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    captureStatus:SetPoint("BOTTOM",toolbar,"BOTTOM",0,49)
    captureStatus:SetText("KEY CAPTURE: WAITING")
    removeKeyButtons={}
    for i=1,MAX_KEYS do
        local index=i
        local b=CreateFrame("Button",nil,toolbar,"UIPanelButtonTemplate")
        b:SetSize(155,27)
        b:SetPoint("TOPLEFT",toolbar,"TOPLEFT",20+(i-1)*172,-92)
        b:SetScript("OnClick",function()
            if not editing or not hovered or not pending then return end
            local pet=isPetSlot(hovered)
            local keys=pet and petPending and petPending[-hovered]
                or pending[tostring(hovered)]
            if keys and keys[index] then
                table.remove(keys,index)
                if not pet and #keys==0 then pending[tostring(hovered)]=nil end
                -- Removing a shortcut is staged; Cancel preserves WoW keys.
                if api.RefreshHotkeys then api.RefreshHotkeys(pending,nativeClearPending) end
                refreshPetPreviews()
                refreshSelectedText()
            end
        end)
        b:Hide()
        removeKeyButtons[i]=b
    end
    makeButton(toolbar,"SAVE & EXIT",105,function()
        local ok,err=pcall(finish,true)
        if not ok then
            -- Last-resort UI escape hatch, even on unexpected WoW errors.
            editing=false; hovered=nil; pending=nil
                    if keyboard then keyboard:Hide() end
            if keyboardGuard then keyboardGuard:Hide() end
            for _,t in ipairs(overlays or {}) do t.overlay:Hide() end
            toolbar:Hide()
            if returnPanel then pcall(returnPanel.Show,returnPanel) end
            returnPanel=nil
            api.Say("Binding editor closed after an error: "..tostring(err))
        end
    end)
    makeButton(toolbar,"CANCEL",285,function() finish(false) end)
    toolbar:Hide()

    -- Secondary always-on capture guard remains visible throughout editing.
    -- No replacement popup is allowed to interrupt key down/up dispatch.
    keyboardGuard=CreateFrame("Frame","MixolasBarsBindingKeyboardGuard",UIParent)
    keyboardGuard:SetAllPoints(UIParent)
    keyboardGuard:SetFrameStrata("FULLSCREEN_DIALOG")
    keyboardGuard:SetFrameLevel(550)
    keyboardGuard:EnableMouse(false)
    keyboardGuard:EnableKeyboard(true)
    if keyboardGuard.SetPropagateKeyboardInput then
        keyboardGuard:SetPropagateKeyboardInput(false)
    end
    keyboardGuard:Hide()

    -- The focused, mouse-transparent EditBox receives normal keyboard events.
    -- Never hide it on an occupied key; the old action could fire on key up.
    keyboard=CreateFrame("EditBox","MixolasBarsBindingKeyboardCapture",UIParent)
    keyboard:SetSize(1,1)
    keyboard:SetPoint("TOPLEFT",UIParent,"TOPLEFT",0,0)
    keyboard:SetFrameStrata("FULLSCREEN_DIALOG")
    keyboard:SetFrameLevel(600)
    keyboard:EnableMouse(false)
    keyboard:EnableKeyboard(true)
    if keyboard.SetAutoFocus then keyboard:SetAutoFocus(false) end
    if keyboard.SetFontObject and GameFontNormal then keyboard:SetFontObject(GameFontNormal) end
    if keyboard.SetAlpha then keyboard:SetAlpha(0) end
    local function consumeInput(self)
        if self.SetPropagateKeyboardInput then
            -- WoW 10.1.5+ restricts this in combat, and editing is out of combat.
            pcall(self.SetPropagateKeyboardInput,self,false)
        end
    end
    keyboard:SetScript("OnShow",function(self)
        consumeInput(self)
        if self.SetFocus then self:SetFocus() end
        if captureStatus then captureStatus:SetText("KEY CAPTURE: ACTIVE") end
    end)
    keyboard:SetScript("OnHide",function(self)
        if self.ClearFocus then self:ClearFocus() end
        if captureStatus then captureStatus:SetText("KEY CAPTURE: OFF") end
    end)
    local function onCapturedKeyDown(rawKey)
        if not editing then return end
        if captureStatus then captureStatus:SetText("KEY CAPTURE: "..tostring(rawKey)) end
        if rawKey=="ESCAPE" then clearHovered(); return end
        assignKey(normalizeKey(rawKey))
    end
    local function onCapturedKeyUp(rawKey)
        if not editing then return end
        if captureStatus then captureStatus:SetText("KEY CAPTURE: ACTIVE") end
    end
    keyboard:SetScript("OnKeyDown",function(self,rawKey)
        consumeInput(self)
        onCapturedKeyDown(rawKey)
    end)
    keyboard:SetScript("OnKeyUp",function(self,rawKey)
        consumeInput(self)
        onCapturedKeyUp(rawKey)
    end)
    keyboardGuard:SetScript("OnKeyDown",function(self,rawKey)
        -- This only receives keys if the EditBox lost focus/priority.
        -- Both handlers consume their events before WorldFrame can cast.
        onCapturedKeyDown(rawKey)
    end)
    keyboardGuard:SetScript("OnKeyUp",function(self,rawKey)
        onCapturedKeyUp(rawKey)
    end)
    -- Guard also closes the editor immediately if combat begins.
    keyboardGuard:SetScript("OnUpdate",function()
        if editing and api.IsInCombat and api.IsInCombat() then
            finish(false)
            api.Say("Binding editor closed because combat started. No binding edits saved.")
        end
    end)
    -- Focused edit boxes also receive character and special-key events.
    -- Never let text accumulate or let Enter/Escape dismiss the focus target.
    keyboard:SetScript("OnTextChanged",function(self)
        if self:GetText()~="" then self:SetText("") end
    end)
    keyboard:SetScript("OnEnterPressed",function() end)
    keyboard:SetScript("OnEscapePressed",function() end)
    keyboard:SetScript("OnEditFocusLost",function(self)
        if not editing or not self:IsShown() then return end
        -- Defer until the click/focus transition completes. The periodic
        -- watchdog below covers builds without C_Timer.
        if C_Timer and C_Timer.After then
            C_Timer.After(0,function()
                if editing and self:IsShown()
                    and self.HasFocus and not self:HasFocus() then
                    self:SetFocus()
                end
            end)
        end
    end)
    -- WoW may drop focus when clicking a popup, minimap, or action overlay.
    -- Regain focus for the NEXT key if the WoW client drops it.
    keyboard:SetScript("OnUpdate",function(self,elapsed)
        if not editing then return end
        if api.IsInCombat and api.IsInCombat() then
            finish(false)
            api.Say("Binding editor closed because combat started. No binding edits saved.")
            return
        end
        self._focusCheck=(self._focusCheck or 0)+(elapsed or 0)
        if self._focusCheck < 0.10 then return end
        self._focusCheck=0
        if self.HasFocus and not self:HasFocus() then
            if self.SetFocus then self:SetFocus() end
            if captureStatus then
                captureStatus:SetText((self.HasFocus and self:HasFocus())
                    and "KEY CAPTURE: ACTIVE" or "KEY CAPTURE: NOT FOCUSED")
            end
        end
    end)
    keyboard:Hide()

    local targets={}
    for _, cluster in ipairs(api.GetClusters()) do
        for _, action in ipairs(cluster.buttons) do
            targets[#targets+1]=action
        end
    end
    for _, action in ipairs(api.GetRegularButtons()) do
        -- Full-length Bars 3, 4 and 5 are internal mirrors of the diamond
        -- slots. Their frames remain hidden in play and MUST NOT have their
        -- own screen-level keybinding overlays or binding capture targets.
        if not (api.IsRegularReserved and api.IsRegularReserved(action.barNumber)) then
            targets[#targets+1]=action
        end
    end
    -- The pet bar uses native Blizzard buttons and BONUSACTIONBUTTON1..10,
    -- not Mixolas action IDs; use negative editor-only IDs to avoid collision.
    for i=1,PET_SLOTS do
        local petButton=_G["PetActionButton"..i]
        if petButton then
            targets[#targets+1]={nativePetButton=petButton,bindId=-i}
        end
    end
    for _, actionInfo in ipairs(targets) do
            local action=actionInfo.nativePetButton or actionInfo
            local bindingID=actionInfo.bindId or actionInfo.slot
            actionById[bindingID]=action
            local overlay = CreateFrame("Frame",nil,UIParent)
            overlay:SetAllPoints(action)
            overlay:SetFrameStrata("DIALOG")
            overlay:SetFrameLevel(185)
            overlay:EnableMouse(true)
            if overlay.EnableMouseWheel then overlay:EnableMouseWheel(true) end
            local wash=overlay:CreateTexture(nil,"OVERLAY")
            wash:SetAllPoints()
            wash:SetColorTexture(0.22,0.62,0.96,0.20)
            local petPreview,petHotkey
            if actionInfo.nativePetButton then
                -- Draw only outlined text: no dark texture obscuring pet icons.
                -- The original native hotkey font is temporarily hidden while
                -- editing, preventing old and staged labels from overlapping.
                petHotkey=action.HotKey or _G[(action.GetName and action:GetName() or "").."HotKey"]
                petPreview=overlay:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
                petPreview:SetPoint("TOPRIGHT",overlay,"TOPRIGHT",-2,-2)
                petPreview:SetWidth(32)
                petPreview:SetJustifyH("RIGHT")
                petPreview:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",8,"OUTLINE")
                petPreview:SetTextColor(1,1,1,1)
            end
            overlay:SetScript("OnEnter", function()
                hovered=bindingID
                -- Acquiring focus here ensures that moving directly from the
                -- minimap to a spell slot cannot leave an unguarded key press.
                if editing and keyboard
                    and keyboard:IsShown() and keyboard.HasFocus
                    and not keyboard:HasFocus() then keyboard:SetFocus() end
                wash:SetColorTexture(0.35,0.9,1,0.46)
                refreshSelectedText()
            end)
            overlay:SetScript("OnLeave", function()
                if hovered == bindingID then hovered=nil end
                wash:SetColorTexture(0.22,0.62,0.96,0.20)
                refreshSelectedText()
            end)
            overlay:SetScript("OnMouseDown", function(_, mouseKey)
                if not editing then return end
                local input = ({MiddleButton="BUTTON3",Button4="BUTTON4",Button5="BUTTON5"})[mouseKey]
                if input then assignKey(modifierPrefix() .. input) end
            end)
            overlay:SetScript("OnMouseWheel", function(_, direction)
                if editing then assignKey(modifierPrefix() .. (direction>0 and "MOUSEWHEELUP" or "MOUSEWHEELDOWN")) end
            end)
            overlay:Hide()
            overlays[#overlays+1]={overlay=overlay,action=action,
                petIndex=actionInfo.nativePetButton and -bindingID or nil,
                petPreview=petPreview,petHotkey=petHotkey}
    end
end
function api.StartBindingMode(previousPanel)
    if editing or not api.IsReady() or api.IsInCombat() then return false end
    initEditor()
    pending = copyBindings(api.GetDB().bindings)
    petBefore=capturePetKeys()
    petPending=copyPetKeys(petBefore)
    nativeClearPending={}
    hovered, returnPanel, editing = nil, previousPanel, true
    -- Reveal eligible hidden empty slots BEFORE evaluating their overlay
    -- visibility. Disabled bars and out-of-range slots remain hidden.
    if api.SetBindingSlotRevealActive and not api.SetBindingSlotRevealActive(true) then
        editing=false
        pending=nil
        petBefore,petPending=nil,nil
        return false
    end
    if api.RefreshHotkeys then api.RefreshHotkeys(pending,nativeClearPending) end
    -- WoW's IsShown checks only the frame's own shown flag; a child of a
    -- hidden bar can still return true. These overlays are parented to
    -- UIParent, so using IsShown creates floating phantom spell bars.
    -- IsVisible includes ancestor visibility and is the correct gate.
    for _, target in ipairs(overlays) do
        local action=target.action
        local visible=action.IsVisible and action:IsVisible()
        if visible==nil then
            visible=action:IsShown()
            local parent=action:GetParent()
            while visible and parent do
                if parent.IsShown and not parent:IsShown() then visible=false end
                parent=parent.GetParent and parent:GetParent() or nil
            end
        end
        target.overlay:SetShown(not not visible)
    end
    suppressPetNativeHotkeys()
    refreshPetPreviews()
    refreshSelectedText()
    toolbar:Show()
    keyboardGuard:Show()  -- establish the guard before focus transitions
    keyboard:Show()
    -- Fail closed. Do not leave a keybinding editor open if the game can't
    -- focus its capture target: otherwise pressing 1 can cast a real spell.
    if keyboard.SetFocus then keyboard:SetFocus() end
    local focusFailed=keyboard.HasFocus and not keyboard:HasFocus()
    local propagateFailed=false
    if keyboard.GetPropagateKeyboardInput then
        local ok,propagate=pcall(keyboard.GetPropagateKeyboardInput,keyboard)
        propagateFailed=ok and propagate==true
    end
    local guardFailed=false
    if keyboardGuard.GetPropagateKeyboardInput then
        local ok,propagate=pcall(keyboardGuard.GetPropagateKeyboardInput,keyboardGuard)
        guardFailed=ok and propagate==true
    end
    if focusFailed or propagateFailed or guardFailed then
        finish(false)
        api.Say("Binding mode couldn't safely capture keyboard input; editor closed to prevent accidental casts. Try /reload.")
        return false
    end
    return true
end
api.IsBindingMode=function() return editing end
api.SaveBindingMode=function() return finish(true) end
api.CancelBindingMode=function() return finish(false) end

-- Versioned portable format: MXB1;1=SHIFT-1;15=ALT-Q;
-- 33-104 are regular-bar button IDs.
-- Percent-encoding ensures special characters cannot corrupt separators.
local function escapeKey(key)
    return (key:gsub("([^A-Z0-9_%-])",function(c) return string.format("%%%02X", string.byte(c)) end))
end
local function unescapeKey(key)
    if key:find("%%[^%x]") or key:find("%%$") then return nil end
    return (key:gsub("%%(%x%x)",function(pair) return string.char(tonumber(pair,16)) end))
end
local function validKey(key)
    return type(key)=="string" and #key>0 and #key<81
        and key:match("^[A-Z0-9_%-]+$") ~= nil
end
local function exportMap(map)
    local result={"MXB1"}
    for slot=1,MAX_BUTTONS do
        local keys=map[tostring(slot)]
        if type(keys)=="table" and #keys>0 then
            local out={}
            for i=1,math.min(MAX_KEYS,#keys) do
                if validKey(keys[i]) then out[#out+1]=escapeKey(keys[i]) end
            end
            if #out>0 then result[#result+1]=slot.."="..table.concat(out,",") end
        end
    end
    return table.concat(result,";")
end
local function importMap(raw)
    if type(raw)~="string" or #raw>16384 then return nil,"Invalid or overly long import." end
    raw=raw:gsub("^%s+",""):gsub("%s+$","")
    if raw~="MXB1" and raw:sub(1,5)~="MXB1;" then
        return nil,"Expected an MXB1 export string." end
    local map,occupied={},{}
    local body=raw:sub(6)
    if body=="" then return map end
    for entry in body:gmatch("[^;]+") do
        local num,list=entry:match("^(%d+)=(.+)$")
        local slot=tonumber(num)
        if not slot or slot<1 or slot>MAX_BUTTONS or map[tostring(slot)] then
            return nil,"Invalid or duplicate slot in import." end
        local keys={}
        for chunk in list:gmatch("[^,]+") do
            local k=unescapeKey(chunk)
            if not validKey(k) or occupied[k] or #keys>=MAX_KEYS then
                return nil,"Invalid key, duplicate shortcut, or too many keys." end
            occupied[k]=true
            keys[#keys+1]=k
        end
        if #keys==0 or #keys>MAX_KEYS then return nil,"Empty slot binding." end
        map[tostring(slot)]=keys
    end
    return map
end
-- Import can run before the mouseover editor has ever been opened.
-- Resolve buttons directly from the live action frames instead of assuming
-- that actionById has already been populated by initEditor().
local function findButtonByBindingID(id)
    id=tonumber(id)
    if not id then return nil end
    local cached=actionById[id]
    if cached then return cached end
    if api.GetClusters then
        for _,cluster in ipairs(api.GetClusters()) do
            for _,button in ipairs(cluster.buttons or {}) do
                if (button.bindId or button.slot)==id then return button end
            end
        end
    end
    if api.GetRegularButtons then
        for _,button in ipairs(api.GetRegularButtons()) do
            if not (api.IsRegularReserved and api.IsRegularReserved(button.barNumber))
                and (button.bindId or button.slot)==id then return button end
        end
    end
end
-- Strictly parse a portable bar map for a combined import WITHOUT applying it.
-- Existing standalone MXB1 importer remains untouched.
api.GetBindingTargetForImport=function(id) return findButtonByBindingID(id) end
api.ParsePortableBarBindings=function(raw)
    local map,err=importMap(raw)
    if not map then return nil,err end
    for id in pairs(map) do
        if not findButtonByBindingID(id) then
            return nil,"Binding target "..tostring(id).." is unavailable."
        end
    end
    return map
end
api.GetBindingExport=function() return exportMap(api.GetDB().bindings or {}) end
api.ImportBindings=function(raw)
    if editing or not api.IsReady() or api.IsInCombat() then
        return false,"Leave binding mode and combat before importing." end
    local map,err=importMap(raw)
    if not map then return false,err end
    for id,keys in pairs(map) do
        for _,key in ipairs(keys) do
            local command=GetBindingAction and GetBindingAction(key) or nil
            local claimed=findButtonByBindingID(id)
            if not claimed then return false,"Binding target "..tostring(id).." is unavailable." end
            local permitted=api.GetNativeBindingCommand and api.GetNativeBindingCommand(claimed)
            if command and command~="" and command~=permitted then
                return false,key.." is still bound to WoW: "..tostring(command)..". Reassign it using mouseover mode to review the conflict."
            end
        end
    end
    if not api.SetCharacterBindings or not api.SetCharacterBindings(map) then
        return false,"Character bindings were not saved."
    end
    api.ApplyBindings()
    if api.RefreshHotkeys then api.RefreshHotkeys() end
    return true,"Imported " .. countBindings() .. " bound buttons for this character."
end

-- RC8.17: Import and export are distinct tasks and have separate input fields.
-- UI-only reorganization; binding transfer formats and import/export APIs unchanged.
local function openTransfer()
    if not api.IsReady() or api.IsInCombat() or editing then return end
    if not transfer then
        transfer=CreateFrame("Frame","MixolasBarsBindingsTransferWindow",UIParent,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        transfer:SetSize(748,662)
        transfer:SetPoint("CENTER",UIParent,"CENTER",0,0)
        transfer:SetFrameStrata("FULLSCREEN_DIALOG")
        transfer:SetFrameLevel(160)
        transfer:EnableMouse(true)
        if api.MakeMovableWindow then api.MakeMovableWindow(transfer,"transfer") end
        if transfer.SetBackdrop then
            transfer:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
                tile=true,tileSize=32,edgeSize=24,
                insets={left=4,right=4,top=4,bottom=4}})
            transfer:SetBackdropColor(0.06,0.07,0.10,0.98)
        end
        local function text(parent,font,label,x,y,width)
            local fs=parent:CreateFontString(nil,"OVERLAY",font)
            fs:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
            fs:SetWidth(width)
            fs:SetJustifyH("LEFT")
            fs:SetText(label)
            return fs
        end
        local function button(parent,label,x,y,width,handler)
            local w=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
            w:SetSize(width,29)
            w:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",x,y)
            w:SetText(label)
            w:SetScript("OnClick",handler)
            return w
        end
        local function editor(parent,name,x,y,width,height)
            local scroll=CreateFrame("ScrollFrame",name.."Scroll",parent,"UIPanelScrollFrameTemplate")
            scroll:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
            scroll:SetSize(width,height)
            local edit=CreateFrame("EditBox",name,scroll)
            edit:SetWidth(width-23)
            edit:SetHeight(height)
            edit:SetMultiLine(true)
            edit:SetAutoFocus(false)
            edit:SetFontObject(ChatFontNormal or GameFontHighlight)
            edit:SetMaxLetters(65535)
            edit:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
            edit:SetScript("OnTextChanged",function(self)
                self:SetHeight(math.max(height,(self.GetStringHeight and self:GetStringHeight() or height)+24))
            end)
            scroll:SetScrollChild(edit)
            return edit
        end
        -- The active Mixolas profile is the primary title, not hidden metadata.
        local heading=text(transfer,"GameFontNormalLarge","",20,-19,430)
        transfer.heading=heading
        text(transfer,"GameFontHighlightSmall","IMPORT & EXPORT  |  Bar, Native WoW or All Keybinds",20,-49,665)
        local profileLabel=text(transfer,"GameFontHighlightSmall","",20,-67,675)
        transfer.profileLabel=profileLabel
        -- RC8.23: A profile selector right in Import / Export. This switches the
        -- REAL active profile using the existing safe profile-loading pathway,
        -- so both tabs always operate on the profile displayed in the heading.
        -- Keep pasted import text on switch (useful for transfers), but clear
        -- previously generated exports because they belong to the old profile.
        local profilePicker=CreateFrame("Button",nil,transfer,"UIPanelButtonTemplate")
        profilePicker:SetSize(258,30)
        profilePicker:SetPoint("TOPRIGHT",transfer,"TOPRIGHT",-26,-13)
        transfer.profilePicker=profilePicker
        local pickerMenu=CreateFrame("Frame",nil,transfer,
            BackdropTemplateMixin and "BackdropTemplate" or nil)
        pickerMenu:SetFrameStrata("FULLSCREEN_DIALOG")
        pickerMenu:SetFrameLevel(240)
        pickerMenu:SetPoint("TOPRIGHT",profilePicker,"BOTTOMRIGHT",0,-2)
        pickerMenu:SetSize(268,40)
        pickerMenu:EnableMouse(true)
        pickerMenu:EnableMouseWheel(true)
        if pickerMenu.SetBackdrop then
            pickerMenu:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
                tile=true,tileSize=32,edgeSize=18,
                insets={left=4,right=4,top=4,bottom=4}})
            pickerMenu:SetBackdropColor(0.06,0.07,0.10,0.99)
        end
        pickerMenu:Hide()
        transfer.profileMenu=pickerMenu
        local maxRows=8
        local rows={}
        local offset=0
        local function refreshProfileHeader()
            local profile=tostring((api.GetActiveProfileName and api.GetActiveProfileName()) or "Current Character")
            heading:SetText("KEYBINDINGS  |  "..profile)
            profileLabel:SetText("Selected: "..profile.."  |  Import and export affect this profile")
            profilePicker:SetText("Switch Profile: "..profile.."  \226\150\188")
        end
        transfer.refreshProfileHeader=refreshProfileHeader
        local function refreshPickerRows()
            local names=(api.ListProfiles and api.ListProfiles()) or {}
            local visible=math.min(#names,maxRows)
            offset=math.min(offset,math.max(0,#names-maxRows))
            pickerMenu:SetHeight(visible*29+16)
            for i,row in ipairs(rows) do
                local name=names[offset+i]
                row:SetShown(name~=nil)
                if name then
                    local current=(api.GetActiveProfileName and api.GetActiveProfileName())
                    row:SetText((name==current and "* " or "  ")..name)
                    row.profileName=name
                else
                    row.profileName=nil
                end
            end
        end
        pickerMenu:SetScript("OnMouseWheel",function(_,delta)
            local count=#((api.ListProfiles and api.ListProfiles()) or {})
            offset=math.max(0,math.min(math.max(0,count-maxRows),offset-(delta>0 and 1 or -1)))
            refreshPickerRows()
        end)
        for i=1,maxRows do
            local row=CreateFrame("Button",nil,pickerMenu,"UIPanelButtonTemplate")
            row:SetSize(248,27)
            row:SetPoint("TOPLEFT",pickerMenu,"TOPLEFT",10,-8-(i-1)*29)
            row:SetScript("OnClick",function(self)
                pickerMenu:Hide()
                local name=self.profileName
                if not name or not api.SwitchNamedProfile then return end
                -- Switching while the import field has focus must never
                -- accidentally type into it or act on an old active profile.
                if transfer.exportEdit then transfer.exportEdit:ClearFocus() end
                if transfer.importEdit then transfer.importEdit:ClearFocus() end
                if api.IsInCombat and api.IsInCombat() then
                    if transfer.profileStatus then transfer.profileStatus:SetText("Cannot switch profiles during combat.") end
                    return
                end
                local ok,msg=api.SwitchNamedProfile(name)
                if ok then
                    refreshProfileHeader()
                    if transfer.exportEdit then transfer.exportEdit:SetText("") end
                    if transfer.exportStatus then
                        transfer.exportStatus:SetText("Switched to '"..name.."'. Generate a new export for this profile.")
                    end
                    if transfer.importStatus then
                        transfer.importStatus:SetText("Switched to '"..name.."'. Pasted import text is retained; Import applies here.")
                    end
                else
                    local reason="Profile switch failed: "..tostring(msg or "Unknown error")
                    if transfer.exportStatus then transfer.exportStatus:SetText(reason) end
                    if transfer.importStatus then transfer.importStatus:SetText(reason) end
                end
            end)
            rows[i]=row
        end
        profilePicker:SetScript("OnClick",function()
            if api.IsInCombat and api.IsInCombat() then return end
            if pickerMenu:IsShown() then pickerMenu:Hide();return end
            offset=0
            refreshPickerRows()
            pickerMenu:Show()
        end)
        transfer.refreshPickerRows=refreshPickerRows
        local closeX=CreateFrame("Button",nil,transfer,"UIPanelCloseButton")
        closeX:SetPoint("TOPRIGHT",-4,-4)
        closeX:SetScript("OnClick",function()
            if transfer.exportEdit then transfer.exportEdit:ClearFocus() end
            if transfer.importEdit then transfer.importEdit:ClearFocus() end
            pickerMenu:Hide()
            transfer:Hide()
        end)
        local line=transfer:CreateTexture(nil,"ARTWORK")
        line:SetColorTexture(0.35,0.35,0.35,0.65)
        line:SetPoint("TOPLEFT",transfer,"TOPLEFT",20,-122)
        line:SetSize(705,1)
        local exportPanel=CreateFrame("Frame",nil,transfer)
        exportPanel:SetAllPoints(transfer)
        local importPanel=CreateFrame("Frame",nil,transfer)
        importPanel:SetAllPoints(transfer)
        local tabExport=CreateFrame("Button",nil,transfer,"UIPanelButtonTemplate")
        tabExport:SetSize(155,31)
        tabExport:SetPoint("TOPLEFT",transfer,"TOPLEFT",20,-83)
        tabExport:SetText("EXPORT")
        local tabImport=CreateFrame("Button",nil,transfer,"UIPanelButtonTemplate")
        tabImport:SetSize(155,31)
        tabImport:SetPoint("LEFT",tabExport,"RIGHT",8,0)
        tabImport:SetText("IMPORT")
        local function selectTab(which)
            pickerMenu:Hide()
            exportPanel:SetShown(which=="export")
            importPanel:SetShown(which=="import")
            tabExport:SetEnabled(which~="export")
            tabImport:SetEnabled(which~="import")
            if transfer.exportEdit then transfer.exportEdit:ClearFocus() end
            if transfer.importEdit then transfer.importEdit:ClearFocus() end
        end
        tabExport:SetScript("OnClick",function() selectTab("export") end)
        tabImport:SetScript("OnClick",function() selectTab("import") end)
        transfer.selectTab=selectTab

        -- EXPORT: choose scope on the left, copy generated text on the right.
        text(exportPanel,"GameFontNormal","EXPORT SCOPE",20,-145,245)
        text(exportPanel,"GameFontNormal","EXPORTED KEYBINDINGS",297,-145,410)
        local mode="all"
        local choices={}
        local exportStatus
        local function pickMode(value)
            mode=value
            for id,w in pairs(choices) do w:SetChecked(id==value) end
            -- Do not leave an All export visible after the user selects Bar only.
            if transfer.exportEdit then transfer.exportEdit:SetText("") end
            if exportStatus then exportStatus:SetText("Scope changed. Generate an export for this selection.") end
        end
        local options={
            {id="bar",title="Bar Keybinds",detail="MXB1  |  Mixolas action button shortcuts"},
            {id="native",title="Native WoW Keybinds",detail="MXBN1  |  Movement, panels, targeting, etc."},
            {id="all",title="All Keybinds",detail="MXBA1  |  Both sets of shortcuts"},
        }
        for i,option in ipairs(options) do
            local y=-177-(i-1)*66
            local radio=CreateFrame("CheckButton",nil,exportPanel,"UIRadioButtonTemplate")
            radio:SetSize(22,22)
            radio:SetPoint("TOPLEFT",exportPanel,"TOPLEFT",20,y)
            radio:SetScript("OnClick",function() pickMode(option.id) end)
            local name=text(exportPanel,"GameFontHighlight",option.title,50,y,226)
            local detail=text(exportPanel,"GameFontHighlightSmall",option.detail,50,y-25,222)
            -- Make the label/description clickable in addition to the radio.
            local hit=CreateFrame("Button",nil,exportPanel)
            hit:SetPoint("TOPLEFT",exportPanel,"TOPLEFT",47,y+3)
            hit:SetSize(230,51)
            hit:SetScript("OnClick",function() pickMode(option.id) end)
            choices[option.id]=radio
        end
        pickMode("all")
        transfer.pickMode=pickMode
        local exportEdit=editor(exportPanel,"MixolasBarsTransferExportEdit",297,-175,419,210)
        transfer.exportEdit=exportEdit
        text(exportPanel,"GameFontHighlightSmall",
            "To copy: click Select Text for Copy, then press Ctrl+C. One-click clipboard copy is blocked by WoW.",297,-394,413)
        text(exportPanel,"GameFontHighlightSmall",
            "Exporting never changes your current bindings or profile.",20,-398,263)
        exportStatus=text(exportPanel,"GameFontHighlightSmall","Choose a scope and generate an export.",297,-427,420)
        transfer.exportStatus=exportStatus
        exportStatus:SetHeight(35)
        button(exportPanel,"Generate Export",20,19,168,function()
            local data,message=api.GenerateKeybindingExport(mode)
            if not data then exportStatus:SetText("Export failed: "..tostring(message));return end
            exportEdit:SetText(data)
            exportEdit:SetFocus()
            exportEdit:HighlightText()
            exportStatus:SetText(message.." Text selected. Press Ctrl+C to copy to your clipboard.")
        end)
        -- WoW's CopyToClipboard() is a protected Blizzard function. Addons
        -- cannot write the OS clipboard directly. A click prepares the full
        -- export for the player's normal Ctrl+C shortcut instead.
        button(exportPanel,"Select Text for Copy",201,19,164,function()
            if exportEdit:GetText()=="" then
                exportStatus:SetText("Generate an export before copying text.")
                return
            end
            exportEdit:SetFocus()
            exportEdit:HighlightText()
            exportStatus:SetText("Export selected. Press Ctrl+C to copy, then Ctrl+V to paste. WoW cannot copy with one click.")
        end)
        button(exportPanel,"Close",597,19,122,function()
            exportEdit:ClearFocus();transfer:Hide()
        end)

        -- RC8.20: Direct native import. Undo is the escape hatch, not a preview modal.
        text(importPanel,"GameFontNormal","PASTE KEYBIND EXPORT",20,-145,680)
        text(importPanel,"GameFontHighlightSmall",
            "MXB1: Bar  |  MXBN1: Native WoW  |  MXBA1: All Keybinds",20,-173,690)
        local importEdit=editor(importPanel,"MixolasBarsTransferImportEdit",20,-205,695,178)
        transfer.importEdit=importEdit
        local previewText=text(importPanel,"GameFontHighlightSmall",
            "Paste a keybinding export to get started.",20,-396,691)
        previewText:SetHeight(138)
        local importStatus=text(importPanel,"GameFontHighlightSmall",
            "No changes until you explicitly import.",20,-537,690)
        importStatus:SetHeight(50)
        transfer.importStatus=importStatus
        local importButton
        local function modeOf(raw)
            local header=(raw or ""):match("^%s*([%a%d]+)") or ""
            if header=="MXB1" then return "bar" end
            if header=="MXBN1" then return "native" end
            if header=="MXBA1" then return "all" end
            return "unknown"
        end
        local function updateImportAvailability()
            local raw=importEdit:GetText() or ""
            local mode=modeOf(raw)
            importButton:SetEnabled(mode=="bar" or mode=="native" or mode=="all")
            if mode=="bar" then
                importButton:SetText("Import Bar Keybinds")
                previewText:SetText("Bar Keybinds (MXB1). Import replaces Mixolas button shortcuts only.\nNative WoW movement and interface keys are unchanged.")
                importStatus:SetText("Legacy MXB1 import is available. Save an export before replacing shortcuts.")
            elseif mode=="native" then
                importButton:SetText("Import Native Keybinds")
                previewText:SetText("Native WoW Keybinds (MXBN1). Click Import to replace native shortcuts in your ACTIVE profile. All changes are one Undo step; other profiles and Mixolas bar bindings stay intact.")
                importStatus:SetText("Paste, then Import. Use Undo to restore the previous keys if needed. No preview or confirmation.")
            elseif mode=="all" then
                importButton:SetText("Import All Keybinds")
                previewText:SetText("All Keybinds (MXBA1). Replaces both Mixolas button shortcuts and native WoW keys in the ACTIVE profile. One Undo restores both sets. No spell placements or layouts change.")
                importStatus:SetText("Paste, then Import. One Undo restores both sets if needed. No preview or confirmation.")
            elseif raw:match("^%s*$") then
                previewText:SetText("Paste an MXB1, MXBN1, or MXBA1 export above.")
                importStatus:SetText("No changes until you explicitly import.")
            else
                previewText:SetText("Unrecognized export format. Nothing changed.")
                importStatus:SetText("Import disabled. Check the exported string.")
            end
        end
        importButton=button(importPanel,"Import Bar Keybinds",20,19,215,function()
            local raw=importEdit:GetText() or ""
            local mode=modeOf(raw)
            if mode=="bar" then
                local ok,message=api.ImportBindings(raw)
                importStatus:SetText(tostring(message))
                if ok and api.Say then api.Say(message) end
                return
            end
            if mode~="native" and mode~="all" then
                importStatus:SetText("Unrecognized binding export; nothing changed.")
                return
            end
            -- Never apply native keybind changes unless the session Undo
            -- timeline can capture both native and Mixolas profile snapshots.
            if not api.CanRecordUndo or not api.CanRecordUndo() or not api.RunBatchEdit then
                importStatus:SetText("Undo history is not ready. No native keys were changed.")
                return
            end
            local applied,message=false,"Binding import could not be completed."
            local name=mode=="all" and "All Keybinds" or "Native WoW Keybinds"
            local ran,reason=pcall(function()
                api.RunBatchEdit("Import "..name,function()
                    if mode=="all" then
                        applied,message=api.ApplyAllBindingImport(raw)
                    else
                        applied,message=api.ApplyNativeBindingImport(raw)
                    end
                    return applied
                end)
            end)
            if not ran then
                applied=false
                message=name.." import failed: "..tostring(reason)
            end
            if applied then
                message=tostring(message).." One Undo restores the previous bindings."
                if api.Say then api.Say(message) end
            end
            importStatus:SetText(tostring(message))
        end)
        importEdit:SetScript("OnTextChanged",function(self)
            self:SetHeight(math.max(178,(self.GetStringHeight and self:GetStringHeight() or 178)+24))
            updateImportAvailability()
        end)
        transfer.refreshImport=updateImportAvailability
        updateImportAvailability()
        button(importPanel,"Undo Last Change",251,19,160,function()
            if not api.UndoMixolasEdit then
                importStatus:SetText("Undo is unavailable; no changes made.")
                return
            end
            local ok,message=api.UndoMixolasEdit()
            importStatus:SetText(tostring(message or (ok and "Previous change restored." or "Nothing to undo.")))
        end)
        button(importPanel,"Clear Input",423,19,128,function()
            importEdit:SetText("")
        end)
        button(importPanel,"Close",597,19,122,function()
            importEdit:ClearFocus();transfer:Hide()
        end)
        transfer:SetScript("OnHide",function() pickerMenu:Hide() end)
        transfer:Hide()
        if UISpecialFrames then table.insert(UISpecialFrames,"MixolasBarsBindingsTransferWindow") end
    end
    transfer.pickMode("all")
    transfer.exportEdit:SetText("")
    transfer.importEdit:SetText("")
    transfer.selectTab("export")
    if transfer.refreshProfileHeader then transfer.refreshProfileHeader() end
    if transfer.profileMenu then transfer.profileMenu:Hide() end
    transfer:Show()
end
api.OpenBindingImportExport=openTransfer

local combat=CreateFrame("Frame")
combat:RegisterEvent("PLAYER_REGEN_DISABLED")
combat:SetScript("OnEvent",function() if editing then finish(false) end end)
