-- Mixolas Bars v0.19.16: queued next-swing ability indicators.
-- Uses the same native IsCurrentAction/IsCurrentSpell states checked by Blizzard
-- action buttons. Never guesses from button presses, swing timers or combat logs.
local api=_G.MixolasBarsAPI
if not api then return end
local QUEUED_BASE_IDS={78,845,6807,2973} -- Heroic Strike, Cleave, Maul, Raptor Strike
local queuedNames={}
local nameCache={}
local function callBoolean(fn,...)
    if type(fn)~="function" then return false end
    -- Comparisons inside pcall also protect the client from restricted values.
    local ok,v=pcall(function(...) return fn(...) == true end,...)
    return ok and v or false
end
local function getInfo(id)
    if not id then return nil end
    if nameCache[id] then return nameCache[id] end
    if C_Spell and C_Spell.GetSpellInfo then
        local ok,t=pcall(C_Spell.GetSpellInfo,id)
        if ok and type(t)=="table" and type(t.name)=="string" then
            nameCache[id]=t.name
            return t.name
        end
    end
    if GetSpellInfo then
        local ok,name=pcall(GetSpellInfo,id)
        if ok and type(name)=="string" then nameCache[id]=name;return name end
    end
end
local function isQueuedAbility(spellID)
    if not spellID then return false end
    if not next(queuedNames) then
        for _,id in ipairs(QUEUED_BASE_IDS) do
            local name=getInfo(id)
            if name then queuedNames[name]=true end
        end
    end
    local name=getInfo(spellID)
    return name~=nil and queuedNames[name]==true
end
local function getSlot(button)
    if not button or button.isCustom then return nil end
    local ok,slot=pcall(function() return button:GetAttribute("action") or button.actionSlot end)
    if ok and type(slot)=="number" then return slot end
end
local function getSpellFromAction(slot)
    if not slot or not GetActionInfo then return nil end
    local ok,kind,id=pcall(GetActionInfo,slot)
    if not ok then return nil end
    if kind=="spell" then return id end
    if kind=="macro" and GetMacroSpell then
        local ok2,spellID=pcall(GetMacroSpell,id)
        if ok2 then return spellID end
    end
end
local function activeState(button)
    local spellID,slot=getSlot(button),nil
    if button.isCustom then
        local db=api.GetDB and api.GetDB()
        local entry=db and db.customActions and db.customActions[tostring(button.slot)]
        if entry then
            if entry.kind=="spell" then spellID=entry.value
            elseif entry.kind=="macro" and GetMacroSpell then
                local ok,id=pcall(GetMacroSpell,entry.value)
                if ok then spellID=id end
            end
        end
    else
        slot=spellID
        spellID=getSpellFromAction(slot)
    end
    if not isQueuedAbility(spellID) then return false end
    if slot then
        if C_ActionBar and callBoolean(C_ActionBar.IsCurrentAction,slot) then return true end
        if callBoolean(IsCurrentAction,slot) then return true end
    end
    if C_Spell and callBoolean(C_Spell.IsCurrentSpell,spellID) then return true end
    return callBoolean(IsCurrentSpell,spellID)
end
local function ensureRing(button)
    if button.mxbQueuedRing then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local ring=button:CreateTexture(nil,"OVERLAY",nil,7)
    ring:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    ring:SetBlendMode("ADD")
    ring:SetVertexColor(1,0.83,0.24,0.95)
    ring:SetPoint("TOPLEFT",button,"TOPLEFT",-7,7)
    ring:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",7,-7)
    ring:Hide()
    button.mxbQueuedRing=ring
end
local function update(button)
    if not button or not button.CreateTexture then return false end
    ensureRing(button)
    if not button.mxbQueuedRing then return false end
    local visible=button.IsVisible and button:IsVisible()
    -- The border is status only. It must not change spell execution or input.
    local queued=visible and activeState(button)
    button.mxbQueuedRing:SetShown(queued and true or false)
    return queued and true or false
end
api.RefreshQueuedActionStates=function()
    if not api.IsReady or not api.IsReady() then return end
    for _,cluster in ipairs(api.GetClusters() or {}) do
        for _,button in ipairs(cluster.buttons or {}) do update(button) end
    end
    for _,button in ipairs(api.GetRegularButtons() or {}) do update(button) end
end
api.UpdateQueuedActionButton=update
local frame=CreateFrame("Frame")
for _,name in ipairs({"ACTIONBAR_UPDATE_STATE","ACTIONBAR_SLOT_CHANGED",
    "CURRENT_SPELL_CAST_CHANGED","SPELL_UPDATE_USABLE","UNIT_SPELLCAST_SUCCEEDED",
    "PLAYER_ENTERING_WORLD","UPDATE_SHAPESHIFT_FORM"}) do frame:RegisterEvent(name) end
frame:SetScript("OnEvent",function() api.RefreshQueuedActionStates() end)
local elapsed=0
frame:SetScript("OnUpdate",function(_,dt)
    elapsed=elapsed+dt
    if elapsed < 0.12 then return end
    elapsed=0
    api.RefreshQueuedActionStates()
end)
SLASH_MIXOLASQUEUED1="/mxbqueue"
SlashCmdList["MIXOLASQUEUED"]=function()
    local found=0
    for _,b in ipairs(api.GetRegularButtons() or {}) do
        local slot=getSlot(b)
        if slot and isQueuedAbility(getSpellFromAction(slot)) then
            found=found+1
            if api.Say then api.Say("Queued spell: slot "..slot.." / Bar "..tostring(b.barNumber).." / active="..tostring(update(b))) end
        end
    end
    for _,c in ipairs(api.GetClusters() or {}) do
        for _,b in ipairs(c.buttons or {}) do
            local slot=getSlot(b)
            if slot and isQueuedAbility(getSpellFromAction(slot)) then
                found=found+1
                if api.Say then api.Say("Queued spell: diamond slot "..slot.." / active="..tostring(update(b))) end
            end
        end
    end
    if found==0 and api.Say then api.Say("No native queued abilities found on Mixolas buttons.") end
end
