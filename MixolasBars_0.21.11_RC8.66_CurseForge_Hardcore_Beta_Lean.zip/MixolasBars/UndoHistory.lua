-- Mixolas Bars 0.20.1-dev2: session undo/redo for addon-owned data.
-- Never writes Blizzard spell slots or secure attributes during combat.
-- RC8.20 also snapshots native WoW keys so binding imports can be undone.
local api=_G.MixolasBarsAPI
if not api then return end
local LIMIT=25
local FIELDS={
 'locked','snapEnabled','visible','editorScale','buttonSize','gap','diamondGapEW','diamondGapNS',
 'glow','borderAlpha','borderWidth','illuminationStyle','diamondGlows','diamondIlluminationStyles','glowSpread','glowSaturation',
 'hotkeyFontSize','itemCountFontSize','showHotkeys','showMacroNames','rangeDim','combatDim','buttonLock',
 'gcdSweep','gcdDarkness','counts','diamondEnabled','alphas','combatAlphas','brightness','scales',
 'borderStyles','glowMotions','colors','positions','regularBars','utilityBars',
 'decorFrames','frameStudio','minimapAngle','minimapSize','hideBlizzard','hideBlizzardArt',
 'nativeBindingInheritance','obsidianPrototype','activationFlash',
 'mixolasProfiles','advancedSettings','advancedAppearance',
}
local points,index={},0
local pointLabels={}
local ready=false
local restoring=false
local nested=0
local continuousDepth=0
local continuousLabel=nil
local continuousOwner=nil
local changeNotify
local function clone(obj,depth)
 local t=type(obj)
 if t~='table' then
  if t=='string' or t=='number' or t=='boolean' then return obj end
  return nil
 end
 if (depth or 0)>20 then return nil end
 local copy={}
 for k,v in pairs(obj) do
  if type(k)=='number' or type(k)=='string' then
   local t=type(v)
   if t=='table' or t=='number' or t=='string' or t=='boolean' then
    copy[k]=clone(v,(depth or 0)+1)
   end
  end
 end
 return copy
end
local function equal(a,b,depth)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 if (depth or 0)>20 then return true end
 for k,v in pairs(a) do if not equal(v,b[k],(depth or 0)+1) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
local function capture()
 local db=api.GetDB and api.GetDB()
 local char=api.GetCharacterDB and api.GetCharacterDB()
 if not db or not char then return nil end
 local snap={layout={},bindings=clone(char.bindings or db.bindings or {}),
   customActions=clone(char.customActions or db.customActions or {}),
   activeLayoutProfile=char.activeLayoutProfile}
 -- Native bindings are deliberately separate from button assignments.
 -- Retain their live state in the same timeline as Mixolas profiles.
 if api.CaptureNativeBindings then
  local native=api.CaptureNativeBindings()
  if native then snap.nativeBindings=clone(native) end
 end
 for _,name in ipairs(FIELDS) do if db[name]~=nil then snap.layout[name]=clone(db[name]) end end
 return snap
end
local function announce(s)
 if api.Say then api.Say(s)
 elseif DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage('Mixolas Bars: '..tostring(s)) end
end
local function legal()
 return api.IsReady and api.IsReady() and not (api.IsInCombat and api.IsInCombat())
   and not (InCombatLockdown and InCombatLockdown())
end
local function notify()
 if changeNotify then pcall(changeNotify) end
end
local function addCurrent(reason)
 if restoring or not legal() then return false end
 local snap=capture()
 if not snap then return false end
 if not ready then
  points={snap};pointLabels={'Startup'};index=1;ready=true;notify();return true
 end
 if equal(snap,points[index]) then return false end
 for i=#points,index+1,-1 do points[i]=nil;pointLabels[i]=nil end
 points[#points+1]=snap
 pointLabels[#points]=tostring(reason or 'Edited settings')
 if #points>LIMIT then table.remove(points,1);table.remove(pointLabels,1) else index=index+1 end
 notify()
 return true
end
-- One user action in the "ALL" diamond editor updates eight diamond values.
-- Group their individual setters into one Undo/Redo history step.
api.CanRecordUndo=function()
 return ready and not restoring and continuousDepth==0 and legal()
end
api.RunBatchEdit=function(label,fn)
 if type(fn)~='function' or not legal() then return false end
 if nested==0 then addCurrent('Before '..tostring(label or 'batch')) end
 nested=nested+1
 local ok,result=pcall(fn)
 nested=nested-1
 if nested==0 then addCurrent(tostring(label or 'batch')) end
 if not ok then error(result) end
 return result~=false
end

-- Each physical slider interaction has its own undo boundary. A second slider
-- can start within the same frame as the first mouse release, so time-based
-- coalescing is inappropriate here: close the prior owner's edit *before*
-- the next control changes its setting. One drag still has live intermediate
-- updates but only one committed history snapshot on release.
api.BeginContinuousEdit=function(label,owner)
 if not ready or restoring or not legal() then return false end
 local nextOwner=tostring(owner or label or 'Slider adjustment')
 if continuousDepth>0 then
  if continuousOwner==nextOwner then return true end
  -- A prior control may have missed OnMouseUp during a rapid pointer move.
  -- Its state must be recorded before this control begins to change.
  api.EndContinuousEdit(continuousOwner)
 end
 if continuousDepth>0 then return false end
 continuousLabel=tostring(label or 'Slider adjustment')
 continuousOwner=nextOwner
 if nested==0 then addCurrent('Before '..continuousLabel) end
 continuousDepth=1
 nested=nested+1
 return true
end
api.EndContinuousEdit=function(owner)
 if continuousDepth==0 then return false end
 if owner~=nil and tostring(owner)~=continuousOwner then return false end
 local label=continuousLabel or 'Slider adjustment'
 continuousDepth=0
 continuousOwner=nil
 continuousLabel=nil
 nested=math.max(0,nested-1)
 if nested==0 then addCurrent(label) end
 return true
end

-- Mutator hooks group each UI operation as a single history point, including
-- nested profile operations. A throttled observer covers sliders and cursor
-- drags that change SavedVariables directly rather than through the API.
local mutators={
 'Change','SetDiamondEnabled','ChangeColor','SetCount','SetDiamondGlow','SetDiamondLighting','SetDiamondGlowMotion','SetDiamondBorderStyle','SetDiamondOutOpacity','SetDiamondCombatOpacity','ResetPositions','Reset',
 'SetRegularBar','DockRegularBar','SetUtilityBar',
 'AddDecor','SetDecor','SetDecorColor','RemoveDecor',
 'SetCharacterBindings','ImportBindings','SaveBindingMode',
 'SaveNamedProfile','CreateNamedProfile','SaveActiveProfile','LoadNamedProfile','SwitchNamedProfile',
 'DeleteNamedProfile','CopyNamedProfile','ResetActiveProfile',
 'RestoreLayoutSnapshot','SetHideBlizzard','SetHideBlizzardArt',
 'SetAppearanceOption','SetDiamondSpacing','SetDiamondScale',
 'ApplySixDiamondLayout','SetLayoutSpacing',
 'SetFrameStudioOption','ResetFrameStudioStyle',
}
for _,name in ipairs(mutators) do
 local original=api[name]
 if type(original)=='function' then
  api[name]=function(...)
   if not ready or restoring or not legal() then return original(...) end
   if nested==0 then addCurrent('Before '..name) end
   nested=nested+1
   local result={pcall(original,...)}
   nested=nested-1
   if nested==0 then addCurrent(name) end
   if not result[1] then error(result[2]) end
   return unpack(result,2)
  end
 end
end
-- DragController also changes values outside API setters. Its save callback
-- happens after positions have been committed; committing here makes the
-- corresponding arrow immediately available.
if type(api.MarkVisualLayoutDirty)=='function' then
 local prev=api.MarkVisualLayoutDirty
 api.MarkVisualLayoutDirty=function(...)
  local values={prev(...)}
  if nested==0 then addCurrent('Position change') end
  return unpack(values)
 end
end
local function refresh()
 local tasks={'Refresh','RefreshRegularBars','RefreshUtilityBars',
   'ReloadDecorFromConfig','RefreshFrameStudio','RefreshCustomActions','RefreshIcons',
   'RefreshRegularActionIcons','RefreshHotkeys','ReapplyBindings',
   'UpdateGCD','UpdateMinimapIcon','RefreshRegularHandles',
   'RefreshUtilityHandles','RefreshDecorHandles','RefreshLayoutGuides'}
 for _,name in ipairs(tasks) do
  local fn=api[name]
  if type(fn)=='function' then
   local ok,reason=pcall(fn)
   if not ok then return false,name..': '..tostring(reason) end
  end
 end
 local c=api.GetDB()
 local blizzard=_G.MixolasBarsBlizzardVisibility
 if blizzard and c then
  if blizzard.SetHiddenButtons then
   local ok,reason=pcall(blizzard.SetHiddenButtons,c.hideBlizzard)
   if not ok then return false,'Blizzard buttons: '..tostring(reason) end
  end
  if blizzard.SetHiddenArt then
   local ok,reason=pcall(blizzard.SetHiddenArt,c.hideBlizzardArt)
   if not ok then return false,'Blizzard art: '..tostring(reason) end
  end
 end
 local theme=_G.MixolasBarsObsidian
 if theme and theme.Apply then
  local ok,reason=pcall(theme.Apply)
  if not ok then return false,'Visual appearance: '..tostring(reason) end
 end
 if api.UpdateSettingsUI then pcall(api.UpdateSettingsUI) end
 return true
end
-- Binding-only batches (particularly Clear Native/All) must not rebuild every
-- action bar, artwork surface and settings page when the only changed state
-- is shortcuts. Avoid WoW's per-frame script watchdog on the Undo hot path.
-- This path is used ONLY when the adjacent committed snapshots have identical
-- visual layouts and identical profile artwork, so no visual changes are lost.
local function sameVisuals(a,b)
 if not a or not b or a.activeLayoutProfile~=b.activeLayoutProfile
     or not equal(a.customActions,b.customActions) then return false end
 for _,field in ipairs(FIELDS) do
  if field~='mixolasProfiles' and not equal(a.layout[field],b.layout[field]) then return false end
 end
 local pa=(a.layout or {}).mixolasProfiles or {}
 local pb=(b.layout or {}).mixolasProfiles or {}
 for name,profile in pairs(pa) do
  local other=pb[name]
  if not other or not equal(profile.layout,other.layout) then return false end
 end
 for name in pairs(pb) do if not pa[name] then return false end end
 return true
end
local function applyBindingsOnly(target)
 if not legal() then return false,'Available only outside combat.' end
 local db=api.GetDB and api.GetDB()
 local char=api.GetCharacterDB and api.GetCharacterDB()
 if not db or not char then return false,'Character data is unavailable.' end
 -- Native writes can trigger automatic active-profile saves. Publish the
 -- exact target profile library AFTER both binding systems have been applied.
 if target.nativeBindings and api.RestoreNativeBindings then
  local live=api.CaptureNativeBindings and api.CaptureNativeBindings()
  if not live then return false,'Cannot inspect native keys for Undo.' end
  if not equal(live.keys,target.nativeBindings.keys) then
   local ok,why=api.RestoreNativeBindings(target.nativeBindings)
   if not ok then return false,'Native restore failed: '..tostring(why) end
  end
 end
 if api.SetCharacterBindings then
  if api.SetCharacterBindings(clone(target.bindings or {}))==false then
   return false,'Mixolas shortcuts could not be restored.'
  end
 else
  char.bindings=clone(target.bindings or {})
  db.bindings=char.bindings
 end
 db.mixolasProfiles=clone((target.layout or {}).mixolasProfiles or {})
 char.activeLayoutProfile=target.activeLayoutProfile
 if api.ApplyBindings then
  local ok,accepted=pcall(api.ApplyBindings)
  if not ok or accepted==false then return false,'Bar shortcut routing failed.' end
 end
 if api.RefreshHotkeys then pcall(api.RefreshHotkeys) end
 if api.UpdateSettingsUI then pcall(api.UpdateSettingsUI) end
 return true
end
local function applySnapshot(target)
 if not legal() then return false,'Available only outside combat.' end
 if type(target)~='table' or type(target.layout)~='table' then return false,'Invalid restore point.' end
 local db=api.GetDB()
 local char=api.GetCharacterDB()
 if not db or not char then return false,'Character data is unavailable.' end
 -- Copy all state BEFORE refreshing the secure action presentations. This
 -- does not touch Blizzard-owned action slots, spells or native bindings.
 for _,name in ipairs(FIELDS) do
  db[name]=clone(target.layout[name])
 end
 char.customActions=clone(target.customActions or {})
 db.customActions=char.customActions
 if api.SetCharacterBindings then
  if api.SetCharacterBindings(clone(target.bindings or {}))==false then
   return false,'Character shortcuts could not be restored.'
  end
 else
  char.bindings=clone(target.bindings or {})
  db.bindings=char.bindings
 end
 char.activeLayoutProfile=target.activeLayoutProfile
 -- Restore the native keys before publishing the saved profile library.
 -- Do not touch WoW keys if they already match the snapshot.
 if target.nativeBindings and api.RestoreNativeBindings then
  local live=api.CaptureNativeBindings and api.CaptureNativeBindings()
  if not live then return false,'Could not inspect native bindings for Undo.' end
  if not equal(live.keys,target.nativeBindings.keys) then
   local ok,why=api.RestoreNativeBindings(target.nativeBindings)
   if not ok then return false,'Native binding restore failed: '..tostring(why) end
  end
 end
 -- A profile change may have autosaved through SetCharacterBindings; put back
 -- the exact saved profile library after restoring character-owned keys.
 db.mixolasProfiles=clone(target.layout.mixolasProfiles or {})
 if api.MarkVisualLayoutDirty then pcall(api.MarkVisualLayoutDirty) end
 -- Another autosave may have rewritten the profile library; the timeline owns
 -- this snapshot, not the other way round.
 db.mixolasProfiles=clone(target.layout.mixolasProfiles or {})
 return refresh()
end
local function travel(delta)
 if continuousDepth>0 then return false,'Finish dragging the slider before using Undo or Redo.' end
 if not ready then return false,'Undo history is still initializing.' end
 if not legal() then return false,'Undo/redo is unavailable during combat.' end
 -- Capture unsaved final settings/drag changes before time travel.
 if delta<0 then addCurrent('Latest edit') end
 local wanted=index+delta
 if wanted<1 or wanted>#points then return false,delta<0 and 'Nothing to undo.' or 'Nothing to redo.' end
 local previous=capture()
 local destination=points[wanted]
 -- A completed binding-clear batch is one history entry. Undoing or redoing
 -- that entry needs shortcuts restored, not the expensive full visual refresh.
 -- Never take this fast path if unrelated appearance/profile layout changed.
 local entryLabel=delta<0 and pointLabels[index] or pointLabels[wanted]
 local bindingsOnly=type(entryLabel)=='string' and
     entryLabel:match('^Clear .+ keybindings$') and sameVisuals(points[index],destination)
 local apply=bindingsOnly and applyBindingsOnly or applySnapshot
 restoring=true
 local ok,done,reason=pcall(apply,destination)
 if not ok or not done then
  -- Do not advance the timeline on a failed restoration.
  pcall(apply,previous)
  restoring=false
  notify()
  return false,(ok and reason or done) or 'Undo/redo failed.'
 end
 index=wanted
 restoring=false
 notify()
 return true,delta<0 and 'Undid Mixolas edit.' or 'Redid Mixolas edit.'
end
api.UndoMixolasEdit=function() return travel(-1) end
api.RedoMixolasEdit=function() return travel(1) end
api.GetUndoRedoStatus=function()
 if not ready then return false,false end
 -- Button status uses committed timeline; direct slider edits are committed
 -- on the next observation tick or when undo is clicked.
 return index>1,index<#points,index,#points
end
api.SetUndoRedoChanged=function(callback)
 if type(callback)=='function' then changeNotify=callback;notify() end
end
local f=CreateFrame('Frame')
f:RegisterEvent('PLAYER_LOGIN')
local startup=0
local elapsed=0
f:SetScript('OnEvent',function()
 startup=(GetTime and GetTime() or 0)+1.5
end)
f:SetScript('OnUpdate',function(_,dt)
 if not legal() or restoring or nested>0 then return end
 if startup>0 and (GetTime and GetTime() or 0)<startup then return end
 elapsed=elapsed+(dt or 0)
 if elapsed<1.05 then return end
 elapsed=0
 addCurrent('Edited settings')
end)
SLASH_MIXOLASUNDO1='/mxbundo'
SLASH_MIXOLASREDO1='/mxbredo'
SlashCmdList.MIXOLASUNDO=function()
 local ok,msg=api.UndoMixolasEdit();announce(msg)
end
SlashCmdList.MIXOLASREDO=function()
 local ok,msg=api.RedoMixolasEdit();announce(msg)
end
