-- Mixolas Bars Forever compatibility helpers. Independent implementation.
-- Prefer the interface-16001 C_* APIs; Classic fallbacks are deliberately
-- isolated here. These helpers query presentation only: never cast spells.
local compat = {}
_G.MixolasBarsCompat = compat

local function result(fn, ...)
    if type(fn) ~= "function" then return nil, nil, false end
    local ok, a, b = pcall(fn, ...)
    if not ok then return nil, nil, false end
    -- Forever shares modern secret-value restrictions. An unreadable value
    -- is not evidence that an action is usable or unusable.
    if issecretvalue then
        local readable, secret = pcall(issecretvalue, a)
        if not readable or secret then return nil, nil, false end
        readable, secret = pcall(issecretvalue, b)
        if not readable or secret then return nil, nil, false end
    end
    return a, b, true
end

function compat.SpellName(id)
    if not id then return nil end
    if type(id) == "string" then return id end
    if C_Spell and C_Spell.GetSpellInfo then
        local info, _, ok = result(C_Spell.GetSpellInfo, id)
        if ok and type(info) == "table" then return info.name end
    end
    local name, _, ok = result(GetSpellInfo, id)
    return ok and name or nil
end

function compat.SpellTexture(id)
    local texture, _, ok
    if C_Spell and C_Spell.GetSpellTexture then
        texture, _, ok = result(C_Spell.GetSpellTexture, id)
        if ok and texture then return texture end
    end
    texture, _, ok = result(GetSpellTexture, id)
    return ok and texture or nil
end

-- The cursor spell payload varies by API generation. Resolve its actual
-- rank-specific ID from Classic spellbook APIs before creating secure actions.
function compat.CursorSpellID(index, bookType, spellID)
    if type(spellID)=="number" and spellID>0 then return spellID end
    if type(index)~="number" or index<1 then return nil end
    if type(GetSpellBookItemInfo)=="function" then
        local ok, kind, id=pcall(GetSpellBookItemInfo,index,bookType or "spell")
        if ok and kind=="SPELL" and type(id)=="number" and id>0 then return id end
    end
    if C_SpellBook and type(C_SpellBook.GetSpellBookItemInfo)=="function" then
        local bank = Enum and Enum.SpellBookSpellBank
        bank = bank and (bookType=="pet" and bank.Pet or bank.Player)
        if bank then
            local ok, info=pcall(C_SpellBook.GetSpellBookItemInfo,index,bank)
            if ok and type(info)=="table" and type(info.spellID)=="number"
                and info.spellID>0 then return info.spellID end
        end
    end
    if type(GetSpellInfo)=="function" then
        local ok, _,_,_,_,_,_,id=pcall(GetSpellInfo,index,bookType or "spell")
        if ok and type(id)=="number" and id>0 then return id end
    end
    return nil
end

-- Macro labels are presentation-only. The actual action remains secure/native.
-- GetActionText is the canonical action-slot macro label when exposed.
function compat.MacroName(id)
    if not id or type(GetMacroInfo) ~= "function" then return nil end
    local name, _, ok = result(GetMacroInfo,id)
    return ok and type(name)=="string" and name~="" and name or nil
end

function compat.ActionMacroName(slot)
    if not slot then return nil end
    if type(GetActionText)=="function" then
        local name,_,ok=result(GetActionText,slot)
        if ok and type(name)=="string" and name~="" then return name end
    end
    if type(GetActionInfo)=="function" then
        local kind,id,ok=result(GetActionInfo,slot)
        if ok and kind=="macro" then return compat.MacroName(id) end
    end
    return nil
end

function compat.ActionTexture(slot)
    if not slot then return nil end
    local t, _, ok
    if C_ActionBar and C_ActionBar.GetActionTexture then
        t, _, ok = result(C_ActionBar.GetActionTexture, slot)
        if ok then return t end
    end
    t, _, ok = result(GetActionTexture, slot)
    return ok and t or nil
end

function compat.ActionHas(slot)
    if not slot then return false end
    local fn=C_ActionBar and C_ActionBar.HasAction or HasAction
    local has, _, ok=result(fn,slot)
    if ok then return has == true end
    return nil
end

function compat.ActionUsable(slot)
    if not slot then return nil,nil,false end
    local fn=C_ActionBar and C_ActionBar.IsUsableAction or IsUsableAction
    return result(fn, slot)
end

function compat.SpellUsable(spellID)
    if not spellID then return nil,nil,false end
    local fn=C_Spell and C_Spell.IsSpellUsable or IsUsableSpell
    return result(fn,spellID)
end

function compat.ItemUsable(itemID)
    if not itemID then return nil,nil,false end
    local fn=C_Item and C_Item.IsUsableItem or IsUsableItem
    return result(fn,itemID)
end

function compat.ActionRange(slot)
    if not slot then return nil end
    local fn=C_ActionBar and C_ActionBar.IsActionInRange or IsActionInRange
    local range, _, ok=result(fn,slot,"target")
    if ok then return range end
    return nil
end

function compat.SpellRange(id)
    if not id then return nil end
    local fn=C_Spell and C_Spell.IsSpellInRange or IsSpellInRange
    local range, _, ok=result(fn,id,"target")
    if ok then return range end
    return nil
end

function compat.ActionCount(slot)
    if not slot then return nil end
    local fn=C_ActionBar and C_ActionBar.GetActionUseCount or GetActionCount
    local count,_,ok=result(fn,slot)
    return ok and count or nil
end

function compat.ItemCount(id)
    if not id then return nil end
    local fn=C_Item and C_Item.GetItemCount or GetItemCount
    local count,_,ok=result(fn,id)
    return ok and count or nil
end

function compat.ActionCooldown(slot)
    if not slot then return nil end
    if C_ActionBar and C_ActionBar.GetActionCooldown then
        local info,_,ok=result(C_ActionBar.GetActionCooldown,slot)
        if ok and type(info)=="table" then
            return info.startTime,info.duration,info.isEnabled
        end
    end
    if GetActionCooldown then
        local ok,a,b,c=pcall(GetActionCooldown,slot)
        if ok then return a,b,c end
    end
    return nil
end

function compat.SpellCooldown(id)
    if not id then return nil end
    if C_Spell and C_Spell.GetSpellCooldown then
        local info,_,ok=result(C_Spell.GetSpellCooldown,id)
        if ok and type(info)=="table" then
            return info.startTime,info.duration,info.isEnabled
        end
    end
    if GetSpellCooldown then
        local ok,a,b,c=pcall(GetSpellCooldown,id)
        if ok then return a,b,c end
    end
    return nil
end

-- Modern WoW / Forever returns opaque duration objects for cooldown display.
-- Do not inspect their numeric fields: they may be secret during combat.
-- The optional ignoreGCD flag lets the ordinary action cooldown renderer
-- honor Mixolas's GCD-swipe toggle without manufacturing a fake GCD.
function compat.ActionCooldownDuration(slot, ignoreGCD)
    if not slot or not (C_ActionBar and C_ActionBar.GetActionCooldownDuration) then return nil end
    local ok, duration=pcall(C_ActionBar.GetActionCooldownDuration,slot,ignoreGCD)
    return ok and duration or nil
end

function compat.SpellCooldownDuration(id, ignoreGCD)
    if not id or not (C_Spell and C_Spell.GetSpellCooldownDuration) then return nil end
    local ok, duration=pcall(C_Spell.GetSpellCooldownDuration,id,ignoreGCD)
    return ok and duration or nil
end

function compat.ItemCooldown(id)
    if not id then return nil end
    if C_Item and C_Item.GetItemCooldown then
        local ok,a,b,c=pcall(C_Item.GetItemCooldown,id)
        if ok then return a,b,c end
    end
    if GetItemCooldown then
        local ok,a,b,c=pcall(GetItemCooldown,id)
        if ok then return a,b,c end
    end
    return nil
end
