MIXOLAS BARS
Version: 0.21.11-rc.8.66
Author: Mixolas HasKill

PUBLIC BETA: SUPPORTED GAME CLIENT
- World of Warcraft Classic Era / Hardcore (interface 11509, 1.15.9)
- Compatibility with other WoW game clients has not been verified for this release.

ABOUT
Mixolas Bars provides controller-first action bars, modular layouts, modifier
Diamonds, customizable frame styles, profile management, and keybinding tools.
The built-in MIXOLAS preset contains the author's Hardcore bar positions,
appearance preferences, Mixolas bindings, and native WoW bindings.

INSTALLATION
1. Close World of Warcraft.
2. Extract this ZIP so the addon is at Interface/AddOns/MixolasBars/
   and that folder contains MixolasBars.toc.
3. Replace the old MixolasBars folder when updating manually. Do not delete
   account or character SavedVariables; back up WTF before upgrading.
4. Start WoW and enable the addon in the AddOns list.

FIRST-TIME SETUP
- MIXOLAS is the protected built-in default, which is not renameable/deletable.
- Editing it creates a new, editable personal profile.
- Selecting MIXOLAS again creates another editable personal profile.
- Applying the built-in native WoW keybindings requires your confirmation.
  These can replace existing Blizzard shortcuts. Back up before applying.
- Open Portable Settings with /mxbtransfer for export/import.
- Blizzard action-slot spell placements and macro contents are not included
  in the portable configuration and must be set independently.
- Save View and Set View keybinds are provided; configure your preferred
  camera perspectives in-game.

COMPANION STEAM INPUT CONFIGURATIONS (STEAM CONTROLLER 2)
These two different layouts must each be applied in the correct place.
1. WoW gameplay layout: https://steaminputdb.com/config/3830487043
   Apply to your Battle.net non-Steam entry in Steam Library. This controls
   the WoW gameplay actions and input mapping.
2. Steam button / Guide Button Chord layout:
   https://steaminputdb.com/config/3830487378
   Apply under Steam > Settings > Controller > Guide Button Chord Layout.
   This configures the Steam-button chord controls, separately from WoW.
Both layouts use Steam Input and are NOT installed by the Mixolas Bars addon.

NOTES
- If other action-bar addons conflict, temporarily disable them for diagnosis.
- This release was live-tested in Classic Era / Hardcore, but fresh install
  on a second computer remains a separate QA step.

FREE COMMUNITY PROJECT
Created by Mixolas HasKill.

MINIMAP LAUNCHER (RC8.66)
The gold MH emblem opens settings with left-click, opens keybind mode with
right-click (out of combat), and can be dragged around the minimap. Change
its size in the General settings.
