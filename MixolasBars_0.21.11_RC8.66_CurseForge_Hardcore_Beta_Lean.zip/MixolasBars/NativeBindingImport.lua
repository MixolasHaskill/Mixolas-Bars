-- Mixolas Bars RC8.20: native WoW (MXBN1) import, direct/undoable.
-- Never import bar bindings or layouts here. Uses the existing native
-- transactional restore and active-profile auto-save paths.
local api = _G.MixolasBarsAPI
if not api then return end
local MAX_TEXT,MAX_KEYS=60000,4096
local function encode(s)
    return (s:gsub('([^A-Za-z0-9_%-])', function(c)
        return string.format('%%%02X',string.byte(c))
    end))
end
local function decode(s)
    if type(s)~='string' or s=='' then return nil end
    local result=s:gsub('%%(%x%x)',function(pair) return string.char(tonumber(pair,16)) end)
    if encode(result)~=s then return nil end
    return result
end
local function parse(raw)
    if type(raw)~='string' or #raw>MAX_TEXT then return nil,'Invalid or overly long native import.' end
    raw=raw:match('^%s*(.-)%s*$')
    if raw~='MXBN1' and raw:sub(1,6)~='MXBN1;' then
        return nil,'Expected an MXBN1 Native WoW Keybinds export.'
    end
    local keys,n={},0
    local body=raw:sub(7)
    if body~='' then
        if body:sub(1,1)==';' or body:sub(-1)==';' or body:find(';;',1,true) then
            return nil,'Malformed native keybinding entries.'
        end
        for entry in body:gmatch('[^;]+') do
            local encodedKey,encodedCommand=entry:match('^([^=]+)=(.+)$')
            local key=decode(encodedKey)
            local command=decode(encodedCommand)
            if not key or not command or #key>64 or #command>256
                or key:find('%c') or command:find('%c') then
                return nil,'Malformed or invalid native binding: '..entry:sub(1,60)
            end
            if keys[key] then return nil,'Duplicate key in native import: '..key end
            n=n+1
            if n>MAX_KEYS then return nil,'Native import contains too many keys.' end
            keys[key]=command
        end
    end
    return {version=1,keys=keys},nil
end
local function same(a,b)
    for k,v in pairs(a or {}) do if b[k]~=v then return false end end
    for k,v in pairs(b or {}) do if a[k]~=v then return false end end
    return true
end
local function canImport()
    if not api.IsReady or not api.IsReady() then return nil,'Wait for the addon to finish loading.' end
    if (api.IsInCombat and api.IsInCombat()) or (InCombatLockdown and InCombatLockdown()) then
        return nil,'Cannot import bindings during combat.'
    end
    if api.IsBindingMode and api.IsBindingMode() then
        return nil,'Close mouseover keybinding mode before importing.'
    end
    local name=api.GetActiveProfileName and api.GetActiveProfileName()
    if not name then return nil,'Select or create a named Mixolas profile first.' end
    if type(api.RestoreNativeBindings)~='function' or type(api.SaveActiveNativeBindings)~='function' then
        return nil,'WoW native binding/profile services are unavailable.'
    end
    return name
end
local function makePlan(raw)
    local profile,why=canImport()
    if not profile then return nil,why end
    local snapshot,err=parse(raw)
    if not snapshot then return nil,err end
    local known,message=api.GetNativeBindingCommands()
    if not known then return nil,message end
    local live,reason=api.CaptureNativeBindings()
    if not live then return nil,reason end
    local effective,unknown,customOverlaps={},0,{}
    for key,command in pairs(snapshot.keys) do
        if known[command] then
            effective[key]=command
        else
            unknown=unknown+1
            -- Mirrors NativeBindings.RestoreNativeBindings: an unknown
            -- command never unbinds something valid at this key.
            if live.keys[key] then effective[key]=live.keys[key] end
        end
    end
    local changes={}
    for key,cmd in pairs(live.keys) do
        if effective[key]~=cmd then changes[#changes+1]={key=key,before=cmd,after=effective[key]} end
    end
    for key,cmd in pairs(effective) do
        if live.keys[key]==nil then changes[#changes+1]={key=key,before=nil,after=cmd} end
    end
    table.sort(changes,function(a,b) return a.key<b.key end)
    -- A native import must never silently hijack a Mixolas override.
    local custom={}
    local db=api.GetDB and api.GetDB()
    for _,keys in pairs((db and db.bindings) or {}) do
        if type(keys)=='table' then
            for _,key in ipairs(keys) do custom[key]=true end
        end
    end
    for _,change in ipairs(changes) do
        if change.after and custom[change.key] then
            customOverlaps[#customOverlaps+1]=change.key
        end
    end
    return {profile=profile,raw=raw,source=snapshot,live=live,
        changes=changes,unknown=unknown,overlaps=customOverlaps},nil
end
api.PreviewNativeBindingImport=makePlan
api.ApplyNativeBindingImport=function(raw)
    -- Revalidate the pasted content, destination profile, live WoW keys and
    -- Mixolas conflicts each time Import is clicked; no UI preview required.
    local fresh,why=makePlan(raw)
    if not fresh then return false,why end
    local profile=fresh.profile
    if #fresh.overlaps>0 then
        return false,'Native import conflicts with Mixolas bar keys: '..table.concat(fresh.overlaps,', ')..'. Resolve those keys before importing.'
    end
    local ok,info=api.RestoreNativeBindings(fresh.source)
    if not ok then return false,'WoW rejected the native import: '..tostring(info) end
    -- Snapshots are normally updated on UPDATE_BINDINGS next frame; commit
    -- synchronously too, so switching profiles immediately still isolates keys.
    local saved,saveMessage=api.SaveActiveNativeBindings()
    if not saved then
        local restored,restoreReason=api.RestoreNativeBindings(fresh.live)
        return false,'Imported keys could not be saved to profile. '..
            (restored and 'Original WoW bindings restored.'
                or 'ROLLBACK FAILED: '..tostring(restoreReason))..' '..tostring(saveMessage)
    end
    return true,'Imported native WoW bindings to '..profile..' ('..
        #fresh.changes..' key changes'..(fresh.unknown>0 and ', '..fresh.unknown..' unsupported commands skipped' or '')..').'
end
