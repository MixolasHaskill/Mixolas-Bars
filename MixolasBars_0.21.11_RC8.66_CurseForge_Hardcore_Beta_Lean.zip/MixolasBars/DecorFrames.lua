-- Mixolas Bars: standalone decorative frames (independent from spell actions).
-- New code. Frame styling/placement may be edited only outside combat.
local api=_G.MixolasBarsAPI
if not api then return end
local objects={}
local defaults={width=270,height=140,x=0,y=70,alpha=1,thickness=3,
    label="New Group",labelSide="TOP",fontSize=13,fontOutline="OUTLINE",labelGap=3,
    labelOffsetX=0,labelOffsetY=0,
    color={0.88,0.83,0.74}}
local sides={"TOP","BOTTOM","LEFT","RIGHT"}
local function db() return api.GetDB() end
local function init()
    local d=db()
    if d then d.decorFrames=d.decorFrames or {} end
end
local function parentCenter(frame)
    local x,y=frame:GetCenter();local cx,cy=UIParent:GetCenter()
    if not x or not cx then return end
    local sf=frame:GetEffectiveScale() or 1
    local ps=UIParent:GetEffectiveScale() or 1
    if ps==0 then ps=1 end
    return x*sf/ps-cx,y*sf/ps-cy
end
local function render(id)
    local c=db().decorFrames[id];local f=objects[id]
    if not c or not f then return end
    if c.deleted then f:Hide();return end
    -- A deleted custom frame was detached from UIParent. A later profile may
    -- restore the same frame ID; reattach it before making it visible again.
    if f.GetParent and f:GetParent()~=UIParent then f:SetParent(UIParent) end
    f:SetSize(c.width,c.height)
    f:ClearAllPoints()
    f:SetPoint("CENTER",UIParent,"CENTER",c.x,c.y)
    f:SetAlpha(c.alpha)
    for k,t in ipairs(f.lines) do
        t:SetColorTexture(c.color[1],c.color[2],c.color[3],1)
        if k<=2 then t:SetHeight(c.thickness) else t:SetWidth(c.thickness) end
    end
    -- Rotate along the OUTSIDE edges rather than putting horizontal labels
    -- beside the frame. Left reads bottom-to-top (+90 deg CCW); right reads
    -- top-to-bottom (-90 deg CW). Normal top/bottom labels stay horizontal.
    -- Classic clients may not expose FontString:SetRotation. In that case,
    -- show upright vertical fallback glyphs rather than throw a Lua error.
    local side=c.labelSide or "TOP"
    local vertical=(side=="LEFT" or side=="RIGHT")
    local gap=math.max(0,math.min(20,tonumber(c.labelGap) or 3))
    -- Fine-position the LABEL without moving its decorative frame or border.
    -- Old profiles have no offset fields and therefore keep their old position.
    local labelX=math.max(-150,math.min(150,tonumber(c.labelOffsetX) or 0))
    local labelY=math.max(-150,math.min(150,tonumber(c.labelOffsetY) or 0))
    local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    local text=c.label or ""
    local size=c.fontSize or 13
    f.title:ClearAllPoints()
    f.title:SetWidth(0);f.title:SetHeight(0)
    f.title:SetFont(font,size,c.fontOutline)
    f.title:SetText(text)
    f.title:SetTextColor(c.color[1],c.color[2],c.color[3],1)
    -- FontString rotation is supported in newer clients; handle Classic
    -- versions without it by using a vertical-letter fallback.
    local canRotate = f.title.SetRotation ~= nil
    local renderedSize=size
    if vertical and canRotate then
        -- Fit long labels to the frame's height without changing their saved
        -- font size. Rotate AFTER choosing font size so the final glyphs rotate.
        local width=f.title.GetStringWidth and f.title:GetStringWidth() or 0
        if width>c.height-12 and width>0 then
            renderedSize=math.max(8,math.floor(size*(c.height-12)/width))
            if renderedSize<size then f.title:SetFont(font,renderedSize,c.fontOutline) end
        end
    end
    if canRotate then
        local angle=side=="LEFT" and (math.pi/2) or side=="RIGHT" and (-math.pi/2) or 0
        canRotate=pcall(f.title.SetRotation,f.title,angle)
    end
    if vertical and not canRotate then
        -- Classic fallback: upright vertically stacked letters. Split UTF-8
        -- codepoints rather than bytes, so accented label text isn't broken.
        local letters={}
        local i=1
        while i<=#text do
            local byte=text:byte(i)
            local width=byte>=240 and 4 or byte>=224 and 3 or byte>=192 and 2 or 1
            letters[#letters+1]=text:sub(i,i+width-1)
            i=i+width
        end
        if side=="LEFT" then
            local backwards={}
            for j=#letters,1,-1 do backwards[#backwards+1]=letters[j] end
            letters=backwards
        end
        f.title:SetText(table.concat(letters,"\n"))
        renderedSize=math.max(8,math.min(size,(c.height-10)/math.max(1,#letters)))
        f.title:SetFont(font,renderedSize,c.fontOutline)
    end
    -- TOP/BOTTOM used to hard-code 5 px, so the Label Distance slider had
    -- no effect there.  Preserve the original default position (gap=3 => 5)
    -- while allowing the gap slider to move all four sides.
    if side=="BOTTOM" then
        f.title:SetPoint("TOP",f,"BOTTOM",labelX,labelY-(gap+2))
    elseif side=="LEFT" then
        f.title:SetPoint("CENTER",f,"LEFT",labelX-(renderedSize/2+gap),labelY)
    elseif side=="RIGHT" then
        f.title:SetPoint("CENTER",f,"RIGHT",labelX+(renderedSize/2+gap),labelY)
    else
        f.title:SetPoint("BOTTOM",f,"TOP",labelX,labelY+(gap+2))
    end
    f.title:SetShown(text~="")
    f:SetShown(c.visible~=false)
    f:SetFrameStrata(db().locked and "LOW" or "HIGH")
    f.editMask:SetShown(not db().locked)
    f.resize:SetShown(not db().locked)
end
local function create(id)
    local f=CreateFrame("Frame","MixolasBarsDecorFrame"..id,UIParent)
    f:SetMovable(true)
    f:SetResizable(true)
    if f.SetResizeBounds then f:SetResizeBounds(40,40,1100,800) end
    -- Custom scaled clamp is handled in DragController; don't double-clamp.
    f:SetClampedToScreen(false)
    f.lines={}
    for k=1,4 do
        local t=f:CreateTexture(nil,"OVERLAY")
        if k==1 then t:SetPoint("TOPLEFT",f,"TOPLEFT",0,0);t:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0)
        elseif k==2 then t:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,0);t:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0)
        elseif k==3 then t:SetPoint("TOPLEFT",f,"TOPLEFT",0,0);t:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",0,0)
        else t:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0);t:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",0,0) end
        f.lines[k]=t
    end
    f.title=f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    local mask=CreateFrame("Button",nil,f)
    mask:SetAllPoints(f)
    mask:EnableMouse(true)
    mask:RegisterForDrag("LeftButton")
    mask:SetFrameLevel(f:GetFrameLevel()+5)
    local wash=mask:CreateTexture(nil,"BACKGROUND")
    wash:SetAllPoints(); wash:SetColorTexture(0.22,0.53,0.95,0.12)
    mask:SetScript("OnDragStart",function()
        if api.BeginLayoutDrag then api.BeginLayoutDrag(f,db().decorFrames[id]) end
    end)
    mask:SetScript("OnDragStop",function()
        if api.EndLayoutDrag then api.EndLayoutDrag(f) end
    end)
    f.editMask=mask
    local resize=CreateFrame("Button",nil,f)
    resize:SetSize(17,17)
    resize:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",4,-4)
    resize:SetFrameLevel(mask:GetFrameLevel()+1)
    resize:EnableMouse(true)
    resize:RegisterForDrag("LeftButton")
    local grip=resize:CreateTexture(nil,"OVERLAY")
    grip:SetAllPoints();grip:SetColorTexture(0.8,0.85,1,0.95)
    resize:SetScript("OnDragStart",function()
        if not api.IsInCombat() and not db().locked then f:StartSizing("BOTTOMRIGHT") end
    end)
    resize:SetScript("OnDragStop",function()
        f:StopMovingOrSizing()
        if not api.IsInCombat() then
            local c=db().decorFrames[id]
            c.width=math.max(40,math.min(1100,f:GetWidth()))
            c.height=math.max(40,math.min(800,f:GetHeight()))
            local x,y=parentCenter(f)
            if x then c.x=x;c.y=y end
            render(id)
            if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
        end
    end)
    f.resize=resize
    objects[id]=f
    render(id)
end
api.GetDecor=function() return db() and db().decorFrames or {} end
api.AddDecor=function()
    if not api.IsReady() or api.IsInCombat() then return false end
    init()
    local c={}
    for k,v in pairs(defaults) do
        if type(v)=="table" then c[k]={v[1],v[2],v[3]} else c[k]=v end
    end
    c.label="GROUP "..(#db().decorFrames+1)
    c.x=(#db().decorFrames%4)*30
    table.insert(db().decorFrames,c)
    create(#db().decorFrames)
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return #db().decorFrames
end
api.SetDecor=function(id,key,value)
    if api.IsInCombat() or not db() or not db().decorFrames[id] or db().decorFrames[id].deleted then return false end
    local c=db().decorFrames[id]
    if key=="label" then c.label=tostring(value):sub(1,48)
    elseif key=="width" or key=="height" then c[key]=math.max(40,math.min(1100,math.floor(value)))
    elseif key=="fontSize" then c[key]=math.max(8,math.min(30,math.floor(value)))
    elseif key=="labelGap" then c.labelGap=math.max(0,math.min(20,math.floor(tonumber(value) or 0)))
    elseif key=="labelOffsetX" or key=="labelOffsetY" then
        c[key]=math.max(-150,math.min(150,math.floor(tonumber(value) or 0)))
    elseif key=="alpha" then c[key]=math.max(0.1,math.min(1,value))
    elseif key=="thickness" then c[key]=math.max(1,math.min(12,math.floor(value)))
    elseif key=="labelSide" then c.labelSide=sides[((({TOP=1,BOTTOM=2,LEFT=3,RIGHT=4})[c.labelSide] or 1)%4)+1]
    elseif key=="fontOutline" then c.fontOutline=c.fontOutline=="OUTLINE" and "THICKOUTLINE" or "OUTLINE"
    elseif key=="visible" then c.visible=not not value
    else return false end
    render(id)
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return true
end
api.SetDecorColor=function(id,r,g,b)
    if api.IsInCombat() or not db() or not db().decorFrames[id] or db().decorFrames[id].deleted then return false end
    db().decorFrames[id].color={r,g,b};render(id)
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return true
end
api.RemoveDecor=function(id)
    if api.IsInCombat() or not db() or not db().decorFrames[id] or db().decorFrames[id].deleted then return false end
    if objects[id] then objects[id]:Hide();objects[id]:SetParent(nil) end
    -- Keep IDs stable for currently instantiated frames; mark removed, not reindex.
    db().decorFrames[id].visible=false
    db().decorFrames[id].deleted=true
    if api.MarkVisualLayoutDirty then api.MarkVisualLayoutDirty() end
    return true
end
api.RefreshDecorHandles=function()
    for id,f in ipairs(objects) do
        if f and db().decorFrames[id] then render(id)
        elseif f then f:Hide() end
    end
end
api.ReloadDecorFromConfig=function()
    if api.IsInCombat() or not db() then return false end
    for id,f in ipairs(objects) do
        local c=db().decorFrames and db().decorFrames[id]
        if f and c and not c.deleted then render(id)
        elseif f then f:Hide() end
    end
    for id,c in ipairs(db().decorFrames or {}) do
        if c and not c.deleted and not objects[id] then create(id) end
    end
    return true
end
local startup=CreateFrame("Frame")
startup:RegisterEvent("PLAYER_LOGIN")
startup:SetScript("OnEvent",function()
    init()
    for id,c in ipairs(db().decorFrames) do
        if not c.deleted then create(id) end
    end
end)
