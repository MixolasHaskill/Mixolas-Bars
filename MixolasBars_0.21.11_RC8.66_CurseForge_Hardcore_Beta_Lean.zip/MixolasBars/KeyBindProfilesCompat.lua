-- Mixolas Bars / Azaiko KeyBindProfiles 1.4.x (Forever) integration.
-- KeyBindProfiles scans native WoW bindings with GetNumBindings/GetBinding.
-- Mixolas action-button shortcuts use priority override clicks, which are NOT
-- part of that snapshot. Store them as an additional field in the currently
-- active KeyBindProfiles AceDB profile, without editing KBP's own source.
-- Never copy native bindings, spells, button action IDs or visual profiles.
local api = _G.MixolasBarsAPI
if not api then return end

local linked, pendingRestore, queuedAtLogin = nil, nil, false
local FIELD = "mixolasBarsBindings"

local function cloneKeys(source)
    local buttons = {}
    if type(source) ~= "table" then return buttons end
    local used = {}
    for slot = 1, 128 do
        local keys = source[tostring(slot)]
        if type(keys) == "table" then
            local values = {}
            for _, key in ipairs(keys) do
                if type(key) == "string" and key ~= "" and not used[key]
                    and #values < 3 then
                    values[#values + 1] = key
                    used[key] = true
                end
            end
            if #values > 0 then buttons[tostring(slot)] = values end
        end
    end
    return buttons
end

local function activeProfile(kbp)
    return kbp and kbp.db and type(kbp.db.profile) == "table"
        and kbp.db.profile or nil
end

local function saveIntoProfile(kbp)
    local profile = activeProfile(kbp)
    local db = api.GetDB and api.GetDB()
    if not profile or not db or type(db.bindings) ~= "table"
        or not (api.IsReady and api.IsReady()) then return false end
    profile[FIELD] = { version = 1, buttons = cloneKeys(db.bindings) }
    return true
end

local function applyPending()
    if not pendingRestore then return false end
    if not (api.IsReady and api.IsReady()) or (api.IsInCombat and api.IsInCombat()) then
        return false
    end
    local restore = pendingRestore
    if not (api.SetCharacterBindings and api.SetCharacterBindings(cloneKeys(restore))) then
        return false
    end
    pendingRestore = nil
    if api.ApplyBindings then api.ApplyBindings() end
    if api.RefreshHotkeys then api.RefreshHotkeys() end
    return true
end

local function restoreFromProfile(kbp)
    local profile = activeProfile(kbp)
    local stored = profile and profile[FIELD]
    -- Compatibility with older KeyBindProfiles profiles: no Mixolas data means
    -- leave this character's current Mixolas bindings unchanged.
    if type(stored) ~= "table" or stored.version ~= 1
        or type(stored.buttons) ~= "table" then
        pendingRestore = nil
        return false
    end
    pendingRestore = cloneKeys(stored.buttons)
    return applyPending()
end

local function lookupKBP()
    -- The Azaiko addon registers through AceAddon-3.0 (not a guaranteed
    -- global variable). Other similarly named addons may have different APIs.
    if type(LibStub) ~= "function" then return nil end
    local ok,ace = pcall(LibStub, "AceAddon-3.0", true)
    if not ok or not ace or type(ace.GetAddon) ~= "function" then return nil end
    local found, addon = pcall(ace.GetAddon, ace, "KeyBindProfiles", true)
    if found and type(addon) == "table" then return addon end
    return nil
end

local function attach()
    if linked then return true end
    local kbp = lookupKBP()
    if not kbp or type(kbp.SaveBindings) ~= "function"
        or type(kbp.RestoreDbBindings) ~= "function"
        or type(hooksecurefunc) ~= "function" then return false end

    local ok1 = pcall(hooksecurefunc, kbp, "SaveBindings", function(self)
        saveIntoProfile(self)
    end)
    local ok2 = pcall(hooksecurefunc, kbp, "RestoreDbBindings", function(self)
        restoreFromProfile(self)
    end)
    if not (ok1 and ok2) then return false end
    linked = kbp
    -- Catch an initial KBP profile load that completed before hooks attached.
    if api.IsReady and api.IsReady() then restoreFromProfile(kbp) end
    return true
end

api.KeyBindProfilesStatus = function()
    if linked then
        return "KeyBindProfiles linked. Mixolas keys are stored with its active profile."
    end
    if attach() then
        return "KeyBindProfiles linked. Mixolas keys are stored with its active profile."
    end
    return "No compatible Azaiko KeyBindProfiles 1.4.x addon detected. Mixolas bindings still work independently."
end
api.KeyBindProfilesSaveCurrent = function()
    if not linked and not attach() then return false end
    -- Called after Mixolas Save & Exit, even if KBP's auto-save is disabled.
    -- Do NOT force the provider to save native bindings or change profiles.
    return saveIntoProfile(linked)
end
api.KeyBindProfilesRestoreCurrent = function()
    if not linked and not attach() then return false end
    return restoreFromProfile(linked)
end

local watcher = CreateFrame("Frame")
watcher:RegisterEvent("PLAYER_LOGIN")
watcher:RegisterEvent("PLAYER_ENTERING_WORLD")
watcher:RegisterEvent("PLAYER_REGEN_ENABLED")
watcher:RegisterEvent("ADDON_LOADED")
watcher:SetScript("OnEvent", function(_, event, name)
    if event == "ADDON_LOADED" and name ~= "KeyBindProfiles" then return end
    if event == "PLAYER_LOGIN" then queuedAtLogin = true end
    if not linked then attach() end
    if event == "PLAYER_REGEN_ENABLED" then applyPending() end
    if queuedAtLogin and linked and api.IsReady and api.IsReady() then
        queuedAtLogin = false
        restoreFromProfile(linked)
    end
end)

SLASH_MIXOLASBARSKEYBINDPROFILES1 = "/mxbkbp"
SlashCmdList = SlashCmdList or {}
SlashCmdList.MIXOLASBARSKEYBINDPROFILES = function()
    local msg = api.KeyBindProfilesStatus()
    if api.Say then api.Say(msg) end
end
