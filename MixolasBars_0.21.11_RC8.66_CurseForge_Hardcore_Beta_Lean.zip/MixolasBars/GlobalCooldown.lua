-- Mixolas Bars v0.19.10: Forever native duration-object GCD display with Classic fallback.
-- Follow Blizzard/Bartender's native action/spell cooldown APIs. Spell 61304
-- measures the global cooldown; GetSpellBaseCooldown's SECOND return value
-- identifies spells that participate even with a longer personal cooldown.
-- Display only: never inspect combat-log procs or execute protected actions.
local api=_G.MixolasBarsAPI
if not api then return end
local compat=_G.MixolasBarsCompat or {}
local widgets={}

local function publicNumber(value)
    if issecretvalue then
        local ok,secret=pcall(issecretvalue,value)
        if not ok or secret then return nil end
    end
    return type(value)=='number' and value or nil
end
local function activeCooldown(start,duration,enabled,now)
    start=publicNumber(start);duration=publicNumber(duration)
    return start and duration and start>0 and duration>0
       and enabled~=0 and enabled~=false and start+duration>now
end
local function nativeGCD(now)
    if compat.SpellCooldown then
        local ok,a,b,c=pcall(compat.SpellCooldown,61304)
        if ok and activeCooldown(a,b,c,now) and b<=2.5 then return a,b end
    end
    -- Compatibility fallback for Classic builds without the shared helper.
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok,info=pcall(C_Spell.GetSpellCooldown,61304)
        if ok and type(info)=='table' then
            local a,b,e=info.startTime,info.duration,info.isEnabled
            if activeCooldown(a,b,e,now) and b<=2.5 then return a,b end
        end
    end
    if GetSpellCooldown then
        local ok,a,b,c=pcall(GetSpellCooldown,61304)
        if ok and activeCooldown(a,b,c,now) and b<=2.5 then return a,b end
    end
end

local function matches(start,duration,enabled,gcdStart,gcdDuration)
    if not gcdStart or not gcdDuration then return false end
    start=publicNumber(start);duration=publicNumber(duration)
    return start and duration and enabled~=false and enabled~=0
        and math.abs(start-gcdStart)<0.28
        and math.abs(duration-gcdDuration)<0.32
end
local function spellOnGCD(spellID,gcdStart,gcdDuration)
    if not spellID then return false end
    -- This is the *gcdMS*, not the regular cooldownMS. Crucial for
    -- e.g. a 30-second spell with a 1.5-second global cooldown.
    if GetSpellBaseCooldown then
        local ok,_,gcdMS=pcall(GetSpellBaseCooldown,spellID)
        if ok then
            gcdMS=publicNumber(gcdMS)
            if gcdMS then return gcdMS>0 end
        end
    end
    -- When cooldown start/duration are secret, matching must not attempt to
    -- compare them. Base spell metadata can still identify eligible spells.
    if not gcdStart or not gcdDuration then return false end
    -- Some Forever beta builds may not expose GetSpellBaseCooldown for every
    -- spell. Exact cooldown matching is still reliable for ordinary spells.
    if compat.SpellCooldown then
        local ok,a,b,c=pcall(compat.SpellCooldown,spellID)
        if ok and matches(a,b,c,gcdStart,gcdDuration) then return true end
    end
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok,info=pcall(C_Spell.GetSpellCooldown,spellID)
        if ok and type(info)=='table' and matches(info.startTime,info.duration,info.isEnabled,gcdStart,gcdDuration) then
            return true
        end
    end
    return false
end
local function actionCooldownMatches(slot,gcdStart,gcdDuration)
    if not gcdStart or not gcdDuration then return false end
    if compat.ActionCooldown then
        local ok,a,b,c=pcall(compat.ActionCooldown,slot)
        if ok and matches(a,b,c,gcdStart,gcdDuration) then return true end
    end
    if C_ActionBar and C_ActionBar.GetActionCooldown then
        local ok,info=pcall(C_ActionBar.GetActionCooldown,slot)
        if ok and type(info)=='table' and matches(info.startTime,info.duration,info.isEnabled,gcdStart,gcdDuration) then
            return true
        end
    end
    if GetActionCooldown then
        local ok,a,b,c=pcall(GetActionCooldown,slot)
        if ok and matches(a,b,c,gcdStart,gcdDuration) then return true end
    end
    return false
end
local function spellOfMacro(macroIndex)
    if not GetMacroSpell then return nil end
    local ok,a,b=pcall(GetMacroSpell,macroIndex)
    if not ok then return nil end
    -- Classic and mainline may return ID or name/ID depending on version.
    if type(a)=='number' then return a end
    if type(b)=='number' then return b end
    if type(a)=='string' then return a end
    return nil
end
local function affectedByGCD(button,gcdStart,gcdDuration)
    if button.isCustom then
        local db=api.GetDB()
        local info=db and db.customActions and db.customActions[tostring(button.slot)]
        if not info then return false end
        if info.kind=='spell' then
            return spellOnGCD(info.value,gcdStart,gcdDuration)
        elseif info.kind=='macro' then
            local id=spellOfMacro(info.value)
            return id and spellOnGCD(id,gcdStart,gcdDuration) or false
        end
        return false -- custom consumable items aren't assumed to share spell GCD.
    end
    local slot=button:GetAttribute('action') or button.actionSlot
    if not slot then return false end
    if compat.ActionHas then
        local ok,present=pcall(compat.ActionHas,slot)
        if ok and present==false then return false end
    elseif HasAction and not HasAction(slot) then
        return false
    end
    -- The native action's reported cooldown is preferred when it matches.
    if actionCooldownMatches(slot,gcdStart,gcdDuration) then return true end
    if not GetActionInfo then return false end
    local ok,kind,id=pcall(GetActionInfo,slot)
    if not ok then return false end
    if kind=='spell' then return spellOnGCD(id,gcdStart,gcdDuration) end
    if kind=='macro' then
        local spell=spellOfMacro(id)
        return spell and spellOnGCD(spell,gcdStart,gcdDuration) or false
    end
    return false
end
-- In combat, Forever can restrict cooldown timestamps as secret values.
-- A DurationObject can be handed directly to a Cooldown widget without
-- inspecting its secret numeric fields, on clients permitting that operation.
local function secretSafeGCDDuration()
    if not (C_Spell and C_Spell.GetSpellCooldownDuration) then return nil end
    local ok,obj=pcall(C_Spell.GetSpellCooldownDuration,61304)
    return ok and obj or nil
end

local function ensure(button)
    if button.mxbGCD then return button.mxbGCD end
    if not button.icon then return nil end
    local frame=CreateFrame('Cooldown',nil,button,'CooldownFrameTemplate')
    frame:SetAllPoints(button.icon)
    frame:SetFrameLevel(button:GetFrameLevel()+1)
    if frame.SetHideCountdownNumbers then frame:SetHideCountdownNumbers(true) end
    if frame.SetDrawEdge then frame:SetDrawEdge(false) end
    if frame.SetDrawBling then frame:SetDrawBling(false) end
    if frame.SetDrawSwipe then frame:SetDrawSwipe(true) end
    if frame.SetReverse then frame:SetReverse(false) end
    frame:Hide()
    -- Match the earlier build: GCD lies below readable hotkeys/countdown text.
    local textLayer=CreateFrame('Frame',nil,button)
    textLayer:SetAllPoints(button)
    textLayer:SetFrameLevel(frame:GetFrameLevel()+2)
    for _,font in ipairs({button.hotkeyText,button.cooldownNumber,button.countText}) do
        if font and font.SetParent then font:SetParent(textLayer) end
    end
    button.mxbGCD=frame
    return frame
end
local function collect()
    widgets={}
    for _,cluster in ipairs(api.GetClusters()) do
        for _,button in ipairs(cluster.buttons) do widgets[#widgets+1]=button end
    end
    for _,button in ipairs(api.GetRegularButtons()) do widgets[#widgets+1]=button end
end
local function redraw()
    if not api.IsReady() then return end
    local total=0
    for _,cluster in ipairs(api.GetClusters()) do total=total+#cluster.buttons end
    total=total+#api.GetRegularButtons()
    if #widgets~=total then collect() end
    local db=api.GetDB()
    local now=GetTime()
    local gcdStart,gcdDuration=nativeGCD(now)
    -- Only request a duration object when numeric cooldown data is not
    -- available (e.g. secrets in combat). Let the native widget interpret it.
    local durationObject
    if not gcdStart then durationObject=secretSafeGCDDuration() end
    local enabled=db.gcdSweep~=false and db.visible
    local active=enabled and (gcdStart~=nil or durationObject~=nil)
    for _,button in ipairs(widgets) do
        -- Do not allocate a second Cooldown frame on Forever: every button's
        -- ordinary cooldown widget already includes the real native GCD.
        local gcd
        if button._mxbNativeCooldown then gcd=button.mxbGCD
        else gcd=ensure(button) end
        if gcd then
            -- Forever's native per-action duration already contains its GCD.
            -- A second overlay would obscure that cooldown and often fail when
            -- the global 61304 timestamps are secret; use this only on clients
            -- without duration-object support for the specific action.
            local show=active and not button._mxbNativeCooldown and button:IsShown()
                and button.icon and button.icon:IsShown()
                and affectedByGCD(button,gcdStart,gcdDuration)
            if show then
                if gcd.SetSwipeColor then gcd:SetSwipeColor(0,0,0,db.gcdDarkness or 0.48) end
                if gcdStart then
                    if gcd._start~=gcdStart or gcd._duration~=gcdDuration then
                        gcd:SetCooldown(gcdStart,gcdDuration)
                        gcd._start,gcd._duration=gcdStart,gcdDuration
                    end
                    gcd:Show()
                elseif durationObject and gcd.SetCooldownFromDurationObject then
                    -- The client may reject this protected method from addon
                    -- code. Fail closed: do not draw a fabricated cooldown.
                    local ok=pcall(gcd.SetCooldownFromDurationObject,gcd,durationObject,true)
                    if ok then gcd:Show() else gcd:Hide() end
                    gcd._start,gcd._duration=nil,nil
                else
                    gcd:Hide()
                end
            else
                gcd:Hide()
                gcd._start,gcd._duration=nil,nil
            end
        end
    end
end
api.UpdateGCD=redraw
-- Events update the native swipe immediately. The core's slower inventory/UI
-- refresh loop remains a safety net, not the primary GCD trigger.
local function refreshNativeButtons()
    if not api.IsReady() or not api.RefreshCooldown then return end
    for _,cluster in ipairs(api.GetClusters()) do
        for _,button in ipairs(cluster.buttons) do
            if button:IsShown() then api.RefreshCooldown(button) end
        end
    end
    for _,button in ipairs(api.GetRegularButtons()) do
        if button:IsShown() then api.RefreshCooldown(button) end
    end
end
local events=CreateFrame('Frame')
for _,name in ipairs({'PLAYER_LOGIN','ACTIONBAR_UPDATE_COOLDOWN','SPELL_UPDATE_COOLDOWN',
    'ACTIONBAR_SLOT_CHANGED','ACTIONBAR_PAGE_CHANGED','UNIT_SPELLCAST_SUCCEEDED'}) do
    events:RegisterEvent(name)
end
events:SetScript('OnEvent',function(_,event,unit)
    if event=='UNIT_SPELLCAST_SUCCEEDED' and unit~='player' then return end
    refreshNativeButtons()
    redraw()
    -- The spellcast event can precede the engine's updated cooldown state.
    -- Recheck after a short delay rather than synthesizing a fake 1.5-second GCD.
    if C_Timer and C_Timer.After and (event=='PLAYER_LOGIN' or event=='UNIT_SPELLCAST_SUCCEEDED') then
        C_Timer.After(0.05,function() refreshNativeButtons();redraw() end)
        if event=='UNIT_SPELLCAST_SUCCEEDED' then
            C_Timer.After(0.15,function() refreshNativeButtons();redraw() end)
        end
    end
end)
local elapsed=0
local ticker=CreateFrame('Frame')
ticker:SetScript('OnUpdate',function(_,dt)
    elapsed=elapsed+dt
    if elapsed>=0.10 then elapsed=0;redraw() end
end)

-- /mxbgcd: safe, descriptive diagnostics for Forever cooldown rendering.
-- Do not print or compare secret cooldown start/duration fields.
SLASH_MIXOLASGCD1="/mxbgcd"
SlashCmdList=SlashCmdList or {}
SlashCmdList["MIXOLASGCD"]=function()
    if not api.IsReady() then print("Mixolas Bars: cooldown system not initialized") return end
    collect()
    local native,fallback=0,0
    for _,button in ipairs(widgets) do
        if button._mxbNativeCooldown then native=native+1 else fallback=fallback+1 end
    end
    local status="unknown (restricted or unsupported)"
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok,info=pcall(C_Spell.GetSpellCooldown,61304)
        if ok and type(info)=="table" and type(info.isActive)=="boolean"
                and (not issecretvalue or not issecretvalue(info.isActive)) then
            status=info.isActive and "active" or "idle"
        end
    end
    local db=api.GetDB()
    print("Mixolas GCD: "..(db.gcdSweep==false and "swipe OFF" or "swipe ON")
        ..", native duration "..native.." buttons, legacy "..fallback
        .." buttons; client GCD: "..status)
end
