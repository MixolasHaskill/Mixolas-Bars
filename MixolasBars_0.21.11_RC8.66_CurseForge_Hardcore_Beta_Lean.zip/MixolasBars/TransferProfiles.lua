-- Portable text import/export. Non-evaluating, validated, explicit confirmation.
-- Native keybinding snapshots are included in v21 profiles. Import staging
-- never calls SetBinding; only a deliberate profile load may apply native keys.
-- WoW spell action slots and macro contents are never exported.
local api=_G.MixolasBarsAPI
if not api then return end
local MAX_TEXT=800000
local MAX_NODES=35000
local MAX_DEPTH=18
local MAX_STR=18000
local MAX_PROFILES=16
local ALLOWED={
    locked=true,snapEnabled=true,visible=true,buttonSize=true,gap=true,
    diamondGapEW=true,diamondGapNS=true,glow=true,borderAlpha=true,
    borderWidth=true,illuminationStyle=true,diamondGlows=true,diamondIlluminationStyles=true,glowSpread=true,glowSaturation=true,
    hotkeyFontSize=true,itemCountFontSize=true,showHotkeys=true,showMacroNames=true,rangeDim=true,
    combatDim=true,buttonLock=true,gcdSweep=true,gcdDarkness=true,
    counts=true,diamondEnabled=true,diamondShowEmpty=true,alphas=true,combatAlphas=true,brightness=true,scales=true,
    borderStyles=true,glowMotions=true,colors=true,positions=true,
    regularBars=true,utilityBars=true,decorFrames=true,frameStudio=true,
    minimapAngle=true,minimapSize=true,
}
local function say(s)
    if api.Say then api.Say(s)
    elseif DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage('Mixolas Bars: '..tostring(s)) end
end
local function clone(value,depth)
    local t=type(value)
    if t=='boolean' or t=='string' or t=='number' then return value end
    if t~='table' or (depth or 0)>MAX_DEPTH then return nil end
    local out={}
    for k,v in pairs(value) do
        if type(k)=='string' or type(k)=='number' then
            out[k]=clone(v,(depth or 0)+1)
        end
    end
    return out
end
local function copyLayout(layout)
    if type(layout)~='table' then return nil end
    local out={}
    for k in pairs(ALLOWED) do if layout[k]~=nil then out[k]=clone(layout[k]) end end
    return out
end
local b64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local function base64(data)
    local out={}
    for i=1,#data,3 do
        local a,b,c=data:byte(i,i+2)
        local v=a*65536+(b or 0)*256+(c or 0)
        local c1=math.floor(v/262144)%64+1
        local c2=math.floor(v/4096)%64+1
        local c3=math.floor(v/64)%64+1
        local c4=v%64+1
        out[#out+1]=b64:sub(c1,c1)..b64:sub(c2,c2)..(b and b64:sub(c3,c3) or '=')..(c and b64:sub(c4,c4) or '=')
    end
    return table.concat(out)
end
local lookup={}
for i=1,#b64 do lookup[b64:sub(i,i)]=i-1 end
local function unbase64(data)
    if #data%4~=0 or data:find('[^%w%+/%=]') then return nil,'Invalid base64 characters.' end
    local out={}
    for i=1,#data,4 do
        local a,b,c,d=data:sub(i,i),data:sub(i+1,i+1),data:sub(i+2,i+2),data:sub(i+3,i+3)
        local x,y=lookup[a],lookup[b]
        if not x or not y then return nil,'Bad base64 payload.' end
        if (c=='=' and d~='=') or ((c=='=' or d=='=') and i~=#data-3) then return nil,'Bad padding.' end
        local z=(c=='=') and 0 or lookup[c]
        local w=(d=='=') and 0 or lookup[d]
        if z==nil or w==nil then return nil,'Unknown base64 digit.' end
        local n=x*262144+y*4096+z*64+w
        out[#out+1]=string.char(math.floor(n/65536)%256)
        if c~='=' then out[#out+1]=string.char(math.floor(n/256)%256) end
        if d~='=' then out[#out+1]=string.char(n%256) end
    end
    return table.concat(out)
end
local function serialize(root)
    local count=0
    local function encode(value,depth)
        count=count+1
        if count>MAX_NODES or depth>MAX_DEPTH then error('Dataset is too large or nested.') end
        local kind=type(value)
        if kind=='nil' then return 'Z' end
        if kind=='boolean' then return value and 'Y' or 'N' end
        if kind=='number' then
            if value~=value or value==math.huge or value==-math.huge then error('Invalid number.') end
            return 'D'..tostring(value)..';'
        end
        if kind=='string' then
            if #value>MAX_STR then error('String is too long.') end
            return 'S'..#value..':'..value
        end
        if kind=='table' then
            local keys={}
            for key in pairs(value) do
                if type(key)~='number' and type(key)~='string' then error('Unsupported table key.') end
                keys[#keys+1]=key
            end
            if #keys>MAX_NODES then error('Table is too large.') end
            table.sort(keys,function(a,b)
                if type(a)~=type(b) then return type(a)<type(b) end
                return a<b
            end)
            local pieces={'T',tostring(#keys),':'}
            for _,k in ipairs(keys) do
                pieces[#pieces+1]=encode(k,depth+1)
                pieces[#pieces+1]=encode(value[k],depth+1)
            end
            return table.concat(pieces)
        end
        error('Unsupported value type '..kind)
    end
    return encode(root,0)
end
local function deserialize(raw)
    if #raw>MAX_TEXT then return nil,'Payload is too long.' end
    local pos,count=1,0
    local function numberUntil(delimiter,limit)
        local start=pos
        while pos<=#raw and raw:sub(pos,pos)~=delimiter do
            if pos-start>20 then error('Overlong numeric header.') end
            pos=pos+1
        end
        if pos>#raw then error('Truncated header.') end
        local n=tonumber(raw:sub(start,pos-1))
        if not n or n<0 or n>limit then error('Invalid size or number.') end
        pos=pos+1
        return n
    end
    local function read(depth)
        count=count+1
        if depth>MAX_DEPTH or count>MAX_NODES then error('Dataset exceeded safety limits.') end
        local tag=raw:sub(pos,pos);pos=pos+1
        if tag=='Z' then return nil
        elseif tag=='Y' then return true
        elseif tag=='N' then return false
        elseif tag=='D' then
            local start=pos
            while pos<=#raw and raw:sub(pos,pos)~=';' do
                if pos-start>45 then error('Numeric token too long.') end
                pos=pos+1
            end
            if pos>#raw then error('Unterminated number.') end
            local value=tonumber(raw:sub(start,pos-1));pos=pos+1
            if not value or value~=value or value==math.huge or value==-math.huge then error('Invalid numeric value.') end
            return value
        elseif tag=='S' then
            local len=numberUntil(':',MAX_STR)
            if pos+len-1>#raw then error('Unterminated string.') end
            local v=raw:sub(pos,pos+len-1);pos=pos+len
            return v
        elseif tag=='T' then
            local n=numberUntil(':',MAX_NODES)
            local result={}
            for i=1,n do
                local k=read(depth+1)
                if type(k)~='number' and type(k)~='string' then error('Invalid table key type.') end
                if result[k]~=nil then error('Duplicate table key.') end
                result[k]=read(depth+1)
            end
            return result
        end
        error('Unexpected token.')
    end
    local ok,value=pcall(read,0)
    if not ok then return nil,tostring(value) end
    if pos~=#raw+1 then return nil,'Unexpected trailing data.' end
    if type(value)~='table' then return nil,'Root is not a table.' end
    return value
end
local function safeBindings(source)
    if type(source)~='table' then return nil,'No binding table.' end
    local out={};local count=0
    for rawId,keys in pairs(source) do
        local id=tonumber(rawId)
        if not id or id%1~=0 or id<1 or id>128 or type(keys)~='table' then
            return nil,'Invalid binding slot ID.'
        end
        local chosen={}
        for _,key in ipairs(keys) do
            if type(key)~='string' or #key>55 or key:find('[^%w%-]') then
                return nil,'Invalid custom key name.'
            end
            if #chosen>=3 then return nil,'More than three bindings for one slot.' end
            chosen[#chosen+1]=key
            count=count+1
            if count>384 then return nil,'Too many keys.' end
        end
        if #chosen>0 then out[tostring(id)]=chosen end
    end
    return out
end
local function safeNative(source)
    if source==nil then return nil end  -- legacy profiles leave WoW keys alone
    if type(source)~='table' or source.version~=1 or type(source.keys)~='table' then
        return false,'Invalid native keybinding snapshot.'
    end
    local copy={version=1,keys={},sourceSet=tonumber(source.sourceSet)==2 and 2 or 1}
    local n=0
    for key,command in pairs(source.keys) do
        if type(key)~='string' or #key<1 or #key>64 or key:find('%c')
            or type(command)~='string' or #command<1 or #command>256 or command:find('%c') then
            return false,'Invalid native shortcut key or command.'
        end
        n=n+1
        if n>4096 then return false,'Too many native keybindings.' end
        copy.keys[key]=command
    end
    return copy
end
local function validLayout(layout)
    if type(layout)~='table' then return false,'Missing layout.' end
    for key,v in pairs(layout) do
        if not ALLOWED[key] then return false,'Unexpected layout key '..tostring(key) end
        if type(v)~='number' and type(v)~='string' and type(v)~='boolean' and type(v)~='table' then
            return false,'Unsupported value for '..tostring(key)
        end
    end
    -- Validate the fields which can directly influence rendering/geometry.
    if layout.buttonSize and (type(layout.buttonSize)~='number' or layout.buttonSize<12 or layout.buttonSize>90) then return false,'Invalid button size.' end
    for _,field in ipairs({'gap','diamondGapEW','diamondGapNS'}) do
        local v=layout[field]
        if v~=nil and (type(v)~='number' or v<0 or v>24) then return false,'Invalid '..field end
    end
    for _,field in ipairs({'counts','positions','scales','colors','diamondEnabled','regularBars','utilityBars','decorFrames','frameStudio'}) do
        if layout[field]~=nil and type(layout[field])~='table' then return false,'Invalid '..field end
    end
    local pos=layout.positions
    if pos then
        for i=1,8 do
            local pt=pos[i]
            if pt~=nil then
                if type(pt)~='table' or type(pt[1])~='number' or type(pt[2])~='number'
                    or math.abs(pt[1])>10000 or math.abs(pt[2])>10000 then
                    return false,'Invalid diamond position '..i
                end
            end
        end
    end
    if layout.scales then
        for i=1,8 do
            local n=layout.scales[i]
            if n~=nil and (type(n)~='number' or n<0.35 or n>1.5) then
                return false,'Invalid diamond scale '..i
            end
        end
    end
    if layout.counts then
        for i=1,8 do
            local n=layout.counts[i]
            if n~=nil and (type(n)~='number' or n<0 or n>4 or n%1~=0) then
                return false,'Invalid diamond count '..i
            end
        end
    end
    return true
end
local staged
local function export()
    if not api.IsReady or not api.IsReady() then return nil,'Not initialized.' end
    local db=api.GetDB() or {}
    local char=api.GetCharacterDB() or {}
    if api.CaptureCurrentVisualLayout then api.CaptureCurrentVisualLayout() end
    local settings=clone(char.activeVisualLayout or {})
    if not next(settings) then return nil,'Could not capture the current layout.' end
    local native,why=api.CaptureNativeBindings and api.CaptureNativeBindings()
    if not native then return nil,'Cannot export native shortcuts: '..tostring(why) end
    local package={version=21,layout=copyLayout(settings),bindings=clone(char.bindings or db.bindings or {}),nativeBindings=native,
        appearance={obsidianPrototype=clone(db.obsidianPrototype or {}),activationFlash=clone(db.activationFlash or {})},
        profiles={}}
    -- Named profile library is included without mutating or overwriting originals.
    for name,profile in pairs(db.mixolasProfiles or {}) do
        if type(name)=='string' and type(profile)=='table' and type(profile.layout)=='table' then
            package.profiles[name]={layout=copyLayout(profile.layout),bindings=clone(profile.bindings or {}),
                nativeBindings=clone(profile.nativeBindings)}
        end
    end
    local ok,raw=pcall(serialize,package)
    if not ok then return nil,tostring(raw) end
    if #raw>MAX_TEXT then return nil,'Export too large; reduce saved profiles first.' end
    return 'MXB21:'..base64(raw)
end
local function import(text)
    staged=nil
    if type(text)~='string' then return false,'No text to import.' end
    text=text:gsub('%s','')
    local prefix=text:sub(1,6)
    if prefix~='MXB20:' and prefix~='MXB21:' then return false,'Expected MXB20: or MXB21:.' end
    if #text>MAX_TEXT*1.45 then return false,'Text too long.' end
    local raw,why=unbase64(text:sub(7))
    if not raw then return false,why end
    local package,err=deserialize(raw)
    if not package then return false,err end
    if package.version~=20 and package.version~=21 then return false,'Unsupported version.' end
    local valid,reason=validLayout(package.layout)
    if not valid then return false,reason end
    local keys,err=safeBindings(package.bindings or {})
    if not keys then return false,err end
    local native,nativeError=safeNative(package.nativeBindings)
    if native==false then return false,nativeError end
    local profiles={};local num=0
    for name,p in pairs(package.profiles or {}) do
        num=num+1
        if num>MAX_PROFILES then return false,'Too many named profiles.' end
        if type(name)~='string' or #name>32 or type(p)~='table' then return false,'Invalid profile.' end
        local ok,reason=validLayout(p.layout)
        if not ok then return false,'Profile '..name..': '..reason end
        local accepted,why=safeBindings(p.bindings or {})
        if not accepted then return false,'Profile '..name..': '..why end
        local savedNative,nativeError=safeNative(p.nativeBindings)
        if savedNative==false then return false,'Profile '..name..': '..nativeError end
        profiles[name]={layout=copyLayout(p.layout),bindings=accepted,nativeBindings=savedNative}
    end
    local appearance=package.appearance or {}
    if type(appearance)~='table' then return false,'Invalid appearance fields.' end
    if type(appearance.obsidianPrototype or {})~='table' or type(appearance.activationFlash or {})~='table' then
        return false,'Invalid appearance fields.'
    end
    staged={layout=copyLayout(package.layout),bindings=keys,nativeBindings=native,
        appearance=appearance,profiles=profiles}
    local binds=0;for _,v in pairs(keys) do binds=binds+#v end
    return true,'Staged '..binds..' Mixolas keys, '..(native and api.CountNativeBindings(native) or 0)..' native WoW keys, and '..num..' named profiles. NOTHING APPLIED. Choose import contents, then REVIEW & CONFIRM.'
end
local function pickUnique(db,prefix)
    db.mixolasProfiles=db.mixolasProfiles or {}
    for i=1,99 do
        local name=prefix..(i==1 and '' or (' '..i))
        if not db.mixolasProfiles[name] then return name end
    end
    return nil
end
local function confirm(mode)
    if not staged then return false,'Stage an import first.' end
    if api.IsInCombat and api.IsInCombat() then return false,'Cannot import in combat.' end
    if not api.IsReady or not api.IsReady() then return false,'Addon not ready.' end
    if mode~='layout' and mode~='keys' and mode~='appearance' and mode~='all' and mode~='profiles' then
        return false,'Choose layout, keys, appearance, profiles or all.'
    end
    local db=api.GetDB();local char=api.GetCharacterDB()
    if not db or not char then return false,'SavedVariables unavailable.' end
    local existingCount=0
    for _ in pairs(db.mixolasProfiles or {}) do existingCount=existingCount+1 end
    local incomingCount=0
    if mode=='all' or mode=='profiles' then
        for _ in pairs(staged.profiles) do incomingCount=incomingCount+1 end
    end
    local extra=(mode=='all' or mode=='layout') and 1 or 0
    if existingCount + incomingCount + extra > MAX_PROFILES then
        return false,'Profile library would exceed 16; delete unwanted profiles manually before importing.'
    end
    local function commitLayout(withKeys)
        if not api.LoadNamedProfile then return false,'Profiles system unavailable.' end
        local backup=api.TakeLayoutSnapshot and api.TakeLayoutSnapshot('Before external Mixolas import')
        if backup==false then return false,'Cannot save restore point.' end
        local name=pickUnique(db,'Imported 0.21')
        if not name then return false,'No unused profile names.' end
        local native=withKeys and clone(staged.nativeBindings) or nil
        db.mixolasProfiles[name]={layout=clone(staged.layout),bindings=withKeys and clone(staged.bindings) or {},
            nativeBindings=native,version=native and 4 or (withKeys and 3 or 1)}
        local ok,why=api.LoadNamedProfile(name,true)
        if not ok then db.mixolasProfiles[name]=nil;return false,tostring(why) end
        return true,name
    end
    if mode=='keys' then
        if not api.SetCharacterBindings then return false,'Custom binding API unavailable.' end
        local previous=clone(char.bindings or {})
        if api.TakeLayoutSnapshot and api.TakeLayoutSnapshot('Before external Mixolas key import')==false then return false,'Cannot create restore point.' end
        local ok,accepted=pcall(api.SetCharacterBindings,clone(staged.bindings))
        if not ok or accepted~=true then return false,'Could not store custom Mixolas bindings.' end
        if api.ApplyBindings then
            local routed,accepted=pcall(api.ApplyBindings)
            if not routed or accepted==false then
                pcall(api.SetCharacterBindings,previous)
                pcall(api.ApplyBindings)
                return false,'Key routing failed; original Mixolas bindings restored.'
            end
        end
    elseif mode=='layout' or mode=='all' then
        local ok,reason=commitLayout(mode=='all')
        if not ok then return false,reason end
    end
    if mode=='appearance' or mode=='all' then
        local look=_G.MixolasBarsObsidian
        local oldLook=clone(db.obsidianPrototype or {})
        local oldFlash=clone(db.activationFlash or {})
        -- Only known cosmetic keys are importable; no code, secure, or binding values.
        local cosmetic=staged.appearance.obsidianPrototype or {}
        db.obsidianPrototype=db.obsidianPrototype or {}
        for _,k in ipairs({'intensity','frameOpacity','armorGlow','armorOpacity'}) do
            if cosmetic[k]~=nil then db.obsidianPrototype[k]=cosmetic[k] end
        end
        local effect=staged.appearance.activationFlash or {}
        db.activationFlash=db.activationFlash or {}
        for _,k in ipairs({'enabled','strength','duration','bar1ModifierColors','bar2ModifierColors'}) do
            if effect[k]~=nil then db.activationFlash[k]=effect[k] end
        end
        if look and look.Apply then
            local ok,success=pcall(look.Apply)
            if not ok or success==false then
                db.obsidianPrototype=oldLook;db.activationFlash=oldFlash
                pcall(look.Apply)
                return false,'Appearance import failed; restored previous appearance.'
            end
        end
    end
    if mode=='profiles' or mode=='all' then
        for name,profile in pairs(staged.profiles) do
            local target=pickUnique(db,'Shared '..name:sub(1,19))
            if not target then return false,'Profile library is full.' end
            db.mixolasProfiles[target]={layout=clone(profile.layout),bindings=clone(profile.bindings),
                nativeBindings=clone(profile.nativeBindings),version=profile.nativeBindings and 4 or 3}
        end
    end
    staged=nil
    return true,'Import applied. Native WoW shortcuts are saved in imported profiles and restored when one is loaded. Spell slots are never transferred.'
end
local panel,inbox,outbox,status
local selectedImportMode='all'
local modeDescriptions={
    all='Complete configuration: layout, Mixolas keys, appearance and saved profiles. WARNING: native WoW shortcuts are replaced (including movement and interface controls). Spell slots and macros are unchanged.',
    layout='Layout only: bar positions, sizes, frames and other visual layout settings. Mixolas keybindings and native WoW shortcuts are preserved.',
    keys='Mixolas keybindings only: replaces Mixolas custom action shortcuts but preserves native WoW keybindings.',
    appearance='Appearance only: visual effects and appearance settings, without changing bars or keybindings.',
    profiles='Saved profiles only: adds imported profiles to the library. Does not activate their native WoW keybindings now; loading them later may change those keys.',
}
local modeLabels={all='Complete Configuration',layout='Layout Only',keys='Mixolas Keybindings Only',appearance='Appearance Only',profiles='Saved Profiles Only'}
local function makePanel()
    if panel then return panel end
    local template=BackdropTemplateMixin and 'BackdropTemplate' or nil
    local f=CreateFrame('Frame','MixolasBarsTransferPanel',UIParent,template)
    f:SetSize(800,615);f:SetPoint('CENTER');f:SetFrameStrata('DIALOG')
    f:EnableMouse(true);f:SetMovable(true);f:RegisterForDrag('LeftButton')
    f:SetScript('OnDragStart',function(self) self:StartMoving() end)
    f:SetScript('OnDragStop',function(self) self:StopMovingOrSizing() end)
    if f.SetBackdrop then
        f:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',edgeSize=24,insets={left=8,right=8,top=8,bottom=8}})
    end
    local function txt(label,y)
        local t=f:CreateFontString(nil,'OVERLAY','GameFontHighlight')
        t:SetPoint('TOPLEFT',f,'TOPLEFT',22,y);t:SetText(label);return t
    end
    local function button(text,x,y,w,fn)
        local b=CreateFrame('Button',nil,f,'UIPanelButtonTemplate')
        b:SetSize(w,25);b:SetPoint('TOPLEFT',f,'TOPLEFT',x,y)
        b:SetText(text);b:SetScript('OnClick',fn);return b
    end
    txt('MIXOLAS BARS | PORTABLE SETTINGS (ASCII TEXT)',-21)
    local close=CreateFrame('Button',nil,f,'UIPanelCloseButton');close:SetPoint('TOPRIGHT',-4,-4)
    txt('Transfer layouts, profiles, Mixolas shortcuts and native WoW keybindings. Spell slots and macros are not included.',-53)
    -- Clearly separated, named input areas. Both fields use the existing
    -- EditBox/ScrollFrame mechanism so large MXB21 strings still copy/paste.
    local function section(label,y)
        local heading=txt(label,y)
        heading:SetTextColor(0.96,0.80,0.41)
        return heading
    end
    local function field(y,height)
        local holder=CreateFrame('Frame',nil,f)
        holder:SetPoint('TOPLEFT',f,'TOPLEFT',25,y)
        holder:SetSize(748,height)
        holder:EnableMouse(true)
        local bg=holder:CreateTexture(nil,'BACKGROUND')
        bg:SetAllPoints(holder)
        bg:SetTexture('Interface\\Buttons\\WHITE8X8')
        bg:SetVertexColor(0.035,0.055,0.085,0.96)
        local edges={}
        local function makeEdge(a1,to1,a2,to2,width,height)
            local edge=holder:CreateTexture(nil,'BORDER')
            edge:SetTexture('Interface\\Buttons\\WHITE8X8')
            edge:SetPoint(a1,holder,to1)
            edge:SetPoint(a2,holder,to2)
            edge:SetSize(width,height)
            edges[#edges+1]=edge
        end
        makeEdge('TOPLEFT','TOPLEFT','TOPRIGHT','TOPRIGHT',748,2)
        makeEdge('BOTTOMLEFT','BOTTOMLEFT','BOTTOMRIGHT','BOTTOMRIGHT',748,2)
        makeEdge('TOPLEFT','TOPLEFT','BOTTOMLEFT','BOTTOMLEFT',2,height)
        makeEdge('TOPRIGHT','TOPRIGHT','BOTTOMRIGHT','BOTTOMRIGHT',2,height)
        local function highlight(active)
            local r,g,b=0.39,0.56,0.72
            if active then r,g,b=0.98,0.80,0.35 end
            for _,edge in ipairs(edges) do edge:SetVertexColor(r,g,b,1) end
        end
        highlight(false)
        local frame=CreateFrame('ScrollFrame',nil,holder,'UIPanelScrollFrameTemplate')
        frame:SetPoint('TOPLEFT',holder,'TOPLEFT',10,-8)
        frame:SetSize(708,height-16)
        local edit=CreateFrame('EditBox',nil,frame)
        edit:SetMultiLine(true);edit:SetAutoFocus(false);edit:SetMaxLetters(0)
        edit:SetFontObject('ChatFontNormal')
        edit:SetWidth(682);edit:SetHeight(math.max(2000,height+2))
        edit:SetScript('OnEscapePressed',function(self) self:ClearFocus() end)
        edit:SetScript('OnEditFocusGained',function() highlight(true) end)
        edit:SetScript('OnEditFocusLost',function() highlight(false) end)
        frame:SetScrollChild(edit)
        holder:SetScript('OnMouseDown',function() edit:SetFocus() end)
        return edit
    end
    section('EXPORT TEXT  |  Click inside the outlined box and press Ctrl+C to copy',-80)
    outbox=field(-100,121)
    button('Generate export',25,-233,166,function()
        local data,err=export()
        if data then
            outbox:SetText(data)
            outbox:SetFocus()
            outbox:HighlightText()
            status:SetText('Export ready: '..#data..' characters. Text selected; press Ctrl+C to copy.')
        else status:SetText('Export error: '..tostring(err)) end
    end)
    button('Select export text',205,-233,170,function()
        if outbox:GetText()=='' then
            status:SetText('Generate your export first.')
            return
        end
        outbox:SetFocus()
        outbox:HighlightText()
        status:SetText('Export text selected. Press Ctrl+C to copy.')
    end)
    local separator=f:CreateTexture(nil,'ARTWORK')
    separator:SetTexture('Interface\\Buttons\\WHITE8X8')
    separator:SetVertexColor(0.32,0.42,0.55,0.75)
    separator:SetPoint('TOPLEFT',f,'TOPLEFT',25,-269)
    separator:SetSize(748,1)
    section('IMPORT TEXT  |  Click inside the outlined box and press Ctrl+V to paste',-288)
    inbox=field(-307,117)
    button('Stage import',25,-436,156,function()
        local ok,msg=import(inbox:GetText())
        status:SetText((ok and 'Ready: ' or 'Error: ')..tostring(msg))
    end)
    txt('IMPORT CONTENTS',-473)
    local modeSelect=button('Complete Configuration  ▼',180,-469,295,function()
        -- Temporary options menu opens UPWARD so it does not obscure the
        -- Review button or final status text. Only one mode is ever selected.
        if f.modeMenu:IsShown() then f.modeMenu:Hide() else f.modeMenu:Show() end
    end)
    local menu=CreateFrame('Frame',nil,f,BackdropTemplateMixin and 'BackdropTemplate' or nil)
    menu:SetSize(298,151)
    menu:SetPoint('BOTTOMLEFT',modeSelect,'TOPLEFT',0,3)
    menu:SetFrameStrata('FULLSCREEN_DIALOG')
    menu:SetFrameLevel(f:GetFrameLevel()+20)
    if menu.SetBackdrop then
        menu:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',
            edgeFile='Interface\\DialogFrame\\UI-DialogBox-Border',edgeSize=18,
            insets={left=4,right=4,top=4,bottom=4}})
    end
    local modes={'all','layout','keys','appearance','profiles'}
    for i,mode in ipairs(modes) do
        local option=CreateFrame('Button',nil,menu,'UIPanelButtonTemplate')
        option:SetSize(278,25)
        option:SetPoint('TOPLEFT',menu,'TOPLEFT',10,-9-(i-1)*28)
        option:SetText(modeLabels[mode])
        option:SetScript('OnClick',function()
            selectedImportMode=mode
            modeSelect:SetText(modeLabels[mode]..'  ▼')
            menu:Hide()
            status:SetText('Mode: '..modeLabels[mode]..'. '..(staged and 'Ready to review.' or 'Stage an import first.'))
        end)
    end
    menu:Hide()
    f.modeMenu=menu
    button('REVIEW & CONFIRM',490,-469,280,function()
        if not staged then
            status:SetText('No staged import. Paste MXB21 text and click Stage Import first.')
            return
        end
        if not api.ShowConfirm then
            status:SetText('Confirmation window unavailable. Import was NOT applied.')
            return
        end
        local mode=selectedImportMode
        local expected=staged
        local detail=modeDescriptions[mode]
        if mode=='all' then
            local n=0;for _,list in pairs(staged.bindings) do n=n+#list end
            local count=0;for _ in pairs(staged.profiles) do count=count+1 end
            local native=staged.nativeBindings and (api.CountNativeBindings and api.CountNativeBindings(staged.nativeBindings) or 0) or 0
            detail='Replace bar layout, '..n..' Mixolas key assignments, visual effects and add '..count..' saved profiles. '..
                (native>0 and ('WARNING: REPLACE '..native..' native WoW shortcuts (movement/interface). ') or 'Native WoW shortcuts unchanged. ')..
                'Spells and macros are not transferred.'
        end
        api.ShowConfirm('Import: '..modeLabels[mode]..'?',detail,function()
            if staged~=expected then
                status:SetText('Import contents changed. Please review again.')
                return
            end
            local ok,msg=confirm(mode)
            status:SetText((ok and 'Success: ' or 'Error: ')..tostring(msg))
        end,mode=='all' and 'REPLACE & IMPORT' or 'CONFIRM IMPORT',nil,'CANCEL')
    end)
    status=txt('No import staged. Stage -> Choose -> Review & Confirm.',-535)
    status:SetWidth(748)
    status:SetJustifyH('LEFT')
    status:SetHeight(64)
    if status.SetJustifyV then status:SetJustifyV('TOP') end
    if status.SetWordWrap then status:SetWordWrap(true) end
    f:Hide();panel=f
    if UISpecialFrames then table.insert(UISpecialFrames,'MixolasBarsTransferPanel') end
    return f
end
local function show() makePanel():Show() end
_G.MixolasBarsTransfer={Export=export,Stage=import,Confirm=confirm,Open=show,
    _Encode=function(payload) return (payload.version==20 and 'MXB20:' or 'MXB21:')..base64(serialize(payload)) end,
    _Decode=function(text)
        if type(text)~='string' or (text:sub(1,6)~='MXB20:' and text:sub(1,6)~='MXB21:') then return nil,'Bad prefix.' end
        local raw,err=unbase64(text:sub(7))
        if not raw then return nil,err end
        return deserialize(raw)
    end}
SLASH_MXBTRANSFER1='/mxbtransfer'
SlashCmdList.MXBTRANSFER=function() show() end
